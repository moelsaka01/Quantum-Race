from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ScenarioInput(BaseModel):
    pit_lap: int = Field(default=35, ge=1, le=71)
    tyre_compound: Literal["SOFT", "MEDIUM", "HARD", "INTERMEDIATE", "WET"] = "MEDIUM"
    rain_probability: int = Field(default=61, ge=0, le=100)
    safety_car_probability: int = Field(default=31, ge=0, le=100)
    recharge_aggression: int = Field(default=4, ge=0, le=10)
    push_level: int = Field(default=6, ge=0, le=10)
    rival_pit_behavior: Literal["conservative", "balanced", "aggressive"] = "aggressive"
    track_temperature: float = Field(default=32.4, ge=0, le=70)
    battery_soc: int = Field(default=63, ge=0, le=100)
    superclip_exposure: float = Field(default=3.2, ge=0, le=8)
    corner_entry_risk: int = Field(default=58, ge=0, le=100)
    tyre_thermal_load: int = Field(default=71, ge=0, le=100)
    active_aero_mode: Literal["X-Mode", "Z-Mode", "Transition"] = "Z-Mode"


class HumanDecisionCreate(BaseModel):
    recommendation_id: str
    action: Literal["Approved", "Adjusted", "Rejected"]
    responsible_human: str = Field(default="M. Alvarez, Race Engineer", min_length=2)
    rationale: str = Field(min_length=4)
    revised_strategy: str | None = None
    risk_tolerance: Literal["Low", "Medium", "High"] = "Medium"


class DataSourceConnectRequest(BaseModel):
    provider: Literal["openf1"] = "openf1"
    mode: Literal["public_historical", "realtime_subscription"] = "public_historical"
    session: str = Field(default="latest", min_length=1)
    year: int | None = Field(default=None, ge=2023, le=2100)
    country_name: str | None = None
    session_name: str | None = None
    driver_number: int | None = Field(default=None, ge=1, le=999)
    allow_mock_fallback: bool = True


class HealthResponse(BaseModel):
    status: Literal["ok"]
    service: str
    human_in_the_loop: bool
