from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from random import Random

from .schemas import HumanDecisionCreate, ScenarioInput


def clamp_percent(value: float) -> int:
    return max(0, min(100, round(value)))


RACE_STATE = {
    "ruleset": "2026 Ruleset Active",
    "grand_prix": "Austrian Grand Prix 2026",
    "circuit": "Red Bull Ring",
    "lap": 32,
    "total_laps": 71,
    "position": "P3",
    "gap_to_leader": "+7.801",
    "gap_to_rival": "+4.312 to NOR",
    "driver": "HAM",
    "race_phase": "Stint 2 - pit window opening",
    "current_sector": "Sector 3",
    "tyre_compound": "MEDIUM",
    "tyre_age": 12,
    "fuel_remaining_laps": 18.6,
    "track_temperature": 32.4,
    "air_temperature": 24.7,
    "rain_probability": 61,
    "safety_car_risk": 31,
    "last_lap": "1:08.732",
    "race_engineer": "M. Alvarez",
    "decision_state": "Under Review",
    "activeAeroMode": "Z-Mode",
    "xModeAvailable": True,
    "zModeStability": 78,
    "overtakeMode": "armed_next_lap",
    "boostButton": "available",
    "batterySOC": 63,
    "batterySOCTrend": "depleting",
    "rechargeMode": "balanced",
    "energyClippingRisk": "medium",
    "superclipDuration": 3.2,
    "mguKDeployment": 350,
    "boostPowerDelta": 150,
    "aeroTransitionRisk": "medium",
    "cornerEntryRisk": "high",
    "tyreThermalLoad": 71,
    "rivalEnergyAttackWindow": "Lap 34-36",
    "car2026Profile": {
        "narrower_car": True,
        "shorter_wheelbase": True,
        "lower_downforce": True,
        "reduced_drag": True,
        "narrower_tyres": True,
        "active_aero": True,
    },
}

DRIVERS = [
    {"pos": 1, "code": "VER", "driver": "Verstappen", "gap": "Leader", "tyre": "MEDIUM", "pit": "-"},
    {"pos": 2, "code": "LEC", "driver": "Leclerc", "gap": "+7.801", "tyre": "MEDIUM", "pit": "-"},
    {"pos": 3, "code": "HAM", "driver": "Hamilton", "gap": "+7.801", "tyre": "MEDIUM", "pit": "-"},
    {"pos": 4, "code": "NOR", "driver": "Norris", "gap": "+12.312", "tyre": "MEDIUM", "pit": "-"},
    {"pos": 5, "code": "RUS", "driver": "Russell", "gap": "+15.981", "tyre": "HARD", "pit": "-"},
    {"pos": 6, "code": "PIA", "driver": "Piastri", "gap": "+18.732", "tyre": "MEDIUM", "pit": "-"},
    {"pos": 7, "code": "SAI", "driver": "Sainz", "gap": "+21.456", "tyre": "HARD", "pit": "-"},
    {"pos": 8, "code": "OCO", "driver": "Ocon", "gap": "+23.873", "tyre": "HARD", "pit": "-"},
    {"pos": 9, "code": "ALB", "driver": "Albon", "gap": "+26.981", "tyre": "MEDIUM", "pit": "-"},
    {"pos": 10, "code": "GAS", "driver": "Gasly", "gap": "+29.231", "tyre": "MEDIUM", "pit": "-"},
]

THREATS = [
    {"name": "Overtake Mode Threat", "value": 87, "severity": "critical"},
    {"name": "Battery Depletion Risk", "value": 64, "severity": "warning"},
    {"name": "X-Mode Straight-Line Threat", "value": 69, "severity": "warning"},
    {"name": "Z-Mode Corner Instability", "value": 46, "severity": "watch"},
    {"name": "Energy Clipping Risk", "value": 54, "severity": "warning"},
    {"name": "Tyre Thermal Risk", "value": 71, "severity": "warning"},
]

TELEMETRY = {
    "speed_trace": [
        {"lap_distance": i, "HAM": 286 + ((i * 23) % 92) - (70 if i in [12, 13, 14, 31, 32, 48] else 0), "VER": 292 + ((i * 19) % 84) - (64 if i in [12, 13, 31, 32, 48] else 0)}
        for i in range(1, 61)
    ],
    "throttle_trace": [{"lap_distance": i, "throttle": max(0, 96 - (i % 13) * 7 if i % 17 < 12 else 34)} for i in range(1, 61)],
    "brake_trace": [{"lap_distance": i, "brake": 12 if i % 17 < 11 else 84 - (i % 6) * 9} for i in range(1, 61)],
    "sector_times": [
        {"sector": "S1", "HAM": 17.92, "VER": 17.78, "NOR": 18.04},
        {"sector": "S2", "HAM": 29.61, "VER": 29.43, "NOR": 29.70},
        {"sector": "S3", "HAM": 21.20, "VER": 21.11, "NOR": 21.28},
    ],
    "lap_times": [
        {"lap": lap, "HAM": 68.4 + (lap % 5) * 0.08 + (0.7 if lap in [27, 28] else 0), "NOR": 68.7 + (lap % 4) * 0.06}
        for lap in range(20, 33)
    ],
    "battery_soc_trace": [{"lap": lap, "SOC": max(48, 78 - (lap - 20) * 1.7), "recharge": 10 + ((lap - 20) % 5) * 4} for lap in range(20, 34)],
    "mgu_k_trace": [
        {"lap_distance": i, "deployment": 350 if 10 < i % 18 < 15 else 215 + (i % 9) * 8, "harvest": 55 if 10 < i % 18 < 15 else 140 + (i % 6) * 10}
        for i in range(1, 61)
    ],
    "live_strip": {
        "speed": "315 km/h",
        "throttle": "91%",
        "brake": "12%",
        "gear": "7",
        "battery_soc": "63%",
        "mgu_k_deployment": "350 kW",
        "boost_button_status": "Available",
        "overtake_mode_status": "Armed next lap",
        "active_aero_mode": "Z-Mode",
        "recharge_mode": "Balanced",
        "superclip_duration": "3.2s/lap",
        "energy_clipping_risk": "Medium",
        "lap_time": "1:08.732",
        "sectors": ["17.92", "29.61", "21.20"],
    },
}

ADVANCED_TELEMETRY = {
    "sector_comparison": TELEMETRY["sector_times"],
    "corner_speed": [
        {"corner": f"T{i}", "HAM": 118 + i * 6 + (i % 3) * 11, "NOR": 116 + i * 6 + (i % 2) * 12}
        for i in range(1, 11)
    ],
    "brake_pressure": [{"corner": f"T{i}", "pressure": 48 + (i * 7) % 42} for i in range(1, 11)],
    "mgu_k_usage": [{"lap": lap, "deploy": 38 + (lap * 5) % 44, "harvest": 28 + (lap * 3) % 31} for lap in range(24, 33)],
    "tyre_temperature": [
        {"lap": lap, "front_left": 91 + lap % 6, "front_right": 94 + lap % 7, "rear_left": 97 + lap % 5, "rear_right": 100 + lap % 6}
        for lap in range(24, 33)
    ],
    "anomalies": [
        {"system": "Rear tyre surface", "delta": "+3.2C", "severity": "watch"},
        {"system": "Energy clipping exposure", "delta": "3.2s/lap", "severity": "medium"},
        {"system": "Brake migration", "delta": "+4%", "severity": "watch"},
    ],
}


def _cluster_points(seed: int = 44) -> list[dict]:
    rng = Random(seed)
    clusters = [
        ("Win", "#12d986", 44, 7, 18),
        ("Podium", "#f2c94c", 34, 22, 58),
        ("Points", "#2aa8ff", 30, 46, 112),
        ("No Points", "#ff3333", 20, 68, 44),
        ("Safety Car", "#ff8a1f", 70, 35, 30),
        ("Rain Outcome", "#6fe7ff", 62, 14, 34),
        ("Failed Strategy", "#d92929", 82, 72, 22),
    ]
    points: list[dict] = []
    for name, color, x, y, count in clusters:
        for _ in range(count):
            points.append(
                {
                    "cluster": name,
                    "color": color,
                    "x": round(max(2, min(98, rng.gauss(x, 9))), 2),
                    "y": round(max(2, min(98, rng.gauss(y, 8))), 2),
                    "opacity": round(rng.uniform(0.45, 0.95), 2),
                }
            )
    return points


def generate_simulation(input_data: ScenarioInput | None = None) -> dict:
    scenario = input_data or ScenarioInput()
    pit_delta = abs(scenario.pit_lap - 35)
    rain = scenario.rain_probability
    safety = scenario.safety_car_probability
    push = scenario.push_level
    aggressive_rival = 1 if scenario.rival_pit_behavior == "aggressive" else 0
    energy_penalty = max(0, max(0, 68 - scenario.battery_soc) * 0.7 + scenario.superclip_exposure * 2.2 - scenario.recharge_aggression * 0.8)
    aero_penalty = 8 if scenario.active_aero_mode == "Transition" else 4 if scenario.active_aero_mode == "X-Mode" else 0
    compound_bonus = {"SOFT": 2, "MEDIUM": 4, "HARD": 1, "INTERMEDIATE": 3, "WET": -3}[scenario.tyre_compound]
    risk_score = clamp_percent(rain * 0.22 + safety * 0.27 + pit_delta * 6 + push * 2.6 + aggressive_rival * 7 + energy_penalty + scenario.corner_entry_risk * 0.2 + scenario.tyre_thermal_load * 0.16 + aero_penalty)
    win_probability = clamp_percent(22 + compound_bonus + (5 - pit_delta) * 1.3 + push * 0.7 - rain * 0.025 - aggressive_rival * 2 - energy_penalty * 0.22)
    podium_probability = clamp_percent(63 + compound_bonus + (5 - pit_delta) * 1.8 + push * 0.9 - risk_score * 0.18)
    points_probability = clamp_percent(92 + compound_bonus - risk_score * 0.16)
    expected_finish = round(max(1.0, min(10.0, 1 + (100 - podium_probability) / 17 + risk_score / 55)), 1)
    return {
        "simulation_count": 100000,
        "win_probability": win_probability,
        "podium_probability": podium_probability,
        "points_probability": points_probability,
        "expected_finish": expected_finish,
        "risk_score": risk_score,
        "best_case": "P1 if Norris burns Boost early and rain arrives after lap 44",
        "worst_case": "P7 if rival energy attack succeeds and Battery SOC drops below the target band",
        "battery_soc": scenario.battery_soc,
        "energy_clipping_risk": clamp_percent(energy_penalty * 4),
        "corner_entry_risk": scenario.corner_entry_risk,
        "tyre_thermal_load": scenario.tyre_thermal_load,
        "active_aero_mode": scenario.active_aero_mode,
        "outcome_clusters": [
            {"name": "Win", "probability": win_probability, "color": "#12d986"},
            {"name": "Podium", "probability": podium_probability, "color": "#f2c94c"},
            {"name": "Points", "probability": points_probability, "color": "#2aa8ff"},
            {"name": "No Points", "probability": clamp_percent(100 - points_probability), "color": "#ff3333"},
            {"name": "Safety Car", "probability": safety, "color": "#ff8a1f"},
            {"name": "Rain Outcome", "probability": rain, "color": "#6fe7ff"},
            {"name": "Failed Strategy", "probability": risk_score, "color": "#d92929"},
        ],
        "points": _cluster_points(),
        "strategy_comparison": [
            {"strategy": "Recharge before attack", "expected_finish": 3.4, "risk": 42, "support": 80},
            {"strategy": "Pit in 3 laps after recharge", "expected_finish": 3.2, "risk": 43, "support": 82},
            {"strategy": "Defend with Boost", "expected_finish": 3.7, "risk": 38, "support": 77},
            {"strategy": "Use X-Mode straight-line offset", "expected_finish": 3.6, "risk": 52, "support": 71},
        ],
        "rain_scenario_impact": "-0.6 positions if rain begins before lap 42; +0.4 if delayed beyond lap 48",
        "safety_car_scenario_impact": "Late safety car improves Battery SOC recovery but increases restart Boost defense pressure",
    }


def get_agent_debate() -> dict:
    agents = [
        {
            "name": "Strategy Director",
            "role": "Race strategy synthesis",
            "recommendation": "Pit in 3 laps",
            "confidence": 86,
            "evidence": ["Pit window lap 33-37 is opening", "Traffic loss remains below 1.4s", "Norris energy attack window opens lap 34"],
            "concern": "Pitting too early creates a Battery SOC deficit in the next attack phase",
            "stance": "Agree",
            "risk_level": "Medium",
        },
        {
            "name": "Tyre Scientist",
            "role": "Tyre life and degradation",
            "recommendation": "Stay out to lap 35",
            "confidence": 78,
            "evidence": ["Medium tyre degradation is linear", "No cliff signature in rear surface temps", "Grip drop predicted in 8 laps"],
            "concern": "Lap 38 becomes high risk if track temp rises",
            "stance": "Agree with caution",
            "risk_level": "Medium",
        },
        {
            "name": "Weather Analyst",
            "role": "Weather uncertainty",
            "recommendation": "Delay only if rain radar confirms lap 42 arrival",
            "confidence": 69,
            "evidence": ["Rain probability 61%", "Cell speed uncertainty +/- 6 minutes", "Sector 2 wind shift increasing"],
            "concern": "Intermediates become viable only after lap 44",
            "stance": "Partial disagreement",
            "risk_level": "High",
        },
        {
            "name": "Rival Analyst",
            "role": "Competitor digital twins",
            "recommendation": "Cover Norris energy attack window",
            "confidence": 88,
            "evidence": ["Norris twin predicts attack lap 34", "Rival Overtake Mode eligibility likely", "Boost defense probability is falling"],
            "concern": "Norris may combine X-Mode straight speed with saved boost on lap 34",
            "stance": "Agree",
            "risk_level": "High",
        },
        {
            "name": "Energy Strategist",
            "role": "Battery SOC, Boost Button, recharge strategy, and MGU-K deployment",
            "recommendation": "Delay attack by two laps to recover Battery SOC before using Overtake Mode",
            "confidence": 74,
            "evidence": ["Battery SOC 63%", "Battery trend depleting", "Superclip exposure 3.2s/lap", "Rival likely to attack on lap 34"],
            "concern": "Attacking before recharge window may leave car exposed to Boost defense",
            "stance": "Agree",
            "risk_level": "Medium",
        },
        {
            "name": "Active Aero Engineer",
            "role": "X-Mode, Z-Mode, aero transition zones, and stability risk",
            "recommendation": "Use X-Mode on the designated straight and protect Z-Mode corner exits through Sector 2",
            "confidence": 80,
            "evidence": ["X-Mode available next straight", "Aero transition risk medium", "Z-Mode stability 78%", "Sector 2 corner entry high risk"],
            "concern": "Low-drag transition too late could destabilize corner entry",
            "stance": "Agree with caution",
            "risk_level": "Medium",
        },
        {
            "name": "Corner Entry Analyst",
            "role": "2026 narrower-car braking stability and tyre thermal load",
            "recommendation": "Avoid aggressive entry into Sector 2 while tyre thermal load is above 70%",
            "confidence": 77,
            "evidence": ["Tyre thermal load 71%", "Lower downforce profile", "Narrower tyre model active", "Brake migration sensitivity rising"],
            "concern": "Corner-entry instability risk increases if boost deployment overlaps braking phase",
            "stance": "Partial disagreement",
            "risk_level": "High",
        },
        {
            "name": "Risk Manager",
            "role": "Downside containment",
            "recommendation": "Require race engineer review before committing",
            "confidence": 91,
            "evidence": ["Weather variance increasing", "Energy attack risk critical", "Corner entry risk high"],
            "concern": "Energy and active aero downside exceeds automated threshold",
            "stance": "Race engineer review required",
            "risk_level": "High",
        },
        {
            "name": "Performance Engineer",
            "role": "Pace and vehicle performance",
            "recommendation": "Stay out while sector 3 remains competitive",
            "confidence": 72,
            "evidence": ["S3 delta to VER is +0.09s", "Brake pressure stable", "MGU-K clipping limited to S2"],
            "concern": "Rear temperatures are trending upward with narrower tyre sensitivity",
            "stance": "Partial disagreement",
            "risk_level": "Medium",
        },
    ]
    team_principal = {
        "name": "Team Principal Agent",
        "role": "Consensus synthesis",
        "recommendation": "Stay out to lap 35, recharge through lift-and-coast windows, prepare Boost defense against Norris, and submit Overtake Mode timing plan for Pit Wall Approval",
        "confidence": 82,
        "evidence": ["Race strategy, tyre, weather, rival, energy, active aero, and corner-entry models attached", "Battery SOC 63%", "Simulation support strongest for lap 35 energy defense"],
        "concern": "Rival energy attack and Z-Mode corner-entry risk create a narrow decision window",
        "stance": "Requires Race Engineer Review",
        "risk_level": "High",
        "consensus_recommendation": "Stay out to lap 35, recharge, defend with Boost",
        "disagreement_summary": "Energy and active aero agents want two recharge laps; rival model warns Norris can attack earlier.",
        "risk_explanation": "Stay out until Lap 35, recharge Battery SOC, defend with Boost if Norris enters the Overtake Mode window. Requires Pit Wall Approval.",
        "requires_human_review": True,
        "requires_pit_wall_approval": True,
    }
    return {
        "agents": agents + [team_principal],
        "consensus": team_principal,
        "agreement_level": 82,
        "disagreement_count": 2,
        "next_action": "Submit recommendation to Pit Wall Approval",
    }


def get_rival_twins() -> list[dict]:
    return [
        {
            "name": "Verstappen Twin",
            "team": "Redline Racing",
            "position": "P1",
            "predicted_pit_lap": 36,
            "tyre_age": 13,
            "tyre_degradation_estimate": "0.061s/lap",
            "pace_trend": "Stable high pace",
            "sector_strengths": ["S1 traction", "T3 exit"],
            "sector_weaknesses": ["S2 tyre temperature"],
            "energy_attack_threat": 87,
            "long_stint_threat": 42,
            "likely_tyre_choice": "HARD",
            "rival_battery_soc": 72,
            "rival_soc_trend": "stable",
            "overtake_mode_eligibility": "available",
            "boost_availability": "defense",
            "x_mode_efficiency": 86,
            "z_mode_cornering_strength": 81,
            "recharge_behavior": "balanced harvest",
            "superclip_exposure": 2.4,
            "likely_energy_attack_lap": 35,
            "likely_boost_defense_lap": 34,
            "corner_entry_weakness": "S2 tyre temperature",
            "tyre_thermal_sensitivity": 66,
            "strategy_likelihood": "Battery Offset Advantage",
            "final_position_probability": {"P1": 68, "P2": 24, "P3": 8},
            "confidence": 89,
        },
        {
            "name": "Norris Twin",
            "team": "Papaya Dynamics",
            "position": "P4",
            "predicted_pit_lap": 34,
            "tyre_age": 12,
            "tyre_degradation_estimate": "0.047s/lap",
            "pace_trend": "Improving in clean air",
            "sector_strengths": ["S2 minimum speed", "X-Mode straight efficiency"],
            "sector_weaknesses": ["S1 braking"],
            "energy_attack_threat": 62,
            "long_stint_threat": 39,
            "likely_tyre_choice": "HARD",
            "rival_battery_soc": 68,
            "rival_soc_trend": "charging",
            "overtake_mode_eligibility": "eligible",
            "boost_availability": "attack",
            "x_mode_efficiency": 88,
            "z_mode_cornering_strength": 72,
            "recharge_behavior": "lift-and-coast recharge",
            "superclip_exposure": 3.6,
            "likely_energy_attack_lap": 34,
            "likely_boost_defense_lap": 35,
            "corner_entry_weakness": "S1 braking",
            "tyre_thermal_sensitivity": 74,
            "strategy_likelihood": "Norris Energy Attack Window",
            "final_position_probability": {"P2": 21, "P3": 37, "P4": 42},
            "confidence": 84,
        },
        {
            "name": "Leclerc Twin",
            "team": "Scuderia Rosso",
            "position": "P2",
            "predicted_pit_lap": 35,
            "tyre_age": 12,
            "tyre_degradation_estimate": "0.052s/lap",
            "pace_trend": "Small rear-limited fade",
            "sector_strengths": ["S3 rotation", "Wet transition"],
            "sector_weaknesses": ["T4 traction"],
            "energy_attack_threat": 41,
            "long_stint_threat": 55,
            "likely_tyre_choice": "HARD",
            "rival_battery_soc": 61,
            "rival_soc_trend": "depleting",
            "overtake_mode_eligibility": "armed_next_lap",
            "boost_availability": "saving",
            "x_mode_efficiency": 78,
            "z_mode_cornering_strength": 84,
            "recharge_behavior": "brake recovery",
            "superclip_exposure": 3.1,
            "likely_energy_attack_lap": 36,
            "likely_boost_defense_lap": 34,
            "corner_entry_weakness": "T4 traction",
            "tyre_thermal_sensitivity": 69,
            "strategy_likelihood": "Z-Mode Corner Protection",
            "final_position_probability": {"P1": 18, "P2": 52, "P3": 30},
            "confidence": 80,
        },
        {
            "name": "Russell Twin",
            "team": "Silver Arrow Lab",
            "position": "P5",
            "predicted_pit_lap": 38,
            "tyre_age": 8,
            "tyre_degradation_estimate": "0.039s/lap",
            "pace_trend": "Late-stint recovery",
            "sector_strengths": ["Recharge efficiency", "S3 consistency"],
            "sector_weaknesses": ["S1 straightline"],
            "energy_attack_threat": 28,
            "long_stint_threat": 58,
            "likely_tyre_choice": "MEDIUM",
            "rival_battery_soc": 75,
            "rival_soc_trend": "charging",
            "overtake_mode_eligibility": "unavailable",
            "boost_availability": "defense",
            "x_mode_efficiency": 67,
            "z_mode_cornering_strength": 79,
            "recharge_behavior": "safety car recharge bias",
            "superclip_exposure": 1.8,
            "likely_energy_attack_lap": 38,
            "likely_boost_defense_lap": 36,
            "corner_entry_weakness": "S1 straightline",
            "tyre_thermal_sensitivity": 58,
            "strategy_likelihood": "Recharge Behavior",
            "final_position_probability": {"P3": 12, "P4": 31, "P5": 57},
            "confidence": 76,
        },
    ]


def get_strategy_recommendations() -> list[dict]:
    strategies = [
        ("recharge-attack", "Recharge before attack", 3.4, 79, 21, 64, "Medium", 76, 24, 36, 42, 80, "Lift-and-coast for two laps, recover Battery SOC, then arm Overtake Mode with Boost Button available."),
        ("defend-boost", "Defend with Boost", 3.7, 74, 19, 61, "Medium", 60, 28, 38, 62, 77, "Hold track position if Norris attacks with Overtake Mode by preserving Boost for lap 34-35 defense."),
        ("arm-overtake", "Arm Overtake Mode", 3.5, 73, 20, 60, "High", 58, 40, 44, 69, 73, "Prepare an Overtake Mode attack only after confirming X-Mode straight-line phase and Battery SOC margin."),
        ("x-mode-offset", "Use X-Mode straight-line offset", 3.6, 70, 19, 58, "Medium", 63, 25, 39, 52, 71, "Exploit X-Mode Straight-Line Phase on the main straight without compromising Z-Mode corner exits."),
        ("z-mode-protect", "Protect Z-Mode corner exits", 3.8, 69, 17, 58, "Medium", 66, 22, 37, 49, 70, "Prioritize Z-Mode stability through Sector 2 while tyre thermal load remains above 70%."),
        ("pit-now", "Pit now before energy deficit compounds", 4.4, 61, 18, 51, "High", 62, 46, 78, 68, 41, "Stops the track-position loss but risks leaving the car short on Battery SOC for the next Overtake Mode phase."),
        ("pit-in-3", "Pit in 3 laps after recharge", 3.2, 82, 22, 66, "Medium", 71, 34, 42, 55, 84, "Best balance between tyre life, Battery SOC recovery, and Boost defense against Norris."),
        ("safety-recharge", "Harvest under Safety Car", 4.2, 58, 14, 49, "Medium", 81, 12, 35, 41, 57, "Use a caution phase to recharge Battery SOC and reset Boost availability before the final stint."),
        ("cover-energy-attack", "Cover rival energy attack", 3.6, 74, 20, 61, "Medium", 64, 33, 44, 66, 78, "Counters Norris Energy Attack Window with Boost defense and conservative corner-entry deployment."),
        ("conservative-entry", "Reduce corner-entry risk with conservative deployment", 4.0, 67, 16, 56, "High", 68, 20, 47, 43, 69, "Avoid boost overlap into braking zones while tyre thermal load and lower-downforce sensitivity are elevated."),
    ]
    return [
        {
            "id": strategy_id,
            "name": name,
            "expected_finish": expected_finish,
            "probability_of_success": success,
            "win_probability": win,
            "podium_probability": podium,
            "risk_level": risk_level,
            "battery_soc_impact": battery_soc_impact,
            "recharge_requirement": recharge_requirement,
            "boost_requirement": boost_requirement,
            "active_aero_risk": active_aero_risk,
            "tyre_risk": active_aero_risk,
            "rival_risk": boost_requirement,
            "weather_risk": active_aero_risk,
            "simulation_support": support,
            "explanation": explanation,
            "requires_human_decision": True,
            "requires_pit_wall_approval": True,
            "batterySOC": RACE_STATE["batterySOC"],
            "batterySOCTrend": RACE_STATE["batterySOCTrend"],
            "boostButton": RACE_STATE["boostButton"],
            "overtakeMode": RACE_STATE["overtakeMode"],
            "activeAeroMode": RACE_STATE["activeAeroMode"],
            "xModeAvailable": RACE_STATE["xModeAvailable"],
            "zModeStability": RACE_STATE["zModeStability"],
            "rechargeMode": RACE_STATE["rechargeMode"],
            "mguKDeployment": RACE_STATE["mguKDeployment"],
            "superclipDuration": RACE_STATE["superclipDuration"],
            "energyClippingRisk": RACE_STATE["energyClippingRisk"],
            "cornerEntryRisk": RACE_STATE["cornerEntryRisk"],
            "tyreThermalLoad": RACE_STATE["tyreThermalLoad"],
            "rivalEnergyAttackWindow": RACE_STATE["rivalEnergyAttackWindow"],
            "action": "Submit to Pit Wall Approval",
        }
        for strategy_id, name, expected_finish, success, win, podium, risk_level, battery_soc_impact, recharge_requirement, boost_requirement, active_aero_risk, support, explanation in strategies
    ]


RACE_MEMORY: list[dict] = [
    {
        "id": "memory-austria-2026",
        "race": "Austrian Grand Prix 2026",
        "circuit": "Red Bull Ring",
        "date": "2026-06-21",
        "lap": 34,
        "situation": "Battery SOC was marginal before a rival Overtake Mode attack window.",
        "ai_recommendation": "Recharge before attack",
        "human_decision": "Approved",
        "race_engineer_decision": "Approved",
        "final_outcome": "Boost defense margin improved before the attack phase.",
        "battery_soc": 59,
        "boost_status": "defense",
        "overtake_mode_status": "armed_next_lap",
        "active_aero_mode": "Z-Mode",
        "aero_context": "X-Mode delayed until main straight; Z-Mode protected through Sector 2.",
        "energy_clipping_risk": "medium",
        "corner_entry_risk": "high",
        "tyre_thermal_load": 73,
        "rival_energy_threat": "Norris Energy Attack Window",
        "lesson_learned": "Battery SOC was too low to attack immediately; delaying two laps improved Boost defense margin.",
        "tags": ["battery-soc", "boost-defense", "pit-wall-approval"],
        "similar_scenario": "Austrian GP lap 32 energy defense",
    },
    {
        "id": "memory-barcelona-2026",
        "race": "Barcelona Grand Prix 2026",
        "circuit": "Circuit de Barcelona-Catalunya",
        "date": "2026-05-31",
        "lap": 27,
        "situation": "Long-corner Z-Mode instability pushed tyre thermal load above the target band.",
        "ai_recommendation": "Protect Z-Mode corner exits",
        "human_decision": "Adjusted",
        "race_engineer_decision": "Adjusted",
        "final_outcome": "Conservative corner-entry deployment improved stint life.",
        "battery_soc": 66,
        "boost_status": "saving",
        "overtake_mode_status": "eligible",
        "active_aero_mode": "Z-Mode",
        "aero_context": "Z-Mode stability prioritized over X-Mode straight-line gain.",
        "energy_clipping_risk": "low",
        "corner_entry_risk": "high",
        "tyre_thermal_load": 76,
        "rival_energy_threat": "Leclerc boost defense",
        "lesson_learned": "Z-Mode instability through long corners increased tyre thermal load; conservative corner-entry deployment improved stint life.",
        "tags": ["z-mode", "corner-entry", "tyre-thermal"],
        "similar_scenario": "Sector 2 corner-entry instability",
    },
    {
        "id": "memory-monaco-2026",
        "race": "Monaco Grand Prix 2026",
        "circuit": "Circuit de Monaco",
        "date": "2026-05-24",
        "lap": 42,
        "situation": "Short straights limited X-Mode benefit while track position remained decisive.",
        "ai_recommendation": "Use X-Mode straight-line offset",
        "human_decision": "Rejected",
        "race_engineer_decision": "Rejected",
        "final_outcome": "Track position outweighed energy attack potential.",
        "battery_soc": 71,
        "boost_status": "available",
        "overtake_mode_status": "eligible",
        "active_aero_mode": "Transition",
        "aero_context": "X-Mode gain limited by short straights; Z-Mode stability protected traction.",
        "energy_clipping_risk": "low",
        "corner_entry_risk": "medium",
        "tyre_thermal_load": 64,
        "rival_energy_threat": "Low",
        "lesson_learned": "X-Mode benefit was limited by short straights; track position outweighed energy attack potential.",
        "tags": ["x-mode", "track-position", "low-drag-limited"],
        "similar_scenario": "Low straight-line energy gain",
    },
    {
        "id": "memory-silverstone-2026",
        "race": "British Grand Prix 2026",
        "circuit": "Silverstone Circuit",
        "date": "2026-07-05",
        "lap": 39,
        "situation": "Rain cell accelerated while Battery SOC was being reserved for restart defense.",
        "ai_recommendation": "Safety Car Recharge",
        "human_decision": "Approved",
        "race_engineer_decision": "Approved",
        "final_outcome": "Battery SOC recovered enough to defend the first restart attack.",
        "what_went_right": "Recharge plan protected Boost Button availability.",
        "what_went_wrong": "Weather uncertainty weighting was still too conservative.",
        "lesson_learned": "Increase weather uncertainty weighting when radar velocity is unstable and Battery SOC is marginal.",
        "tags": ["rain", "battery-soc", "boost-defense"],
        "similar_scenario": "Austrian GP lap 32 rain and recharge threat",
    },
    {
        "id": "memory-hungary-2026",
        "race": "Hungarian Grand Prix 2026",
        "circuit": "Hungaroring",
        "date": "2026-07-19",
        "lap": 32,
        "situation": "Medium tyres were stable, but Norris opened a rival energy attack window.",
        "ai_recommendation": "Recharge before attack",
        "human_decision": "Adjusted to pit one lap earlier with Boost defense preserved",
        "race_engineer_decision": "Adjusted",
        "final_outcome": "Held podium position with stronger Battery SOC margin.",
        "what_went_right": "Race engineer override reacted to rival Overtake Mode eligibility.",
        "what_went_wrong": "AI model undervalued rival Battery SOC and pit crew readiness cues.",
        "lesson_learned": "Rival energy attack risk was higher than estimated; preserve Boost defense before committing.",
        "tags": ["rival-energy-attack", "medium-tyre", "pit-wall-adjustment"],
        "similar_scenario": "Norris Twin predicted energy attack",
    },
]

DECISIONS: list[dict] = [
    {
        "id": "decision-live-001",
        "recommendation_id": "pit-in-3",
        "state": "Under Review",
        "ai_recommendation": "Stay out until lap 35, recharge Battery SOC, and prepare Boost defense",
        "responsible_human": "M. Alvarez, Race Engineer",
        "created_at": "2026-06-21T14:08:00Z",
        "requires_human_review": True,
        "linked_simulation": "simulation-live-100k",
        "linked_agent_debate": "debate-live-lap-32",
    }
]


def log_human_decision(payload: HumanDecisionCreate) -> dict:
    now = datetime.now(timezone.utc).isoformat()
    state = {
        "Approved": "Approved",
        "Adjusted": "Adjusted",
        "Rejected": "Rejected",
    }[payload.action]
    record = {
        "id": f"decision-{len(DECISIONS) + 1:03d}",
        "recommendation_id": payload.recommendation_id,
        "state": state,
        "action": payload.action,
        "responsible_human": payload.responsible_human,
        "rationale": payload.rationale,
        "revised_strategy": payload.revised_strategy,
        "risk_tolerance": payload.risk_tolerance,
        "created_at": now,
        "requires_human_review": False,
        "requires_pit_wall_approval": False,
        "linked_simulation": "simulation-live-100k",
        "linked_agent_debate": "debate-live-lap-32",
        "battery_soc": RACE_STATE["batterySOC"],
        "boost_status": RACE_STATE["boostButton"],
        "overtake_mode_status": RACE_STATE["overtakeMode"],
        "active_aero_mode": RACE_STATE["activeAeroMode"],
        "energy_clipping_risk": RACE_STATE["energyClippingRisk"],
        "corner_entry_risk": RACE_STATE["cornerEntryRisk"],
        "tyre_thermal_load": RACE_STATE["tyreThermalLoad"],
        "memory_state": "Memory Created",
    }
    DECISIONS.append(record)
    RACE_MEMORY.insert(
        0,
        {
            "id": f"memory-decision-{len(RACE_MEMORY) + 1:03d}",
            "race": RACE_STATE["grand_prix"],
            "circuit": RACE_STATE["circuit"],
            "date": now[:10],
            "lap": RACE_STATE["lap"],
            "situation": "Live strategy recommendation reviewed by race engineer.",
            "ai_recommendation": payload.recommendation_id,
            "human_decision": payload.action,
            "race_engineer_decision": payload.action,
            "final_outcome": "Outcome tracking pending",
            "battery_soc": RACE_STATE["batterySOC"],
            "boost_status": RACE_STATE["boostButton"],
            "overtake_mode_status": RACE_STATE["overtakeMode"],
            "active_aero_mode": RACE_STATE["activeAeroMode"],
            "aero_context": "Race engineer reviewed X-Mode and Z-Mode exposure before logging.",
            "energy_clipping_risk": RACE_STATE["energyClippingRisk"],
            "corner_entry_risk": RACE_STATE["cornerEntryRisk"],
            "tyre_thermal_load": RACE_STATE["tyreThermalLoad"],
            "rival_energy_threat": RACE_STATE["rivalEnergyAttackWindow"],
            "what_went_right": "Decision passed through the required pit wall approval workflow.",
            "what_went_wrong": "Outcome not yet available.",
            "lesson_learned": payload.rationale,
            "tags": ["pit-wall-approval", "battery-soc", "active-aero", payload.action.lower(), payload.risk_tolerance.lower()],
            "similar_scenario": "Linked to live Austrian GP simulation universe",
        },
    )
    return record


def get_performance_analytics() -> dict:
    return {
        "pace_ranking": [
            {"metric": "Race pace", "rank": 3, "delta": "+0.19s"},
            {"metric": "Long-run consistency", "rank": 2, "delta": "+0.08s"},
            {"metric": "Sector 3 rotation", "rank": 1, "delta": "-0.04s"},
        ],
        "system_metrics": [
            {"name": "Battery SOC error", "value": 5, "target": 4, "lower_is_better": True},
            {"name": "Recharge accuracy", "value": 84, "target": 86},
            {"name": "Overtake Mode timing accuracy", "value": 81, "target": 83},
            {"name": "Boost defense success", "value": 76, "target": 75},
            {"name": "Active aero transition error", "value": 6, "target": 5, "lower_is_better": True},
            {"name": "Energy clipping prediction error", "value": 9, "target": 8, "lower_is_better": True},
            {"name": "Corner-entry risk accuracy", "value": 79, "target": 82},
            {"name": "Tyre thermal model accuracy", "value": 82, "target": 84},
        ],
        "energy_efficiency": [{"stint": "S1", "value": 92}, {"stint": "S2", "value": 88}, {"stint": "Projected S3", "value": 84}],
        "tyre_usage_ranking": [{"compound": "MEDIUM", "score": 82}, {"compound": "HARD", "score": 76}, {"compound": "SOFT", "score": 48}],
    }


def mission_control_summary() -> dict:
    simulation = generate_simulation()
    debate = get_agent_debate()
    rivals = get_rival_twins()
    return {
        "race_state": deepcopy(RACE_STATE),
        "drivers": deepcopy(DRIVERS),
        "threats": deepcopy(THREATS),
        "agent_consensus": deepcopy(debate["consensus"]),
        "pit_wall_approval_status": deepcopy(DECISIONS[0]),
        "simulation_preview": {
            "win_probability": simulation["win_probability"],
            "podium_probability": simulation["podium_probability"],
            "points_probability": simulation["points_probability"],
            "expected_finish": simulation["expected_finish"],
            "simulation_count": simulation["simulation_count"],
            "points": simulation["points"][:130],
        },
        "rival_twin_alerts": deepcopy(rivals),
        "telemetry": deepcopy(TELEMETRY),
        "strategy_timeline": [
            {"lap": 1, "event": "Started on medium tyre", "state": "past"},
            {"lap": 21, "event": "Battery recharge phase completed", "state": "past"},
            {"lap": 32, "event": "AI recommends recharge and Boost defense", "state": "current"},
            {"lap": 35, "event": "Primary pit and Overtake Mode window", "state": "recommended"},
            {"lap": 52, "event": "Rival tyre thermal cliff window", "state": "future"},
        ],
        "race_memory_insight": deepcopy(RACE_MEMORY[1]),
    }
