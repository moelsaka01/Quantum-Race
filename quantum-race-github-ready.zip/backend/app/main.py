from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .data import (
    ADVANCED_TELEMETRY,
    DECISIONS,
    RACE_MEMORY,
    RACE_STATE,
    TELEMETRY,
    generate_simulation,
    get_agent_debate,
    get_performance_analytics,
    get_rival_twins,
    get_strategy_recommendations,
    log_human_decision,
    mission_control_summary,
)
from .schemas import DataSourceConnectRequest, HealthResponse, HumanDecisionCreate, ScenarioInput
from .services import openf1_client

app = FastAPI(
    title="Quantum Race API",
    description="AI-powered race engineering demo API. AI recommends; pit wall approves.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok", service="quantum-race-api", human_in_the_loop=True)


@app.get("/api/mission-control")
def mission_control() -> dict:
    return mission_control_summary()


@app.get("/api/race-state")
def race_state() -> dict:
    return RACE_STATE


@app.get("/api/telemetry")
def telemetry() -> dict:
    return TELEMETRY


@app.get("/api/advanced-telemetry")
def advanced_telemetry() -> dict:
    return ADVANCED_TELEMETRY


@app.get("/api/simulations")
def simulations() -> dict:
    return generate_simulation()


@app.post("/api/scenario-simulation")
def scenario_simulation(input_data: ScenarioInput) -> dict:
    return generate_simulation(input_data)


@app.get("/api/agent-debate")
def agent_debate() -> dict:
    return get_agent_debate()


@app.get("/api/rival-twins")
def rival_twins() -> list[dict]:
    return get_rival_twins()


@app.get("/api/strategy-recommendations")
def strategy_recommendations() -> list[dict]:
    return get_strategy_recommendations()


@app.get("/api/human-decisions")
def human_decisions() -> list[dict]:
    return DECISIONS


@app.post("/api/human-decisions")
def create_human_decision(payload: HumanDecisionCreate) -> dict:
    return log_human_decision(payload)


@app.get("/api/decisions")
def decisions() -> list[dict]:
    return DECISIONS


@app.post("/api/decisions/log")
def log_pit_wall_decision(payload: HumanDecisionCreate) -> dict:
    return log_human_decision(payload)


@app.get("/api/race-memory")
def race_memory() -> list[dict]:
    return RACE_MEMORY


@app.get("/api/memory/session")
def session_memory() -> list[dict]:
    return RACE_MEMORY


@app.get("/api/performance-analytics")
def performance_analytics() -> dict:
    return get_performance_analytics()


@app.get("/api/settings")
def settings() -> dict:
    return {
        "team_profile": {"name": "Quantum Race Demo Team", "engineer": "M. Alvarez", "mode": "Research demo"},
        "agent_settings": {
            "risk_manager_required": True,
            "energy_strategist_enabled": True,
            "active_aero_engineer_enabled": True,
            "team_principal_synthesis": True,
            "race_engineer_review_threshold": 40,
        },
        "simulation_settings": {
            "default_runs": 100000,
            "weather_uncertainty": "Elevated",
            "rival_model": "2026 energy attack twin v1",
            "active_aero_model": "X-Mode/Z-Mode rule model",
            "battery_soc_model": "MGU-K recharge and Boost Button model",
        },
        "risk_tolerance": "Medium",
        "data_sources": ["Demo telemetry", "Synthetic timing feed", "2026 tactical scenario engine"],
        "model_configuration": {"agent_mode": "Rule-based", "auto_execute": False},
        "theme": "Mission Control Dark",
        "pit_wall_approval": {"required_for_strategy": True, "approve_adjust_reject": True, "memory_logging": True},
    }


@app.get("/api/data-source/status")
def data_source_status() -> dict:
    return openf1_client.get_status()


@app.post("/api/data-source/connect")
def data_source_connect(payload: DataSourceConnectRequest) -> dict:
    try:
        return openf1_client.connect(payload)
    except openf1_client.OpenF1Error as exc:
        return {
            "status": "error",
            "provider": payload.provider,
            "mode": payload.mode,
            "message": str(exc),
            "connected_state": None,
        }


@app.post("/api/data-source/disconnect")
def data_source_disconnect() -> dict:
    return openf1_client.disconnect()


@app.get("/api/openf1/sessions")
def openf1_sessions(year: int | None = None, country_name: str | None = None, session_name: str | None = None) -> list[dict]:
    return openf1_client.sessions(year=year, country_name=country_name, session_name=session_name)


@app.get("/api/openf1/latest-session")
def openf1_latest_session() -> dict:
    return openf1_client.latest_session()


@app.get("/api/openf1/drivers")
def openf1_drivers(session_key: int | str) -> list[dict]:
    return openf1_client.drivers(session_key)


@app.get("/api/openf1/telemetry")
def openf1_telemetry(session_key: int | str, driver_number: int | None = None) -> list[dict]:
    return openf1_client.telemetry(session_key, driver_number)


@app.get("/api/openf1/weather")
def openf1_weather(session_key: int | str) -> list[dict]:
    return openf1_client.weather(session_key)


@app.get("/api/openf1/positions")
def openf1_positions(session_key: int | str) -> list[dict]:
    return openf1_client.positions(session_key)


frontend_dist = Path(__file__).resolve().parents[2] / "frontend" / "dist"


@app.get("/")
def api_root():
    if frontend_dist.exists():
        return FileResponse(frontend_dist / "index.html")
    return {"message": "Quantum Race API running. Build frontend to serve the full app."}


if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")
