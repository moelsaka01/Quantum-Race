from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from time import monotonic
from typing import Any
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from ..schemas import DataSourceConnectRequest


OPENF1_BASE_URL = "https://api.openf1.org/v1"


class OpenF1Error(RuntimeError):
    pass


MOCK_SESSION = {
    "session_key": 9977,
    "meeting_key": 2026001,
    "year": 2026,
    "country_name": "Public latest session",
    "location": "OpenF1 sample feed",
    "session_name": "Latest public session",
    "date_start": "2026-06-22T00:00:00+00:00",
}

MOCK_DRIVERS = [
    {"driver_number": 44, "name_acronym": "HAM", "full_name": "Demo Driver 44"},
    {"driver_number": 1, "name_acronym": "VER", "full_name": "Demo Driver 1"},
    {"driver_number": 4, "name_acronym": "NOR", "full_name": "Demo Driver 4"},
]

MOCK_TELEMETRY = [
    {"date": "2026-06-22T00:00:01+00:00", "driver_number": 44, "speed": 294, "throttle": 86, "brake": 0, "n_gear": 7, "rpm": 11180},
    {"date": "2026-06-22T00:00:03+00:00", "driver_number": 44, "speed": 312, "throttle": 94, "brake": 0, "n_gear": 8, "rpm": 11640},
    {"date": "2026-06-22T00:00:05+00:00", "driver_number": 44, "speed": 188, "throttle": 22, "brake": 78, "n_gear": 5, "rpm": 10490},
    {"date": "2026-06-22T00:00:07+00:00", "driver_number": 44, "speed": 267, "throttle": 72, "brake": 0, "n_gear": 6, "rpm": 10920},
]

MOCK_WEATHER = [
    {"air_temperature": 24.4, "track_temperature": 31.8, "humidity": 48, "rainfall": 0, "wind_speed": 2.2}
]

MOCK_POSITIONS = [
    {"driver_number": 44, "position": 3, "date": "2026-06-22T00:00:07+00:00"},
    {"driver_number": 1, "position": 1, "date": "2026-06-22T00:00:07+00:00"},
    {"driver_number": 4, "position": 4, "date": "2026-06-22T00:00:07+00:00"},
]


@dataclass
class OpenF1Client:
    base_url: str = OPENF1_BASE_URL
    timeout: float = 4.0
    cache_ttl: float = 45.0
    _cache: dict[str, tuple[float, Any]] = field(default_factory=dict)

    def request(self, endpoint: str, params: dict[str, Any] | None = None) -> Any:
        query = f"?{urlencode({k: v for k, v in (params or {}).items() if v not in (None, '')})}" if params else ""
        url = f"{self.base_url}/{endpoint.lstrip('/')}{query}"
        cache_key = url
        cached = self._cache.get(cache_key)
        now = monotonic()
        if cached and now - cached[0] < self.cache_ttl:
            return cached[1]

        try:
            request = Request(url, headers={"User-Agent": "QuantumRace/1.0"})
            with urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (OSError, URLError, json.JSONDecodeError) as exc:
            raise OpenF1Error(str(exc)) from exc

        self._cache[cache_key] = (now, payload)
        return payload

    def sessions(self, **params: Any) -> list[dict]:
        return list(self.request("sessions", params))

    def latest_session(self) -> dict:
        sessions = self.sessions()
        if not sessions:
            raise OpenF1Error("OpenF1 returned no public sessions.")
        return sorted(sessions, key=lambda item: str(item.get("date_start", "")))[-1]

    def drivers(self, session_key: int | str) -> list[dict]:
        return list(self.request("drivers", {"session_key": session_key}))

    def telemetry(self, session_key: int | str, driver_number: int | None = None) -> list[dict]:
        params = {"session_key": session_key}
        if driver_number:
            params["driver_number"] = driver_number
        return list(self.request("car_data", params))[-120:]

    def weather(self, session_key: int | str) -> list[dict]:
        return list(self.request("weather", {"session_key": session_key}))[-60:]

    def positions(self, session_key: int | str) -> list[dict]:
        return list(self.request("position", {"session_key": session_key}))[-120:]


def _session_label(session: dict) -> str:
    year = session.get("year")
    country = session.get("country_name") or session.get("location") or "OpenF1"
    name = session.get("session_name") or "Public session"
    return f"{year} {country} - {name}".strip()


def map_connected_state(session: dict, telemetry: list[dict], weather: list[dict], positions: list[dict], drivers: list[dict], source: str) -> dict:
    latest_car = telemetry[-1] if telemetry else {}
    latest_weather = weather[-1] if weather else {}
    speed_points = [
        {
            "lap_distance": index + 1,
            "OPENF1": row.get("speed", 0) or 0,
            "Throttle": row.get("throttle", 0) or 0,
            "Brake": row.get("brake", 0) or 0,
        }
        for index, row in enumerate(telemetry[-80:])
    ]
    if not speed_points:
        speed_points = [{"lap_distance": i, "OPENF1": 0, "Throttle": 0, "Brake": 0} for i in range(1, 12)]

    return {
        "source": source,
        "source_label": "OpenF1 public data connected" if source == "openf1" else "OpenF1 mock fallback connected",
        "session": session,
        "session_label": _session_label(session),
        "drivers": drivers,
        "positions": positions,
        "weather": weather,
        "telemetry": {
            "live_strip": {
                "speed": f"{latest_car.get('speed', 'n/a')} km/h" if latest_car else "not available",
                "throttle": f"{latest_car.get('throttle', 'n/a')}%" if latest_car else "not available",
                "brake": f"{latest_car.get('brake', 'n/a')}%" if latest_car else "not available",
                "gear": str(latest_car.get("n_gear", "not available")),
                "rpm": str(latest_car.get("rpm", "not available")),
                "data_source": "OpenF1 public/historical",
                "active_aero_mode": "Synthetic 2026 overlay only",
                "battery_soc": "not available from source",
            },
            "speed_trace": speed_points,
        },
        "weather_summary": {
            "air_temperature": latest_weather.get("air_temperature", "not available"),
            "track_temperature": latest_weather.get("track_temperature", "not available"),
            "humidity": latest_weather.get("humidity", "not available"),
            "rainfall": latest_weather.get("rainfall", "not available"),
            "wind_speed": latest_weather.get("wind_speed", "not available"),
        },
        "notice": "2026 tactical simulation layer remains synthetic unless connected data provides matching fields.",
    }


client = OpenF1Client()
DATA_SOURCE_STATE: dict[str, Any] = {
    "status": "disconnected",
    "provider": None,
    "mode": None,
    "session": None,
    "connected_at": None,
    "message": "No data source connected.",
    "connected_state": None,
}


def get_status() -> dict:
    return DATA_SOURCE_STATE.copy()


def disconnect() -> dict:
    DATA_SOURCE_STATE.update(
        {
            "status": "disconnected",
            "provider": None,
            "mode": None,
            "session": None,
            "connected_at": None,
            "message": "Data source disconnected.",
            "connected_state": None,
        }
    )
    return get_status()


def connect(payload: DataSourceConnectRequest) -> dict:
    if payload.mode == "realtime_subscription" and not os.getenv("OPENF1_TOKEN"):
        raise OpenF1Error("Real-time OpenF1 mode requires a subscription token. Use public historical/latest mode without a token.")

    source = "openf1"
    try:
        if payload.session == "latest":
            session = client.latest_session()
        else:
            sessions = client.sessions(year=payload.year, country_name=payload.country_name, session_name=payload.session_name)
            session = sessions[0] if sessions else client.latest_session()
        session_key = session["session_key"]
        drivers = client.drivers(session_key)
        driver_number = payload.driver_number or (drivers[0].get("driver_number") if drivers else None)
        telemetry = client.telemetry(session_key, driver_number)
        weather = client.weather(session_key)
        positions = client.positions(session_key)
        message = "OpenF1 public data connected."
    except OpenF1Error as exc:
        if not payload.allow_mock_fallback:
            raise
        source = "mock_fallback"
        session = MOCK_SESSION
        drivers = MOCK_DRIVERS
        telemetry = MOCK_TELEMETRY
        weather = MOCK_WEATHER
        positions = MOCK_POSITIONS
        message = f"OpenF1 unavailable; using structured mock fallback. Reason: {exc}"

    connected_state = map_connected_state(session, telemetry, weather, positions, drivers, source)
    DATA_SOURCE_STATE.update(
        {
            "status": "connected",
            "provider": "openf1",
            "mode": payload.mode,
            "session": session,
            "connected_at": datetime.now(timezone.utc).isoformat(),
            "message": message,
            "realtime_available": bool(os.getenv("OPENF1_TOKEN")),
            "connected_state": connected_state,
        }
    )
    return get_status()


def latest_session(allow_mock_fallback: bool = True) -> dict:
    try:
        return client.latest_session()
    except OpenF1Error:
        if allow_mock_fallback:
            return MOCK_SESSION
        raise


def sessions(**params: Any) -> list[dict]:
    try:
        return client.sessions(**params)
    except OpenF1Error:
        return [MOCK_SESSION]


def drivers(session_key: int | str) -> list[dict]:
    try:
        return client.drivers(session_key)
    except OpenF1Error:
        return MOCK_DRIVERS


def telemetry(session_key: int | str, driver_number: int | None = None) -> list[dict]:
    try:
        return client.telemetry(session_key, driver_number)
    except OpenF1Error:
        return MOCK_TELEMETRY


def weather(session_key: int | str) -> list[dict]:
    try:
        return client.weather(session_key)
    except OpenF1Error:
        return MOCK_WEATHER


def positions(session_key: int | str) -> list[dict]:
    try:
        return client.positions(session_key)
    except OpenF1Error:
        return MOCK_POSITIONS
