from fastapi.testclient import TestClient

from app.main import app
from app.services import openf1_client


client = TestClient(app)


def test_health_endpoint_reports_human_in_loop():
    response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["human_in_the_loop"] is True


def test_simulation_probabilities_stay_in_range():
    response = client.post(
        "/api/scenario-simulation",
        json={
            "pit_lap": 37,
            "tyre_compound": "HARD",
            "rain_probability": 72,
            "safety_car_probability": 44,
            "recharge_aggression": 6,
            "push_level": 8,
            "rival_pit_behavior": "aggressive",
            "track_temperature": 35.1,
            "battery_soc": 58,
            "superclip_exposure": 4.2,
            "corner_entry_risk": 72,
            "tyre_thermal_load": 76,
            "active_aero_mode": "Transition",
        },
    )
    assert response.status_code == 200
    body = response.json()
    for key in ["win_probability", "podium_probability", "points_probability", "risk_score"]:
        assert 0 <= body[key] <= 100
    assert body["simulation_count"] == 100000
    assert body["outcome_clusters"]
    assert body["battery_soc"] == 58
    assert body["active_aero_mode"] == "Transition"


def test_agent_outputs_include_team_principal_human_review():
    response = client.get("/api/agent-debate")
    assert response.status_code == 200
    body = response.json()
    assert len(body["agents"]) >= 10
    principal = body["consensus"]
    assert principal["name"] == "Team Principal Agent"
    assert principal["requires_human_review"] is True
    assert principal["requires_pit_wall_approval"] is True
    assert principal["stance"] == "Requires Race Engineer Review"
    assert any(agent["name"] == "Energy Strategist" for agent in body["agents"])
    assert any(agent["name"] == "Active Aero Engineer" for agent in body["agents"])


def test_strategy_recommendations_require_human_decision():
    response = client.get("/api/strategy-recommendations")
    assert response.status_code == 200
    strategies = response.json()
    assert len(strategies) >= 9
    assert all(strategy["requires_human_decision"] for strategy in strategies)
    assert all(strategy["requires_pit_wall_approval"] for strategy in strategies)
    assert any(strategy["name"] == "Pit in 3 laps after recharge" for strategy in strategies)
    assert any(strategy["name"] == "Cover rival energy attack" for strategy in strategies)
    assert all("Battery SOC" in strategy["explanation"] or strategy["id"] != "pit-in-3" for strategy in strategies)


def test_human_decision_logging_creates_memory_entry():
    before = client.get("/api/race-memory").json()
    response = client.post(
        "/api/human-decisions",
        json={
            "recommendation_id": "pit-in-3",
            "action": "Adjusted",
            "responsible_human": "M. Alvarez, Race Engineer",
            "rationale": "Approve the pit window but move one lap earlier to cover Norris.",
            "revised_strategy": "Recharge lap 33, pit lap 35, preserve Boost for defense.",
            "risk_tolerance": "Medium",
        },
    )
    assert response.status_code == 200
    decision = response.json()
    assert decision["state"] == "Adjusted"
    assert decision["memory_state"] == "Memory Created"
    after = client.get("/api/race-memory").json()
    assert len(after) == len(before) + 1
    assert after[0]["human_decision"] == "Adjusted"
    assert after[0]["race_engineer_decision"] == "Adjusted"
    assert after[0]["battery_soc"] == 63
    assert "active-aero" in after[0]["tags"]


def test_2026_race_state_and_rival_models_expose_tactical_fields():
    race_state = client.get("/api/race-state").json()
    assert race_state["ruleset"] == "2026 Ruleset Active"
    assert race_state["activeAeroMode"] == "Z-Mode"
    assert race_state["batterySOC"] == 63
    assert race_state["boostButton"] == "available"

    rivals = client.get("/api/rival-twins").json()
    assert all("energy_attack_threat" in twin for twin in rivals)
    assert all("rival_battery_soc" in twin for twin in rivals)
    assert all("x_mode_efficiency" in twin for twin in rivals)


def test_data_source_status_and_openf1_connect_are_structured(monkeypatch):
    openf1_client.disconnect()
    monkeypatch.setattr(
        openf1_client.client,
        "latest_session",
        lambda: {
            "session_key": 12345,
            "meeting_key": 987,
            "year": 2026,
            "country_name": "OpenF1 Sample",
            "location": "Public API",
            "session_name": "Practice",
            "date_start": "2026-06-22T00:00:00+00:00",
        },
    )
    monkeypatch.setattr(openf1_client.client, "drivers", lambda session_key: [{"driver_number": 44, "name_acronym": "HAM"}])
    monkeypatch.setattr(
        openf1_client.client,
        "telemetry",
        lambda session_key, driver_number=None: [
            {"speed": 298, "throttle": 88, "brake": 0, "n_gear": 7, "rpm": 11150},
            {"speed": 314, "throttle": 96, "brake": 0, "n_gear": 8, "rpm": 11620},
        ],
    )
    monkeypatch.setattr(
        openf1_client.client,
        "weather",
        lambda session_key: [{"air_temperature": 25.0, "track_temperature": 33.4, "humidity": 47, "rainfall": 0, "wind_speed": 2.1}],
    )
    monkeypatch.setattr(openf1_client.client, "positions", lambda session_key: [{"driver_number": 44, "position": 3}])

    status = client.get("/api/data-source/status").json()
    assert status["status"] == "disconnected"

    response = client.post(
        "/api/data-source/connect",
        json={"provider": "openf1", "mode": "public_historical", "session": "latest", "driver_number": 44, "allow_mock_fallback": False},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "connected"
    assert body["provider"] == "openf1"
    assert body["connected_state"]["source_label"] == "OpenF1 public data connected"
    assert body["connected_state"]["telemetry"]["live_strip"]["speed"] == "314 km/h"
    assert "Austrian GP" not in body["connected_state"]["session_label"]

    disconnect = client.post("/api/data-source/disconnect")
    assert disconnect.status_code == 200
    assert disconnect.json()["status"] == "disconnected"


def test_realtime_openf1_without_token_returns_graceful_error(monkeypatch):
    monkeypatch.delenv("OPENF1_TOKEN", raising=False)
    response = client.post(
        "/api/data-source/connect",
        json={"provider": "openf1", "mode": "realtime_subscription", "session": "latest", "allow_mock_fallback": False},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "error"
    assert "subscription token" in body["message"]


def test_decision_logging_requires_rationale():
    response = client.post(
        "/api/decisions/log",
        json={
            "recommendation_id": "pit-in-3",
            "action": "Approved",
            "responsible_human": "M. Alvarez, Race Engineer",
            "rationale": "",
            "risk_tolerance": "Medium",
        },
    )
    assert response.status_code == 422
