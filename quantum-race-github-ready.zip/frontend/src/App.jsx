import React, { useEffect, useMemo, useState } from "react";
import Shell, { navigation } from "./layout/Shell.jsx";
import CommandDeck from "./pages/CommandDeck.jsx";
import MissionControl from "./pages/MissionControl.jsx";
import RaceCommand from "./pages/RaceCommand.jsx";
import RealTimeData from "./pages/RealTimeData.jsx";
import AdvancedTelemetry from "./pages/AdvancedTelemetry.jsx";
import SimulationUniversePage from "./pages/SimulationUniversePage.jsx";
import ScenarioExplorer from "./pages/ScenarioExplorer.jsx";
import AgentDebateArena from "./pages/AgentDebateArena.jsx";
import RivalTwinCommand from "./pages/RivalTwinCommand.jsx";
import StrategyRecommendations from "./pages/StrategyRecommendations.jsx";
import PitWallApproval from "./pages/PitWallApproval.jsx";
import RaceMemoryTimeline from "./pages/RaceMemoryTimeline.jsx";
import PerformanceAnalytics from "./pages/PerformanceAnalytics.jsx";
import SettingsPage from "./pages/SettingsPage.jsx";
import DataSourceModal from "./components/data-source/DataSourceModal.jsx";
import { raceState, strategyOptions } from "./data/demoData.js";
import { postJson } from "./services/api.js";

const STORAGE_KEYS = {
  decisions: "quantum-race-decisions",
  memory: "quantum-race-session-memory"
};

const defaultDemoStrategy = strategyOptions.find((strategy) => strategy.id === "pit-in-3") ?? strategyOptions[0];

const pages = {
  "command-deck": CommandDeck,
  mission: MissionControl,
  "race-command": RaceCommand,
  "real-time": RealTimeData,
  advanced: AdvancedTelemetry,
  simulation: SimulationUniversePage,
  scenario: ScenarioExplorer,
  debate: AgentDebateArena,
  rivals: RivalTwinCommand,
  strategy: StrategyRecommendations,
  decision: PitWallApproval,
  memory: RaceMemoryTimeline,
  analytics: PerformanceAnalytics,
  settings: SettingsPage
};

const pageKeys = new Set(Object.keys(pages));

function routeFromHash() {
  const hash = window.location.hash.replace(/^#\/?/, "");
  return pageKeys.has(hash) ? hash : "command-deck";
}

function readStorage(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    if (value === null || value === undefined) {
      window.localStorage.removeItem(key);
      return;
    }
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // LocalStorage is a convenience only; the demo still works without it.
  }
}

function buildApprovalPayload(strategy, source = "Strategy Recommendations", context = {}) {
  const now = new Date().toISOString();
  const isConnectedSource = context.mode === "connected";
  return {
    id: strategy.id ?? `strategy-${Date.now()}`,
    name: strategy.name ?? strategy.recommendation ?? "Pit in 3 laps",
    source,
    aiRecommendation: strategy.name ?? strategy.recommendation ?? "Pit in 3 laps",
    explanation: strategy.explanation ?? "Race strategy requires race engineer authorization before logging.",
    riskLevel: strategy.risk_level ?? strategy.riskLevel ?? "High",
    winProbability: strategy.win_probability ?? 22,
    podiumProbability: strategy.podium_probability ?? 66,
    simulationSupport: strategy.simulation_support ?? 82,
    batterySOC: strategy.batterySOC ?? raceState.batterySOC,
    batterySOCTrend: strategy.batterySOCTrend ?? raceState.batterySOCTrend,
    boostButton: strategy.boostButton ?? raceState.boostButton,
    overtakeMode: strategy.overtakeMode ?? raceState.overtakeMode,
    activeAeroMode: strategy.activeAeroMode ?? raceState.activeAeroMode,
    xModeAvailable: strategy.xModeAvailable ?? raceState.xModeAvailable,
    zModeStability: strategy.zModeStability ?? raceState.zModeStability,
    rechargeMode: strategy.rechargeMode ?? raceState.rechargeMode,
    mguKDeployment: strategy.mguKDeployment ?? raceState.mguKDeployment,
    superclipDuration: strategy.superclipDuration ?? raceState.superclipDuration,
    energyClippingRisk: strategy.energyClippingRisk ?? raceState.energyClippingRisk,
    cornerEntryRisk: strategy.cornerEntryRisk ?? raceState.cornerEntryRisk,
    tyreThermalLoad: strategy.tyreThermalLoad ?? raceState.tyreThermalLoad,
    rivalEnergyAttackWindow: strategy.rivalEnergyAttackWindow ?? raceState.rivalEnergyAttackWindow,
    activeAeroRisk: strategy.active_aero_risk ?? strategy.activeAeroRisk ?? 55,
    batterySOCImpact: strategy.battery_soc_impact ?? strategy.batterySOCImpact ?? 63,
    boostRequirement: strategy.boost_requirement ?? strategy.boostRequirement ?? 55,
    rechargeRequirement: strategy.recharge_requirement ?? strategy.rechargeRequirement ?? 35,
    linkedSimulationId: strategy.linkedSimulationId ?? (isConnectedSource ? "openf1-source-no-simulation-run" : "simulation-demo-100k-lap-32"),
    linkedAgentDebateId: strategy.linkedAgentDebateId ?? (isConnectedSource ? "openf1-source-no-agent-debate" : "debate-demo-lap-32"),
    responsibleEngineer: context.responsibleEngineer ?? raceState.race_engineer,
    sessionId: context.sessionId ?? "austrian-gp-2026-demo-lap-32",
    decisionId: `decision-${strategy.id ?? "demo"}-${Date.now()}`,
    createdAt: now,
    status: "Strategy under race engineer review"
  };
}

function buildMemoryEntry(decision) {
  const connectedSourceDecision = String(decision.sessionId ?? "").startsWith("openf1-");
  return {
    id: `memory-session-${Date.now()}`,
    race: connectedSourceDecision ? "OpenF1 Connected Source Review" : raceState.grand_prix,
    circuit: connectedSourceDecision ? "Source session" : raceState.circuit,
    date: decision.timestamp.slice(0, 10),
    lap: connectedSourceDecision ? "n/a" : raceState.lap,
    situation: connectedSourceDecision
      ? "Race engineer reviewed a strategy payload created while OpenF1 public source data was connected."
      : "Race engineer reviewed a 2026 energy, active aero, and tyre thermal strategy recommendation in the Austrian GP demo.",
    selected_strategy: decision.selectedStrategy,
    ai_recommendation: decision.aiRecommendation,
    race_engineer_decision: decision.action,
    final_outcome: "Outcome tracking pending in demo replay.",
    rationale: decision.rationale,
    risk_level: decision.riskLevel,
    battery_soc: decision.batterySOC,
    battery_soc_trend: decision.batterySOCTrend,
    boost_status: decision.boostButton,
    overtake_mode_status: decision.overtakeMode,
    active_aero_mode: decision.activeAeroMode,
    aero_context: `X-Mode ${decision.xModeAvailable ? "available" : "unavailable"}; Z-Mode stability ${decision.zModeStability}%.`,
    energy_clipping_risk: decision.energyClippingRisk,
    corner_entry_risk: decision.cornerEntryRisk,
    tyre_thermal_load: decision.tyreThermalLoad,
    rival_energy_threat: decision.rivalEnergyAttackWindow,
    timestamp: decision.timestamp,
    lesson_learned: "Lesson placeholder: review Battery SOC, Boost defense, and corner-entry outcome before promoting this memory.",
    tags: ["pit-wall-approval", "battery-soc", "active-aero", decision.action.toLowerCase(), decision.riskLevel.toLowerCase()],
    similar_scenario: connectedSourceDecision ? "Linked to OpenF1 connected-source session" : "Linked to Austrian GP 2026 lap 32 demo replay"
  };
}

export default function App() {
  const [activePage, setActivePage] = useState(routeFromHash);
  const [mode, setMode] = useState("idle");
  const [pendingApproval, setPendingApproval] = useState(null);
  const [dataSource, setDataSource] = useState(null);
  const [connectedState, setConnectedState] = useState(null);
  const [dataSourceModalOpen, setDataSourceModalOpen] = useState(false);
  const [dataSourceLoading, setDataSourceLoading] = useState(false);
  const [dataSourceError, setDataSourceError] = useState("");
  const [decisions, setDecisions] = useState(() => readStorage(STORAGE_KEYS.decisions, []));
  const [sessionMemory, setSessionMemory] = useState(() => readStorage(STORAGE_KEYS.memory, []));
  const Page = pages[activePage] ?? MissionControl;
  const pageTitle = useMemo(() => navigation.find((item) => item.key === activePage)?.title ?? "Mission Control", [activePage]);

  useEffect(() => {
    const onHashChange = () => setActivePage(routeFromHash());
    window.addEventListener("hashchange", onHashChange);
    window.addEventListener("popstate", onHashChange);
    return () => {
      window.removeEventListener("hashchange", onHashChange);
      window.removeEventListener("popstate", onHashChange);
    };
  }, []);

  useEffect(() => {
    document.title = `${pageTitle} | Quantum Race`;
  }, [pageTitle]);

  const navigate = (key) => {
    const route = pageKeys.has(key) ? key : "command-deck";
    setActivePage(route);
    if (window.location.hash !== `#/${route}`) {
      window.history.pushState(null, "", `#/${route}`);
    }
  };

  const runDemo = () => {
    setMode("demo");
    setDataSource(null);
    setConnectedState(null);
    setDataSourceModalOpen(false);
    setDataSourceError("");
    if (!pendingApproval) {
      const approval = buildApprovalPayload(defaultDemoStrategy, "Austrian GP 2026 Demo");
      setPendingApproval(approval);
    }
  };

  const resetDemo = () => {
    setMode("idle");
    setPendingApproval(null);
    setDataSource(null);
    setConnectedState(null);
    setDataSourceError("");
  };

  const openDataSourceModal = () => {
    setDataSourceError("");
    setDataSourceModalOpen(true);
  };

  const connectDataSource = async (payload) => {
    setDataSourceLoading(true);
    setDataSourceError("");
    try {
      const response = await postJson("/api/data-source/connect", payload);
      if (response.status !== "connected") {
        setDataSourceError(response.message ?? "OpenF1 connection failed. Please retry.");
        return response;
      }
      setMode("connected");
      setPendingApproval(null);
      setDataSource(response);
      setConnectedState(response.connected_state);
      setDataSourceModalOpen(false);
      return response;
    } catch (error) {
      setDataSourceError(error.message ?? "OpenF1 connection failed. Please retry.");
      return { status: "error", message: error.message };
    } finally {
      setDataSourceLoading(false);
    }
  };

  const disconnectDataSource = async () => {
    try {
      await postJson("/api/data-source/disconnect", {});
    } catch {
      // Local UI state still returns to standby if the server disconnect call fails.
    }
    setMode("idle");
    setPendingApproval(null);
    setDataSource(null);
    setConnectedState(null);
    setDataSourceError("");
  };

  const clearLocalDecisions = () => {
    setDecisions([]);
    setSessionMemory([]);
    writeStorage(STORAGE_KEYS.decisions, []);
    writeStorage(STORAGE_KEYS.memory, []);
  };

  const submitStrategy = (strategy, source) => {
    const connectedSessionKey = connectedState?.session?.session_key ?? "public-session";
    const approval = buildApprovalPayload(
      strategy,
      source,
      mode === "connected"
        ? {
            mode: "connected",
            sessionId: `openf1-${connectedSessionKey}`,
            responsibleEngineer: "Race Engineer"
          }
        : {}
    );
    setMode((currentMode) => (currentMode === "connected" ? "connected" : "demo"));
    setPendingApproval(approval);
    return approval;
  };

  const logDecision = (decision) => {
    const timestamp = new Date().toISOString();
    const record = {
      ...decision,
      id: `decision-session-${Date.now()}`,
      timestamp,
      memoryState: "Race Memory Updated",
      state: "Strategy Logged"
    };
    const memory = buildMemoryEntry(record);
    const nextDecisions = [record, ...decisions];
    const nextMemory = [memory, ...sessionMemory];
    setDecisions(nextDecisions);
    setSessionMemory(nextMemory);
    const nextApproval = pendingApproval ? { ...pendingApproval, status: "Decision logged. Race Memory updated.", completedAt: timestamp } : null;
    setPendingApproval(nextApproval);
    writeStorage(STORAGE_KEYS.decisions, nextDecisions);
    writeStorage(STORAGE_KEYS.memory, nextMemory);
    return record;
  };

  const appState = {
    mode,
    dataSource,
    connectedState,
    pendingApproval,
    decisions,
    sessionMemory,
    isDemo: mode === "demo",
    isConnected: mode === "connected",
    isIdle: mode === "idle"
  };

  const appActions = {
    runDemo,
    resetDemo,
    openDataSourceModal,
    connectDataSource,
    disconnectDataSource,
    clearLocalDecisions,
    submitStrategy,
    logDecision
  };

  return (
    <>
      <Shell activePage={activePage} onNavigate={navigate} pageTitle={pageTitle} appState={appState} appActions={appActions}>
        <Page onNavigate={navigate} appState={appState} appActions={appActions} />
      </Shell>
      {dataSourceModalOpen && (
        <DataSourceModal
          error={dataSourceError}
          loading={dataSourceLoading}
          onCancel={() => setDataSourceModalOpen(false)}
          onConnect={connectDataSource}
        />
      )}
    </>
  );
}

