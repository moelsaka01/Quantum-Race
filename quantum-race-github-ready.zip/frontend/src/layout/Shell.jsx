import React from "react";
import {
  Activity,
  BarChart3,
  Bot,
  BrainCircuit,
  CalendarClock,
  Command,
  Cpu,
  Gauge,
  GitBranch,
  History,
  Map,
  RadioTower,
  Settings,
  ShieldAlert,
  UserCheck,
  Waves
} from "lucide-react";
import StatusPill from "../components/cards/StatusPill.jsx";
import { raceState } from "../data/demoData.js";

export const navigation = [
  { key: "command-deck", label: "Command Deck", title: "Quantum Race Command Deck", icon: Command },
  { key: "mission", label: "Mission Control", title: "Mission Control", icon: Command },
  { key: "race-command", label: "Race Command", title: "Race Command", icon: RadioTower },
  { key: "real-time", label: "Real-Time Data", title: "Real-Time Data", icon: Activity },
  { key: "advanced", label: "Advanced Telemetry", title: "Advanced Telemetry", icon: Gauge },
  { key: "simulation", label: "Simulation Universe", title: "Simulation Universe Explorer", icon: BrainCircuit },
  { key: "scenario", label: "Scenario Explorer", title: "Scenario Explorer", icon: GitBranch },
  { key: "debate", label: "Agent Debate Arena", title: "Agent Debate Arena", icon: Bot },
  { key: "rivals", label: "Rival Twin Command", title: "Rival Twin Command Center", icon: ShieldAlert },
  { key: "strategy", label: "Strategy Recommendations", title: "Strategy Recommendations", icon: Map },
  { key: "decision", label: "Pit Wall Approval", title: "Race Engineer Approval", icon: UserCheck },
  { key: "memory", label: "Race Memory Timeline", title: "Race Memory Timeline", icon: History },
  { key: "analytics", label: "Performance Analytics", title: "Performance Analytics", icon: BarChart3 },
  { key: "settings", label: "Settings", title: "Settings", icon: Settings }
];

export default function Shell({ activePage, onNavigate, pageTitle, children, appState, appActions }) {
  const isDemo = appState?.mode === "demo";
  const isConnected = appState?.mode === "connected";
  const sourceSession = appState?.connectedState?.session_label ?? "OpenF1 public session";
  const modeLabel = isDemo ? "2026 RULESET ACTIVE" : isConnected ? "OPENF1 DATA CONNECTED" : "NO LIVE 2026 RACE DATA CONNECTED";
  const sessionLabel = isDemo ? raceState.grand_prix : isConnected ? sourceSession : "No live race session";
  const telemetryStatus = isDemo ? "Demo | Connected" : isConnected ? "OpenF1 | Public" : "Offline | Standby";

  return (
    <div className={`mission-shell mode-${isDemo ? "demo" : isConnected ? "connected" : "idle"}`}>
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">QR</div>
          <div>
            <strong>Quantum <span>Race</span></strong>
            <small>AI-powered race engineering</small>
          </div>
        </div>
        <nav className="nav-list" aria-label="Main navigation">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                aria-current={activePage === item.key ? "page" : undefined}
                className={activePage === item.key ? "active" : ""}
                data-route={item.key}
                type="button"
                onClick={() => onNavigate(item.key)}
                key={item.key}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
        <section className="session-panel">
          <p className="eyebrow">Session</p>
          <h3>{sessionLabel}</h3>
          <div className="session-grid">
            <span><b>{isDemo ? "Lap" : isConnected ? "Source" : "Feed"}</b>{isDemo ? `${raceState.lap} / ${raceState.total_laps}` : isConnected ? "OpenF1" : "None"}</span>
            <span><b>{isDemo ? "Race Time" : isConnected ? "Mode" : "Simulation"}</b>{isDemo ? "1:08:32" : isConnected ? "Public" : "Standby"}</span>
            <span><b>Track Temp</b>{isDemo ? `${raceState.track_temperature}C` : isConnected ? `${appState?.connectedState?.weather_summary?.track_temperature ?? "n/a"}C` : "--"}</span>
            <span><b>Air Temp</b>{isDemo ? `${raceState.air_temperature}C` : isConnected ? `${appState?.connectedState?.weather_summary?.air_temperature ?? "n/a"}C` : "--"}</span>
            <span><b>{isDemo ? "Battery SOC" : isConnected ? "Overlay" : "Agents"}</b>{isDemo ? `${raceState.batterySOC}%` : isConnected ? "Synthetic" : "Idle"}</span>
            <span><b>{isDemo ? "Active Aero" : isConnected ? "Realtime" : "Queue"}</b>{isDemo ? raceState.activeAeroMode : isConnected ? "Token req." : "Empty"}</span>
          </div>
          <StatusPill tone={isDemo || isConnected ? "success" : "warning"}>{telemetryStatus}</StatusPill>
        </section>
        <div className="sidebar-speedlines" />
      </aside>
      <main className="main-stage">
        <header className="topbar">
          <div>
            <p className="eyebrow">Quantum Race Mission Platform</p>
            <h1>{pageTitle}</h1>
          </div>
          <div className="topbar-metrics">
            <span><Cpu size={16} /> {isDemo ? `${raceState.batterySOC}%` : isConnected ? "OpenF1" : "Idle"} <small>{isDemo ? "Battery SOC" : isConnected ? "Source" : "Agents"}</small></span>
            <span><Waves size={16} /> {isDemo ? raceState.activeAeroMode : isConnected ? "Synthetic overlay" : "Standby"} <small>{isDemo ? "Active Aero" : "2026 Layer"}</small></span>
            <span><CalendarClock size={16} /> {isDemo ? raceState.overtakeMode.replaceAll("_", " ") : isConnected ? "Historical/latest" : "Offline"} <small>{isDemo ? "Overtake Mode" : "Feed"}</small></span>
            <StatusPill tone={isDemo ? "danger" : isConnected ? "success" : "warning"}>{modeLabel}</StatusPill>
            {isDemo && (
              <button className="topbar-reset" type="button" onClick={appActions?.resetDemo}>Reset Demo</button>
            )}
            {isConnected && (
              <button className="topbar-reset" type="button" onClick={appActions?.disconnectDataSource}>Disconnect</button>
            )}
          </div>
        </header>
        {children}
        <footer className="mission-footer">
          <span>AI RECOMMENDS.</span>
          <strong>PIT WALL APPROVES.</strong>
          <span>Demo research platform. No affiliation with Formula 1, FIA, or any team.</span>
        </footer>
      </main>
    </div>
  );
}

