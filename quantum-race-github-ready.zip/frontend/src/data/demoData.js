const makeSpeedTrace = () =>
  Array.from({ length: 60 }, (_, index) => {
    const i = index + 1;
    const brakingZone = [12, 13, 14, 31, 32, 48].includes(i);
    return {
      lap_distance: i,
      HAM: 286 + ((i * 23) % 92) - (brakingZone ? 70 : 0),
      VER: 292 + ((i * 19) % 84) - (brakingZone ? 64 : 0),
      NOR: 282 + ((i * 21) % 88) - (brakingZone ? 58 : 0)
    };
  });

const makeSimulationPoints = () => {
  const clusters = [
    ["Win", "#12d986", 44, 7, 70],
    ["Podium", "#f2c94c", 34, 22, 110],
    ["Points", "#2aa8ff", 30, 46, 180],
    ["No Points", "#ff3333", 20, 68, 72],
    ["Safety Car", "#ff8a1f", 70, 35, 62],
    ["Rain Outcome", "#6fe7ff", 62, 14, 70],
    ["Failed Strategy", "#d92929", 82, 72, 48]
  ];
  let seed = 42;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
  return clusters.flatMap(([cluster, color, cx, cy, count]) =>
    Array.from({ length: count }, () => ({
      cluster,
      color,
      x: Math.max(2, Math.min(98, cx + (rand() - 0.5) * 26)),
      y: Math.max(2, Math.min(98, cy + (rand() - 0.5) * 22)),
      opacity: 0.45 + rand() * 0.5
    }))
  );
};

export const raceState = {
  ruleset: "2026 Ruleset Active",
  grand_prix: "Austrian Grand Prix 2026",
  circuit: "Red Bull Ring",
  lap: 32,
  total_laps: 71,
  position: "P3",
  gap_to_leader: "+7.801",
  gap_to_rival: "+4.312 to NOR",
  driver: "HAM",
  race_phase: "Stint 2 - Pit Window Opening",
  current_sector: "Sector 3",
  tyre_compound: "MEDIUM",
  tyre_age: 12,
  fuel_remaining_laps: 18.6,
  track_temperature: 32.4,
  air_temperature: 24.7,
  rain_probability: 61,
  safety_car_risk: 31,
  last_lap: "1:08.732",
  race_engineer: "M. Alvarez",
  decision_state: "Under Review",
  activeAeroMode: "Z-Mode",
  xModeAvailable: true,
  zModeStability: 78,
  overtakeMode: "armed_next_lap",
  boostButton: "available",
  batterySOC: 63,
  batterySOCTrend: "depleting",
  rechargeMode: "balanced",
  energyClippingRisk: "medium",
  superclipDuration: 3.2,
  mguKDeployment: 350,
  boostPowerDelta: 150,
  aeroTransitionRisk: "medium",
  cornerEntryRisk: "high",
  tyreThermalLoad: 71,
  rivalEnergyAttackWindow: "Lap 34-36",
  car2026Profile: {
    narrower_car: true,
    shorter_wheelbase: true,
    lower_downforce: true,
    reduced_drag: true,
    narrower_tyres: true,
    active_aero: true
  }
};

export const drivers = [
  { pos: 1, code: "VER", driver: "Verstappen", gap: "Leader", tyre: "M", pit: "-" },
  { pos: 2, code: "LEC", driver: "Leclerc", gap: "+7.801", tyre: "M", pit: "-" },
  { pos: 3, code: "HAM", driver: "Hamilton", gap: "+7.801", tyre: "M", pit: "-" },
  { pos: 4, code: "NOR", driver: "Norris", gap: "+12.312", tyre: "M", pit: "-" },
  { pos: 5, code: "RUS", driver: "Russell", gap: "+15.981", tyre: "H", pit: "-" },
  { pos: 6, code: "PIA", driver: "Piastri", gap: "+18.732", tyre: "M", pit: "-" },
  { pos: 7, code: "SAI", driver: "Sainz", gap: "+21.456", tyre: "H", pit: "-" },
  { pos: 8, code: "OCO", driver: "Ocon", gap: "+23.873", tyre: "H", pit: "-" },
  { pos: 9, code: "ALB", driver: "Albon", gap: "+26.981", tyre: "M", pit: "-" },
  { pos: 10, code: "GAS", driver: "Gasly", gap: "+29.231", tyre: "M", pit: "-" }
];

export const threats = [
  { name: "Overtake Mode Threat", value: 87, severity: "critical" },
  { name: "Battery Depletion Risk", value: 64, severity: "warning" },
  { name: "X-Mode Straight-Line Threat", value: 69, severity: "warning" },
  { name: "Z-Mode Corner Instability", value: 46, severity: "watch" },
  { name: "Energy Clipping Risk", value: 54, severity: "warning" },
  { name: "Tyre Thermal Risk", value: 71, severity: "warning" },
  { name: "Rival Boost Defense", value: 58, severity: "watch" },
  { name: "Safety Car Recharge Opportunity", value: 31, severity: "stable" }
];

export const telemetry = {
  speed_trace: makeSpeedTrace(),
  throttle_trace: Array.from({ length: 60 }, (_, index) => {
    const i = index + 1;
    return { lap_distance: i, throttle: Math.max(0, i % 17 < 12 ? 96 - (i % 13) * 7 : 34) };
  }),
  brake_trace: Array.from({ length: 60 }, (_, index) => {
    const i = index + 1;
    return { lap_distance: i, brake: i % 17 < 11 ? 12 : 84 - (i % 6) * 9 };
  }),
  sector_times: [
    { sector: "S1", HAM: 17.92, VER: 17.78, NOR: 18.04 },
    { sector: "S2", HAM: 29.61, VER: 29.43, NOR: 29.7 },
    { sector: "S3", HAM: 21.2, VER: 21.11, NOR: 21.28 }
  ],
  lap_times: Array.from({ length: 13 }, (_, index) => {
    const lap = index + 20;
    return {
      lap,
      HAM: +(68.4 + (lap % 5) * 0.08 + ([27, 28].includes(lap) ? 0.7 : 0)).toFixed(2),
      NOR: +(68.7 + (lap % 4) * 0.06).toFixed(2)
    };
  }),
  battery_soc_trace: Array.from({ length: 14 }, (_, index) => {
    const lap = index + 20;
    return { lap, SOC: Math.max(48, 78 - index * 1.7 + (index % 4 === 0 ? 3 : 0)), recharge: 10 + (index % 5) * 4 };
  }),
  mgu_k_trace: Array.from({ length: 60 }, (_, index) => {
    const i = index + 1;
    const attackZone = i % 18 > 10 && i % 18 < 15;
    return { lap_distance: i, deployment: attackZone ? 350 : 215 + (i % 9) * 8, harvest: attackZone ? 55 : 140 + (i % 6) * 10 };
  }),
  boost_usage_timeline: Array.from({ length: 13 }, (_, index) => {
    const lap = index + 20;
    return { lap, attack: [31, 32, 34].includes(lap) ? 150 : 45 + (index % 3) * 12, defense: [33, 34, 35].includes(lap) ? 128 : 38 + (index % 4) * 10 };
  }),
  recharge_map: Array.from({ length: 13 }, (_, index) => {
    const lap = index + 20;
    return { lap, brake_recovery: 32 + (index % 5) * 5, lift_and_coast: 18 + (index % 4) * 6, superclip: 3 + (index % 4) * 0.7 };
  }),
  aero_mode_timeline: Array.from({ length: 12 }, (_, index) => ({
    segment: `S${index + 1}`,
    xMode: [2, 3, 7, 8].includes(index + 1) ? 90 : 18,
    zMode: [1, 4, 5, 6, 9, 10, 11, 12].includes(index + 1) ? 82 : 34
  })),
  corner_entry_risk_trace: Array.from({ length: 10 }, (_, index) => ({
    corner: `T${index + 1}`,
    risk: 38 + ((index * 9) % 42),
    stability: 86 - ((index * 7) % 31)
  })),
  tyre_thermal_trace: Array.from({ length: 13 }, (_, index) => {
    const lap = index + 20;
    return { lap, thermal_load: 61 + (index % 6) * 3, narrower_tyre_sensitivity: 54 + (index % 5) * 5 };
  }),
  live_strip: {
    speed: "315 km/h",
    throttle: "91%",
    brake: "12%",
    gear: "7",
    battery_soc: "63%",
    mgu_k_deployment: "350 kW",
    boost_button_status: "Available",
    overtake_mode_status: "Armed next lap",
    active_aero_mode: "Z-Mode",
    recharge_mode: "Balanced",
    superclip_duration: "3.2s/lap",
    energy_clipping_risk: "Medium",
    lap_time: "1:08.732",
    sectors: ["17.92", "29.61", "21.20"]
  }
};

export const advancedTelemetry = {
  sector_comparison: telemetry.sector_times,
  corner_speed: Array.from({ length: 10 }, (_, index) => {
    const corner = index + 1;
    return { corner: `T${corner}`, HAM: 118 + corner * 6 + (corner % 3) * 11, NOR: 116 + corner * 6 + (corner % 2) * 12 };
  }),
  brake_pressure: Array.from({ length: 10 }, (_, index) => {
    const corner = index + 1;
    return { corner: `T${corner}`, pressure: 48 + (corner * 7) % 42 };
  }),
  mgu_k_usage: Array.from({ length: 9 }, (_, index) => {
    const lap = index + 24;
    return { lap, deploy: 38 + (lap * 5) % 44, harvest: 28 + (lap * 3) % 31 };
  }),
  tyre_temperature: Array.from({ length: 9 }, (_, index) => {
    const lap = index + 24;
    return { lap, front_left: 91 + lap % 6, front_right: 94 + lap % 7, rear_left: 97 + lap % 5, rear_right: 100 + lap % 6 };
  }),
  anomalies: [
    { system: "Rear tyre surface", delta: "+3.2C", severity: "watch" },
    { system: "Energy clipping exposure", delta: "3.2s/lap", severity: "medium" },
    { system: "Brake migration", delta: "+4%", severity: "watch" },
    { system: "Active aero transition timing", delta: "+0.08s", severity: "watch" }
  ]
};

export const simulation = {
  simulation_count: 100000,
  win_probability: 22,
  podium_probability: 66,
  points_probability: 92,
  expected_finish: 3.2,
  risk_score: 43,
  best_case: "P1 if Norris burns Boost early and rain arrives after lap 44",
  worst_case: "P7 if rival energy attack succeeds and Battery SOC drops below the target band",
  points: makeSimulationPoints(),
  outcome_clusters: [
    { name: "Win", probability: 22, color: "#12d986" },
    { name: "Podium", probability: 66, color: "#f2c94c" },
    { name: "Points", probability: 92, color: "#2aa8ff" },
    { name: "No Points", probability: 8, color: "#ff3333" },
    { name: "Safety Car", probability: 31, color: "#ff8a1f" },
    { name: "Rain Outcome", probability: 61, color: "#6fe7ff" },
    { name: "Failed Strategy", probability: 43, color: "#d92929" }
  ],
  strategy_comparison: [
    { strategy: "Pit now", expected_finish: 4.4, risk: 64, support: 41 },
    { strategy: "Pit in 3 laps", expected_finish: 3.2, risk: 43, support: 82 },
    { strategy: "Extend current stint", expected_finish: 4.9, risk: 72, support: 33 },
    { strategy: "Wait for rain", expected_finish: 5.8, risk: 79, support: 24 }
  ]
};

export const agents = [
  {
    name: "Strategy Director",
    role: "Race strategy synthesis",
    recommendation: "Stay out to lap 35 and protect the energy window",
    confidence: 86,
    evidence: ["Pit window lap 33-37 is opening", "Traffic loss remains below 1.4s", "Norris energy attack window opens lap 34"],
    concern: "Pitting too early creates a battery SOC deficit in the next attack phase",
    stance: "Agree",
    risk_level: "Medium"
  },
  {
    name: "Tyre Scientist",
    role: "Tyre life and degradation",
    recommendation: "Stay out to lap 35",
    confidence: 78,
    evidence: ["Medium tyre degradation is linear", "No cliff signature in rear surface temps", "Grip drop predicted in 8 laps"],
    concern: "Lap 38 becomes high risk if track temp rises",
    stance: "Agree with caution",
    risk_level: "Medium"
  },
  {
    name: "Weather Analyst",
    role: "Weather uncertainty",
    recommendation: "Delay only if rain radar confirms lap 42 arrival",
    confidence: 69,
    evidence: ["Rain probability 61%", "Cell speed uncertainty +/- 6 minutes", "Sector 2 wind shift increasing"],
    concern: "Intermediates become viable only after lap 44",
    stance: "Partial disagreement",
    risk_level: "High"
  },
  {
    name: "Rival Analyst",
    role: "Competitor digital twins",
    recommendation: "Cover Norris energy attack window",
    confidence: 88,
    evidence: ["Norris twin predicts attack lap 34", "Rival Overtake Mode eligibility likely", "Boost defense probability is falling"],
    concern: "Norris may combine X-Mode straight speed with saved boost on lap 34",
    stance: "Agree",
    risk_level: "High"
  },
  {
    name: "Energy Strategist",
    role: "Battery SOC, Boost Button, recharge strategy, and MGU-K deployment",
    recommendation: "Delay attack by two laps to recover Battery SOC before using Overtake Mode",
    confidence: 74,
    evidence: ["Battery SOC 63%", "Battery trend depleting", "Superclip exposure 3.2s/lap", "Rival likely to attack on lap 34"],
    concern: "Attacking before recharge window may leave car exposed to Boost defense",
    stance: "Agree",
    risk_level: "Medium"
  },
  {
    name: "Active Aero Engineer",
    role: "X-Mode, Z-Mode, aero transition zones, and stability risk",
    recommendation: "Use X-Mode on the designated straight and protect Z-Mode corner exits through Sector 2",
    confidence: 80,
    evidence: ["X-Mode available next straight", "Aero transition risk medium", "Z-Mode stability 78%", "Sector 2 corner entry high risk"],
    concern: "Low-drag transition too late could destabilize corner entry",
    stance: "Agree with caution",
    risk_level: "Medium"
  },
  {
    name: "Corner Entry Analyst",
    role: "2026 narrower-car braking stability and tyre thermal load",
    recommendation: "Avoid aggressive entry into Sector 2 while tyre thermal load is above 70%",
    confidence: 77,
    evidence: ["Tyre thermal load 71%", "Lower downforce profile", "Narrower tyre model active", "Brake migration sensitivity rising"],
    concern: "Corner-entry instability risk increases if boost deployment overlaps braking phase",
    stance: "Partial disagreement",
    risk_level: "High"
  },
  {
    name: "Risk Manager",
    role: "Downside containment",
    recommendation: "Require race engineer review before committing",
    confidence: 91,
    evidence: ["Weather variance increasing", "Energy attack risk critical", "Corner entry risk high"],
    concern: "Energy and active aero downside exceeds automated threshold",
    stance: "Race engineer review required",
    risk_level: "High"
  },
  {
    name: "Performance Engineer",
    role: "Pace and vehicle performance",
    recommendation: "Stay out while sector 3 remains competitive",
    confidence: 72,
    evidence: ["S3 delta to VER is +0.09s", "Brake pressure stable", "MGU-K clipping limited to S2"],
    concern: "Rear temperatures are trending upward with narrower tyre sensitivity",
    stance: "Partial disagreement",
    risk_level: "Medium"
  },
  {
    name: "Team Principal Agent",
    role: "Consensus synthesis",
    recommendation: "Stay out to lap 35, recharge through lift-and-coast windows, prepare Boost defense against Norris, and submit Overtake Mode timing plan for Pit Wall Approval",
    confidence: 82,
    evidence: ["Race strategy, tyre, weather, rival, energy, active aero, and corner-entry models attached", "Battery SOC 63%", "Simulation support strongest for lap 35 energy defense"],
    concern: "Rival energy attack and Z-Mode corner-entry risk create a narrow decision window",
    stance: "Requires Race Engineer Review",
    risk_level: "High",
    consensus_recommendation: "Stay out to lap 35, recharge, defend with Boost",
    disagreement_summary: "Energy and active aero agents want two recharge laps; rival model warns Norris can attack earlier.",
    risk_explanation: "Stay out until Lap 35, recharge Battery SOC, defend with Boost if Norris enters the Overtake Mode window. Requires Pit Wall Approval.",
    requires_pit_wall_approval: true
  }
];

export const rivalTwins = [
  {
    name: "Verstappen Twin",
    team: "Redline Racing",
    position: "P1",
    predicted_pit_lap: 36,
    tyre_age: 13,
    tyre_degradation_estimate: "0.061s/lap",
    pace_trend: "Stable high pace",
    sector_strengths: ["S1 traction", "T3 exit"],
    sector_weaknesses: ["S2 tyre temperature"],
    energy_attack_threat: 87,
    long_stint_threat: 42,
    rival_battery_soc: 72,
    rival_soc_trend: "stable",
    overtake_mode_eligibility: "available",
    boost_availability: "defense",
    x_mode_efficiency: 86,
    z_mode_cornering_strength: 81,
    recharge_behavior: "balanced harvest",
    superclip_exposure: 2.4,
    likely_energy_attack_lap: 35,
    likely_boost_defense_lap: 34,
    corner_entry_weakness: "S2 tyre temperature",
    tyre_thermal_sensitivity: 66,
    likely_tyre_choice: "HARD",
    strategy_likelihood: "Battery Offset Advantage",
    final_position_probability: { P1: 68, P2: 24, P3: 8 },
    confidence: 89
  },
  {
    name: "Norris Twin",
    team: "Papaya Dynamics",
    position: "P4",
    predicted_pit_lap: 34,
    tyre_age: 12,
    tyre_degradation_estimate: "0.047s/lap",
    pace_trend: "Improving in clean air",
    sector_strengths: ["S2 minimum speed", "X-Mode straight efficiency"],
    sector_weaknesses: ["S1 braking"],
    energy_attack_threat: 62,
    long_stint_threat: 39,
    rival_battery_soc: 68,
    rival_soc_trend: "charging",
    overtake_mode_eligibility: "eligible",
    boost_availability: "attack",
    x_mode_efficiency: 88,
    z_mode_cornering_strength: 72,
    recharge_behavior: "lift-and-coast recharge",
    superclip_exposure: 3.6,
    likely_energy_attack_lap: 34,
    likely_boost_defense_lap: 35,
    corner_entry_weakness: "S1 braking",
    tyre_thermal_sensitivity: 74,
    likely_tyre_choice: "HARD",
    strategy_likelihood: "Norris Energy Attack Window",
    final_position_probability: { P2: 21, P3: 37, P4: 42 },
    confidence: 84
  },
  {
    name: "Leclerc Twin",
    team: "Scuderia Rosso",
    position: "P2",
    predicted_pit_lap: 35,
    tyre_age: 12,
    tyre_degradation_estimate: "0.052s/lap",
    pace_trend: "Small rear-limited fade",
    sector_strengths: ["S3 rotation", "Wet transition"],
    sector_weaknesses: ["T4 traction"],
    energy_attack_threat: 41,
    long_stint_threat: 55,
    rival_battery_soc: 61,
    rival_soc_trend: "depleting",
    overtake_mode_eligibility: "armed_next_lap",
    boost_availability: "saving",
    x_mode_efficiency: 78,
    z_mode_cornering_strength: 84,
    recharge_behavior: "brake recovery",
    superclip_exposure: 3.1,
    likely_energy_attack_lap: 36,
    likely_boost_defense_lap: 34,
    corner_entry_weakness: "T4 traction",
    tyre_thermal_sensitivity: 69,
    likely_tyre_choice: "HARD",
    strategy_likelihood: "Z-Mode Corner Protection",
    final_position_probability: { P1: 18, P2: 52, P3: 30 },
    confidence: 80
  },
  {
    name: "Russell Twin",
    team: "Silver Arrow Lab",
    position: "P5",
    predicted_pit_lap: 38,
    tyre_age: 8,
    tyre_degradation_estimate: "0.039s/lap",
    pace_trend: "Late-stint recovery",
    sector_strengths: ["Recharge efficiency", "S3 consistency"],
    sector_weaknesses: ["S1 straightline"],
    energy_attack_threat: 28,
    long_stint_threat: 58,
    rival_battery_soc: 75,
    rival_soc_trend: "charging",
    overtake_mode_eligibility: "unavailable",
    boost_availability: "defense",
    x_mode_efficiency: 67,
    z_mode_cornering_strength: 79,
    recharge_behavior: "safety car recharge bias",
    superclip_exposure: 1.8,
    likely_energy_attack_lap: 38,
    likely_boost_defense_lap: 36,
    corner_entry_weakness: "S1 straightline",
    tyre_thermal_sensitivity: 58,
    likely_tyre_choice: "MEDIUM",
    strategy_likelihood: "Recharge Behavior",
    final_position_probability: { P3: 12, P4: 31, P5: 57 },
    confidence: 76
  }
];

export const strategyOptions = [
  ["pit-now", "Pit now before energy deficit compounds", 4.4, 61, 18, 51, "High", 62, 46, 78, 68, 41, 58, 72, 41, "Stops the track-position loss but risks leaving the car short on Battery SOC for the next Overtake Mode phase."],
  ["pit-in-3", "Pit in 3 laps after recharge", 3.2, 82, 22, 66, "Medium", 71, 34, 42, 55, 84, 28, 48, 82, "Best balance between tyre life, Battery SOC recovery, and Boost defense against Norris."],
  ["recharge-attack", "Recharge before attack", 3.4, 79, 21, 64, "Medium", 76, 24, 36, 42, 80, 18, 43, 86, "Lift-and-coast for two laps, recover Battery SOC, then arm Overtake Mode with Boost Button available."],
  ["defend-boost", "Defend with Boost", 3.7, 74, 19, 61, "Medium", 60, 28, 38, 62, 77, 32, 47, 78, "Hold track position if Norris attacks with Overtake Mode by preserving Boost for lap 34-35 defense."],
  ["arm-overtake", "Arm Overtake Mode", 3.5, 73, 20, 60, "High", 58, 40, 44, 69, 73, 46, 56, 72, "Prepare an Overtake Mode attack only after confirming X-Mode straight-line phase and Battery SOC margin."],
  ["x-mode-offset", "Use X-Mode straight-line offset", 3.6, 70, 19, 58, "Medium", 63, 25, 39, 52, 71, 34, 50, 76, "Exploit X-Mode Straight-Line Phase on the main straight without compromising Z-Mode corner exits."],
  ["z-mode-protect", "Protect Z-Mode corner exits", 3.8, 69, 17, 58, "Medium", 66, 22, 37, 49, 70, 24, 42, 79, "Prioritize Z-Mode stability through Sector 2 while tyre thermal load remains above 70%."],
  ["safety-recharge", "Harvest under Safety Car", 4.2, 58, 14, 49, "Medium", 81, 12, 35, 41, 57, 14, 35, 65, "Use a caution phase to recharge Battery SOC and reset Boost availability before the final stint."],
  ["cover-energy-attack", "Cover rival energy attack", 3.6, 74, 20, 61, "Medium", 64, 33, 44, 66, 78, 38, 54, 77, "Counters Norris Energy Attack Window with Boost defense and conservative corner-entry deployment."],
  ["conservative-entry", "Reduce corner-entry risk with conservative deployment", 4.0, 67, 16, 56, "High", 68, 20, 47, 43, 69, 26, 63, 74, "Avoid boost overlap into braking zones while tyre thermal load and lower-downforce sensitivity are elevated."]
].map(([id, name, expected_finish, probability_of_success, win_probability, podium_probability, risk_level, battery_soc_impact, recharge_requirement, boost_requirement, active_aero_risk, simulation_support, energy_clipping_risk, corner_entry_risk, tyre_thermal_risk, explanation]) => ({
  id,
  name,
  expected_finish,
  probability_of_success,
  win_probability,
  podium_probability,
  risk_level,
  battery_soc_impact,
  recharge_requirement,
  boost_requirement,
  overtake_mode_relevance: id.includes("overtake") || id.includes("attack") ? 88 : 62,
  active_aero_risk,
  energy_clipping_risk,
  tyre_thermal_risk,
  corner_entry_risk,
  tyre_risk: tyre_thermal_risk,
  rival_risk: boost_requirement,
  weather_risk: active_aero_risk,
  simulation_support,
  explanation,
  requires_pit_wall_approval: true,
  batterySOC: raceState.batterySOC,
  batterySOCTrend: raceState.batterySOCTrend,
  boostButton: raceState.boostButton,
  overtakeMode: raceState.overtakeMode,
  activeAeroMode: raceState.activeAeroMode,
  xModeAvailable: raceState.xModeAvailable,
  zModeStability: raceState.zModeStability,
  rechargeMode: raceState.rechargeMode,
  mguKDeployment: raceState.mguKDeployment,
  superclipDuration: raceState.superclipDuration,
  energyClippingRisk: raceState.energyClippingRisk,
  cornerEntryRisk: raceState.cornerEntryRisk,
  tyreThermalLoad: raceState.tyreThermalLoad,
  rivalEnergyAttackWindow: raceState.rivalEnergyAttackWindow,
  action: "Submit to Pit Wall Approval"
}));

export const raceMemory = [
  {
    id: "memory-austria-2026",
    race: "Austrian Grand Prix 2026",
    circuit: "Red Bull Ring",
    date: "2026-06-21",
    lap: 34,
    situation: "Battery SOC was marginal before a rival Overtake Mode attack window.",
    ai_recommendation: "Recharge before attack",
    race_engineer_decision: "Approved",
    final_outcome: "Boost defense margin improved before the attack phase.",
    battery_soc: 59,
    boost_status: "defense",
    overtake_mode_status: "armed_next_lap",
    active_aero_mode: "Z-Mode",
    aero_context: "X-Mode delayed until main straight; Z-Mode protected through Sector 2.",
    energy_clipping_risk: "medium",
    corner_entry_risk: "high",
    tyre_thermal_load: 73,
    rival_energy_threat: "Norris Energy Attack Window",
    lesson_learned: "Battery SOC was too low to attack immediately; delaying two laps improved Boost defense margin.",
    tags: ["battery-soc", "boost-defense", "pit-wall-approval"],
    similar_scenario: "Austrian GP lap 32 energy defense"
  },
  {
    id: "memory-barcelona-2026",
    race: "Barcelona Grand Prix 2026",
    circuit: "Circuit de Barcelona-Catalunya",
    date: "2026-05-31",
    lap: 27,
    situation: "Long-corner Z-Mode instability pushed tyre thermal load above the target band.",
    ai_recommendation: "Protect Z-Mode corner exits",
    race_engineer_decision: "Adjusted",
    final_outcome: "Conservative corner-entry deployment improved stint life.",
    battery_soc: 66,
    boost_status: "saving",
    overtake_mode_status: "eligible",
    active_aero_mode: "Z-Mode",
    aero_context: "Z-Mode stability prioritized over X-Mode straight-line gain.",
    energy_clipping_risk: "low",
    corner_entry_risk: "high",
    tyre_thermal_load: 76,
    rival_energy_threat: "Leclerc boost defense",
    lesson_learned: "Z-Mode instability through long corners increased tyre thermal load; conservative corner-entry deployment improved stint life.",
    tags: ["z-mode", "corner-entry", "tyre-thermal"],
    similar_scenario: "Sector 2 corner-entry instability"
  },
  {
    id: "memory-monaco-2026",
    race: "Monaco Grand Prix 2026",
    circuit: "Circuit de Monaco",
    date: "2026-05-24",
    lap: 42,
    situation: "Short straights limited X-Mode benefit while track position remained decisive.",
    ai_recommendation: "Use X-Mode straight-line offset",
    race_engineer_decision: "Rejected",
    final_outcome: "Track position outweighed energy attack potential.",
    battery_soc: 71,
    boost_status: "available",
    overtake_mode_status: "eligible",
    active_aero_mode: "Transition",
    aero_context: "X-Mode gain limited by short straights; Z-Mode stability protected traction.",
    energy_clipping_risk: "low",
    corner_entry_risk: "medium",
    tyre_thermal_load: 64,
    rival_energy_threat: "Low",
    lesson_learned: "X-Mode benefit was limited by short straights; track position outweighed energy attack potential.",
    tags: ["x-mode", "track-position", "low-drag-limited"],
    similar_scenario: "Low straight-line energy gain"
  }
];

export const performanceAnalytics = {
  pace_ranking: [
    { metric: "Race pace", rank: 3, delta: "+0.19s" },
    { metric: "Long-run consistency", rank: 2, delta: "+0.08s" },
    { metric: "Sector 3 rotation", rank: 1, delta: "-0.04s" }
  ],
  system_metrics: [
    { name: "Strategy accuracy", value: 78, target: 80 },
    { name: "Simulation accuracy", value: 84, target: 85 },
    { name: "Agent accuracy", value: 81, target: 82 },
    { name: "Decision success rate", value: 76, target: 75 },
    { name: "Battery SOC prediction error", value: 8, target: 6, lower_is_better: true },
    { name: "Recharge model accuracy", value: 83, target: 84 },
    { name: "Overtake Mode recommendation accuracy", value: 79, target: 81 },
    { name: "Boost defense success rate", value: 74, target: 76 },
    { name: "Active aero transition accuracy", value: 81, target: 83 },
    { name: "Energy clipping prediction error", value: 9, target: 7, lower_is_better: true },
    { name: "Corner-entry risk prediction error", value: 10, target: 8, lower_is_better: true },
    { name: "Tyre thermal model accuracy", value: 82, target: 84 },
    { name: "Pit Wall approval rate", value: 68, target: 60 },
    { name: "Pit Wall rejection rate", value: 12, target: 18, lower_is_better: true }
  ],
  energy_efficiency: [
    { stint: "S1", value: 88 },
    { stint: "S2", value: 82 },
    { stint: "Projected S3", value: 79 }
  ],
  tyre_usage_ranking: [
    { compound: "MEDIUM", score: 82 },
    { compound: "HARD", score: 76 },
    { compound: "SOFT", score: 48 }
  ]
};

export const strategyTimeline = [
  { lap: 1, event: "Started on medium tyre", state: "past" },
  { lap: 21, event: "Battery SOC reset after safety car recharge", state: "past" },
  { lap: 32, event: "AI recommends recharge and defend with Boost", state: "current" },
  { lap: 35, event: "Primary pit and Overtake Mode timing window", state: "recommended" },
  { lap: 52, event: "Rival energy attack tail and tyre thermal window", state: "future" }
];
