import React from "react";
import MetricCard from "../components/cards/MetricCard.jsx";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { raceState, telemetry } from "../data/demoData.js";

export default function RealTimeData({ appState, appActions }) {
  if (appState?.isConnected) {
    const connected = appState.connectedState ?? {};
    const sourceLabel = connected.source_label ?? "OpenF1 public data connected";
    const sessionLabel = connected.session_label ?? "OpenF1 latest public session";
    const liveStrip = connected.telemetry?.live_strip ?? {};
    const speedTrace = connected.telemetry?.speed_trace ?? [];
    const weather = connected.weather_summary ?? {};

    return (
      <div className="page-stack connected-telemetry-page">
        <section className="panel page-intro connected-source-intro">
          <div>
            <p className="eyebrow">Connected Telemetry</p>
            <h2>OpenF1 Public Data Feed</h2>
            <p>{sessionLabel}</p>
          </div>
          <div className="connected-source-actions">
            <span className="system-tag">{sourceLabel}</span>
            <button className="outline-button compact-button" type="button" onClick={appActions?.disconnectDataSource}>Disconnect Source</button>
          </div>
        </section>
        <section className="telemetry-strip">
          {Object.entries(liveStrip).map(([key, value]) => (
            <MetricCard label={key.replaceAll("_", " ")} value={String(value)} key={key} accent={key === "brake" ? "yellow" : key === "data_source" ? "blue" : "red"} />
          ))}
        </section>
        <div className="two-column">
          <section className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">OpenF1 Source Trace</p>
                <h2>Speed / Throttle / Brake</h2>
              </div>
              <span className="system-tag">Public latest/historical</span>
            </div>
            <TelemetryChart
              data={speedTrace}
              series={[
                { key: "OPENF1", color: "#ff3333" },
                { key: "Throttle", color: "#12d986" },
                { key: "Brake", color: "#f2c94c" }
              ]}
              height={290}
            />
          </section>
          <section className="panel connected-boundary-panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Data Boundary</p>
                <h2>Source Fields vs 2026 Tactical Layer</h2>
              </div>
              <span className="system-tag">No Austrian GP demo labels</span>
            </div>
            <p>{connected.notice ?? "Connected OpenF1 data is separated from the synthetic 2026 tactical model."}</p>
            <div className="summary-grid tall">
              <span><b>{weather.air_temperature ?? "n/a"}</b> air temperature</span>
              <span><b>{weather.track_temperature ?? "n/a"}</b> track temperature</span>
              <span><b>{weather.humidity ?? "n/a"}</b> humidity</span>
              <span><b>{weather.rainfall ?? "n/a"}</b> rainfall</span>
              <span><b>{weather.wind_speed ?? "n/a"}</b> wind speed</span>
              <span><b>{connected.session?.session_key ?? "n/a"}</b> session key</span>
            </div>
          </section>
        </div>
      </div>
    );
  }

  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow="Telemetry Standby"
        title="No Live 2026 Telemetry Connected"
        body="The oscilloscope grid is dormant because no live speed, brake, throttle, Battery SOC, MGU-K, Boost, or Active Aero stream is connected."
        bullets={["Speed trace dormant", "Battery SOC unavailable", "MGU-K deployment idle", "Active Aero timeline offline"]}
        onPrimary={appActions?.runDemo}
      />
    );
  }

  return (
    <div className="page-stack">
      <section className="telemetry-strip">
        {Object.entries(telemetry.live_strip).filter(([key]) => key !== "sectors").map(([key, value]) => (
          <MetricCard label={key.replace("_", " ")} value={value} key={key} accent={key === "brake" ? "yellow" : "red"} />
        ))}
      </section>
      <div className="two-column">
        <section className="panel">
          <div className="panel-header"><h2>Speed Trace</h2></div>
          <TelemetryChart data={telemetry.speed_trace} series={[{ key: "HAM", color: "#ff3333" }, { key: "VER", color: "#5394ff" }, { key: "NOR", color: "#ff8a1f" }]} height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Battery SOC Trend</h2></div>
          <TelemetryChart data={telemetry.battery_soc_trace} xKey="lap" series={[{ key: "SOC", color: "#12d986" }, { key: "recharge", color: "#2aa8ff" }]} type="area" height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>MGU-K Deployment Trace</h2></div>
          <TelemetryChart data={telemetry.mgu_k_trace} series={[{ key: "deployment", color: "#ff3333" }, { key: "harvest", color: "#12d986" }]} type="area" height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Boost Usage Timeline</h2></div>
          <TelemetryChart data={telemetry.boost_usage_timeline} xKey="lap" series={[{ key: "attack", color: "#ff3333" }, { key: "defense", color: "#f2c94c" }]} type="bar" height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Recharge Map</h2></div>
          <TelemetryChart data={telemetry.recharge_map} xKey="lap" series={[{ key: "brake_recovery", color: "#2aa8ff" }, { key: "lift_and_coast", color: "#12d986" }, { key: "superclip", color: "#ff8a1f" }]} height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>X-Mode / Z-Mode State Timeline</h2></div>
          <TelemetryChart data={telemetry.aero_mode_timeline} xKey="segment" series={[{ key: "xMode", color: "#6fe7ff" }, { key: "zMode", color: "#f2c94c" }]} type="bar" height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Corner-Entry Risk Trace</h2></div>
          <TelemetryChart data={telemetry.corner_entry_risk_trace} xKey="corner" series={[{ key: "risk", color: "#ff3333" }, { key: "stability", color: "#12d986" }]} height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Tyre Thermal Load Trace</h2></div>
          <TelemetryChart data={telemetry.tyre_thermal_trace} xKey="lap" series={[{ key: "thermal_load", color: "#f2c94c" }, { key: "narrower_tyre_sensitivity", color: "#ff8a1f" }]} type="area" height={260} />
        </section>
      </div>
      <div className="three-column">
        {[
          ["Active Aero Mode", raceState.activeAeroMode, "X-Mode available next straight"],
          ["Battery SOC", `${raceState.batterySOC}%`, `${raceState.batterySOCTrend} with ${raceState.rechargeMode} recharge`],
          ["Energy Clipping Risk", raceState.energyClippingRisk, `${raceState.superclipDuration}s/lap superclip exposure`],
          ["Weather Feed", `${raceState.rain_probability}% rain`, "Cell arrival lap 44-50"],
          ["Rival Feed", "Norris energy attack", raceState.rivalEnergyAttackWindow]
        ].map(([title, value, text]) => (
          <section className="panel" key={title}>
            <p className="eyebrow">{title}</p>
            <h2>{value}</h2>
            <p>{text}</p>
          </section>
        ))}
      </div>
    </div>
  );
}

