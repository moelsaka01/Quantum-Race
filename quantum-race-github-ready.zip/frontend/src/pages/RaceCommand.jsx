import React from "react";
import MetricCard from "../components/cards/MetricCard.jsx";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import TrackPanel from "../components/telemetry/TrackPanel.jsx";
import { drivers, raceState, rivalTwins, strategyTimeline, telemetry } from "../data/demoData.js";

export default function RaceCommand({ appState, appActions }) {
  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Race Command Standby"}
        title={appState?.isConnected ? "No 2026 Race Command Model Loaded" : "No Active Race Session"}
        body={appState?.isConnected
          ? "OpenF1 source data is connected, but the race command model is not running the Austrian GP demo. Use Real-Time Data for source telemetry or run the demo for the 2026 tactical surface."
          : "Race Command has no timing feed, no gap table, and no pit-window model loaded. Run the demo to populate the command surface."}
        bullets={["No 2026 lap state", "No Battery SOC stream", "No energy attack window", "Pit wall queue empty"]}
        primaryLabel="Run Austrian GP 2026 Demo"
        onPrimary={appActions?.runDemo}
      />
    );
  }

  return (
    <div className="page-stack">
      <section className="metric-grid">
        <MetricCard label="Active Aero State" value={raceState.activeAeroMode} subvalue="X-Mode / Z-Mode operational" />
        <MetricCard label="Pit Window" value="Lap 33-37" subvalue="Primary lap 35" accent="yellow" />
        <MetricCard label="Battery SOC" value={`${raceState.batterySOC}%`} subvalue={raceState.batterySOCTrend} accent="green" />
        <MetricCard label="Boost Availability" value={raceState.boostButton} subvalue={`Overtake ${raceState.overtakeMode}`} accent="blue" />
        <MetricCard label="Corner Entry Risk" value={raceState.cornerEntryRisk} subvalue={`${raceState.tyreThermalLoad}% tyre thermal`} />
      </section>
      <div className="two-third-grid">
        <TrackPanel drivers={drivers} compact />
        <section className="panel">
          <div className="panel-header"><h2>Rival Gap Table</h2></div>
          <div className="data-table">
            {rivalTwins.map((twin) => (
              <div className="data-row" key={twin.name}>
                <span>{twin.position}</span>
                <strong>{twin.name}</strong>
                <span>Energy attack lap {twin.likely_energy_attack_lap}</span>
                <b>{twin.rival_battery_soc}% rival SOC</b>
              </div>
            ))}
          </div>
        </section>
      </div>
      <div className="three-column">
        <section className="panel">
          <div className="panel-header compact"><h2>Lap-by-Lap Pace</h2></div>
          <TelemetryChart data={telemetry.lap_times} xKey="lap" series={[{ key: "HAM", color: "#ff3333" }, { key: "NOR", color: "#ff8a1f" }]} />
        </section>
        <section className="panel">
          <div className="panel-header compact"><h2>Live Strategy Timeline with Energy Events</h2></div>
          <div className="vertical-events">
            {strategyTimeline.map((item) => (
              <span className={item.state} key={item.event}><b>Lap {item.lap}</b>{item.event}</span>
            ))}
          </div>
        </section>
        <section className="panel">
          <div className="panel-header compact"><h2>Pit Wall State</h2></div>
          <div className="summary-grid tall">
            <span><b>{raceState.position}</b> current position</span>
            <span><b>{raceState.gap_to_leader}</b> leader gap</span>
            <span><b>{raceState.tyre_compound}</b> compound</span>
            <span><b>{raceState.rivalEnergyAttackWindow}</b> rival energy gap</span>
            <span><b>{raceState.mguKDeployment} kW</b> MGU-K deployment</span>
            <span><b>{raceState.energyClippingRisk}</b> energy clipping risk</span>
          </div>
        </section>
      </div>
    </div>
  );
}

