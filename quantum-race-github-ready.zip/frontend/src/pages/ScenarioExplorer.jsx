import React, { useMemo, useState } from "react";
import MetricCard from "../components/cards/MetricCard.jsx";
import RiskBadge from "../components/cards/RiskBadge.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";

const clamp = (value) => Math.max(0, Math.min(100, Math.round(value)));

export default function ScenarioExplorer({ onNavigate, appState, appActions }) {
  const [scenario, setScenario] = useState({
    pitLap: 35,
    tyreCompound: "MEDIUM",
    rain: 61,
    safetyCar: 31,
    rechargeAggression: 4,
    push: 6,
    rivalBehavior: "aggressive",
    trackTemp: 32,
    batterySOC: 63,
    boostAvailable: 1,
    overtakeMode: 1,
    activeAeroMode: "Z-Mode",
    rechargeMode: "balanced",
    superclipExposure: 3,
    cornerEntryRisk: 58,
    tyreThermalLoad: 71
  });

  const output = useMemo(() => {
    const pitDelta = Math.abs(scenario.pitLap - 35);
    const compoundBonus = { SOFT: 2, MEDIUM: 4, HARD: 1, INTERMEDIATE: 3, WET: -3 }[scenario.tyreCompound];
    const rivalPenalty = scenario.rivalBehavior === "aggressive" ? 7 : scenario.rivalBehavior === "balanced" ? 3 : 0;
    const energyPenalty = Math.max(0, Math.max(0, 68 - scenario.batterySOC) * 0.7 + scenario.superclipExposure * 2.2 - scenario.rechargeAggression * 0.8);
    const aeroPenalty = scenario.activeAeroMode === "Transition" ? 8 : scenario.activeAeroMode === "X-Mode" ? 4 : 0;
    const risk = clamp(scenario.rain * 0.2 + scenario.safetyCar * 0.24 + pitDelta * 5 + scenario.push * 2.4 + rivalPenalty + energyPenalty + scenario.cornerEntryRisk * 0.22 + scenario.tyreThermalLoad * 0.18 + aeroPenalty);
    const win = clamp(22 + compoundBonus + (5 - pitDelta) * 1.2 + scenario.push * 0.45 - energyPenalty * 0.22 - rivalPenalty * 0.25 + scenario.boostAvailable * 2);
    const podium = clamp(63 + compoundBonus + (5 - pitDelta) * 1.6 + scenario.push * 0.7 - risk * 0.16 + scenario.overtakeMode * 2);
    return {
      win,
      podium,
      expected: Math.max(1, Math.min(10, (1 + (100 - podium) / 17 + risk / 55).toFixed(1))),
      risk,
      energyRisk: clamp(energyPenalty * 3.8),
      aeroRisk: clamp(28 + aeroPenalty * 5 + (scenario.activeAeroMode === "Z-Mode" ? 8 : 14)),
      cornerRisk: scenario.cornerEntryRisk,
      batteryImpact: clamp(scenario.batterySOC - 63),
      strategy: scenario.batterySOC < 58 ? "Recharge before attack" : pitDelta <= 2 ? "Pit in primary window with Boost defense" : "Cover rival energy attack",
      reaction: risk > 70 ? "Risk Manager escalates to race engineer review" : "Agents keep recommendation under review"
    };
  }, [scenario]);

  const update = (key, value) => setScenario((current) => ({ ...current, [key]: value }));

  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Scenario Explorer Standby"}
        title="Load a Race State Before Exploring Scenarios"
        body={appState?.isConnected
          ? "OpenF1 source data is connected, but the 2026 scenario controls need a tactical baseline. Run the demo to explore pit, energy, aero, and rival response scenarios."
          : "Scenario controls are locked until Quantum Race has a baseline race state to simulate against."}
        bullets={["No pit-lap baseline", "No Battery SOC baseline", "No active aero model", "No decision payload"]}
        onPrimary={appActions?.runDemo}
      />
    );
  }

  const submitScenario = () => {
    appActions?.submitStrategy(
      {
        id: `scenario-pit-lap-${scenario.pitLap}`,
        name: output.strategy,
        explanation: `${output.reaction}. Pit lap ${scenario.pitLap}, ${scenario.tyreCompound}, rain ${scenario.rain}%, safety car ${scenario.safetyCar}%.`,
        risk_level: output.risk > 70 ? "Critical" : output.risk > 50 ? "High" : "Medium",
        win_probability: output.win,
        podium_probability: output.podium,
        simulation_support: Math.max(10, 100 - output.risk),
        batterySOC: scenario.batterySOC,
        rechargeMode: scenario.rechargeMode,
        activeAeroMode: scenario.activeAeroMode,
        superclipDuration: scenario.superclipExposure,
        cornerEntryRisk: output.cornerRisk > 70 ? "high" : "medium",
        tyreThermalLoad: scenario.tyreThermalLoad
      },
      "Scenario Explorer"
    );
    onNavigate("decision");
  };

  return (
    <div className="page-stack">
      <section className="metric-grid">
        <MetricCard label="Updated Win Probability" value={`${output.win}%`} accent="green" />
        <MetricCard label="Updated Podium Probability" value={`${output.podium}%`} accent="yellow" />
        <MetricCard label="Expected Finish" value={`P${output.expected}`} />
        <MetricCard label="Risk Level" value={`${output.risk}%`} subvalue={output.reaction} />
      </section>
      <div className="two-column scenario-layout">
        <section className="panel controls-panel">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Scenario Explorer</p>
              <h2>Race Assumption Controls</h2>
            </div>
            <RiskBadge level={output.risk > 70 ? "High" : "Medium"} />
          </div>
          {[
            ["pitLap", "Pit lap", 1, 71],
            ["rain", "Rain probability", 0, 100],
            ["safetyCar", "Safety car probability", 0, 100],
            ["rechargeAggression", "Recharge aggression", 0, 10],
            ["push", "Push level", 0, 10],
            ["trackTemp", "Track temperature", 0, 70],
            ["batterySOC", "Battery SOC", 0, 100],
            ["superclipExposure", "Superclip exposure", 0, 8],
            ["cornerEntryRisk", "Corner-entry risk", 0, 100],
            ["tyreThermalLoad", "Tyre thermal load", 0, 100]
          ].map(([key, label, min, max]) => (
            <label className="range-control" key={key}>
              <span>{label}<b>{scenario[key]}</b></span>
              <input type="range" min={min} max={max} value={scenario[key]} onChange={(event) => update(key, Number(event.target.value))} />
            </label>
          ))}
          <label>
            Tyre compound
            <select value={scenario.tyreCompound} onChange={(event) => update("tyreCompound", event.target.value)}>
              <option>SOFT</option>
              <option>MEDIUM</option>
              <option>HARD</option>
              <option>INTERMEDIATE</option>
              <option>WET</option>
            </select>
          </label>
          <label>
            Rival energy attack behavior
            <select value={scenario.rivalBehavior} onChange={(event) => update("rivalBehavior", event.target.value)}>
              <option value="conservative">conservative</option>
              <option value="balanced">balanced</option>
              <option value="aggressive">aggressive</option>
            </select>
          </label>
          <label>
            Active Aero Mode
            <select value={scenario.activeAeroMode} onChange={(event) => update("activeAeroMode", event.target.value)}>
              <option>Z-Mode</option>
              <option>X-Mode</option>
              <option>Transition</option>
            </select>
          </label>
          <label>
            Recharge Mode
            <select value={scenario.rechargeMode} onChange={(event) => update("rechargeMode", event.target.value)}>
              <option value="balanced">balanced</option>
              <option value="lift_and_coast">lift_and_coast</option>
              <option value="brake_recovery">brake_recovery</option>
              <option value="superclip">superclip</option>
              <option value="safety_car_recharge">safety_car_recharge</option>
            </select>
          </label>
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Scenario Output</h2></div>
          <div className="decision-evidence large">
            <p className="eyebrow">Recommended Strategy</p>
            <h3>{output.strategy}</h3>
            <p>{output.reaction}. Race engineer approval required before the strategy is logged.</p>
            <div className="summary-grid tall">
              <span><b>{output.win}%</b> win probability</span>
              <span><b>{output.podium}%</b> podium probability</span>
              <span><b>P{output.expected}</b> expected finish</span>
              <span><b>{output.risk}%</b> risk score</span>
              <span><b>{output.batteryImpact >= 0 ? "+" : ""}{output.batteryImpact}%</b> Battery SOC impact</span>
              <span><b>{output.energyRisk}%</b> energy clipping risk</span>
              <span><b>{output.aeroRisk}%</b> active aero risk</span>
              <span><b>{output.cornerRisk}%</b> corner-entry risk</span>
            </div>
            <button className="primary-button" type="button" onClick={submitScenario}>Submit Scenario to Pit Wall Approval</button>
          </div>
        </section>
      </div>
    </div>
  );
}

