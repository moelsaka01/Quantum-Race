import React from "react";
import StrategyCard from "../components/strategy/StrategyCard.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { strategyOptions } from "../data/demoData.js";

export default function StrategyRecommendations({ onNavigate, appState, appActions }) {
  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Strategy Engine Standby"}
        title="No Strategy Recommendation Generated"
        body={appState?.isConnected
          ? "OpenF1 public data is connected, but no 2026 tactical recommendation has been generated. Run the demo to create strategy cards and Pit Wall Approval payloads."
          : "There is no live 2026 race state for the strategy engine to evaluate. Run the Austrian GP 2026 demo to generate energy, active aero, and pit wall recommendations."}
        bullets={["No pit window", "No Battery SOC model", "No rival energy trigger", "No approval payload"]}
        onPrimary={appActions?.runDemo}
      />
    );
  }

  const sendToApproval = (strategy) => {
    appActions?.submitStrategy(strategy, "Strategy Recommendations");
    onNavigate("decision");
  };

  return (
    <div className="page-stack">
      <section className="panel page-intro">
        <div>
          <p className="eyebrow">Strategy Recommendations</p>
          <h2>Compare 2026 Active Aero and Energy Strategy Options</h2>
          <p>Every option is a recommendation only. A race engineer must approve, adjust, or reject before it becomes a logged decision.</p>
        </div>
      </section>
      <section className="strategy-grid">
        {strategyOptions.map((strategy) => (
          <StrategyCard strategy={strategy} onSend={sendToApproval} key={strategy.id} />
        ))}
      </section>
    </div>
  );
}

