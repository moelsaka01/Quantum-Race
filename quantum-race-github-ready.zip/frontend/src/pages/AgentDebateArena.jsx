import React from "react";
import AgentCard from "../components/agents/AgentCard.jsx";
import StatusPill from "../components/cards/StatusPill.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { agents } from "../data/demoData.js";

export default function AgentDebateArena({ onNavigate, appState, appActions }) {
  const principal = agents[agents.length - 1];

  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Agent Network Standby"}
        title="AI Agents Idle"
        body={appState?.isConnected
          ? "OpenF1 source data is connected, but the 2026 agent debate layer is idle until a tactical race state is loaded. AI recommendations remain advisory only."
          : "No race state is loaded, so strategy, tyre, weather, rival, energy, active aero, corner-entry, risk, and performance agents are not debating."}
        bullets={["No consensus", "No disagreement map", "No evidence bundle", "No approval handoff"]}
        primaryLabel="Start Demo Debate"
        onPrimary={appActions?.runDemo}
      />
    );
  }

  const submitConsensus = () => {
    appActions?.submitStrategy(
      {
        id: "agent-consensus-stay-out",
        name: principal.recommendation,
        explanation: principal.risk_explanation,
        risk_level: principal.risk_level,
        win_probability: 22,
        podium_probability: 66,
        simulation_support: principal.confidence,
        batterySOC: 63,
        overtakeMode: "armed_next_lap",
        boostButton: "available",
        activeAeroMode: "Z-Mode",
        energyClippingRisk: "medium",
        cornerEntryRisk: "high",
        tyreThermalLoad: 71
      },
      "Agent Debate Arena"
    );
    onNavigate("decision");
  };

  return (
    <div className="page-stack debate-page">
      <section className="panel debate-hero">
        <div>
          <p className="eyebrow">Agent Debate Arena</p>
          <h2>AI Race Engineering Team Deliberation</h2>
          <p>Strategy, tyre, weather, rival, energy, active aero, corner-entry, risk, and performance agents are aligned on a recommendation that still requires race engineer review.</p>
        </div>
        <div className="debate-score">
          <span>Agreement</span>
          <strong>82%</strong>
          <StatusPill tone="warning">2 disagreements</StatusPill>
        </div>
      </section>
      <section className="agent-grid">
        {agents.slice(0, -1).map((agent) => (
          <AgentCard agent={agent} key={agent.name} />
        ))}
      </section>
      <section className="panel consensus-panel">
        <AgentCard agent={principal} prominent />
        <div className="consensus-copy">
          <p className="eyebrow">Final Output</p>
          <h2>{principal.consensus_recommendation}</h2>
          <p>{principal.disagreement_summary}</p>
          <p>{principal.risk_explanation}</p>
          <StatusPill tone="danger">Requires Pit Wall Approval</StatusPill>
          <button className="primary-button" type="button" onClick={submitConsensus}>Submit to Pit Wall Approval</button>
        </div>
      </section>
    </div>
  );
}

