import React from "react";
import AgentCard from "../components/agents/AgentCard.jsx";
import DecisionPanel from "../components/decisions/DecisionPanel.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import StrategyCard from "../components/strategy/StrategyCard.jsx";
import { agents, simulation, strategyOptions } from "../data/demoData.js";

export default function PitWallApproval({ onNavigate, appState, appActions }) {
  if (!appState?.pendingApproval) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Pit Wall Approval Standby"}
        title="No Recommendation Awaiting Pit Wall Approval"
        body={appState?.isConnected
          ? "OpenF1 public data is connected, but no strategy has been submitted for race engineer review. AI recommendations remain advisory and cannot be logged without approval."
          : "The approval queue is empty because no live race session or demo strategy is active. Race Memory remains available, but there is no current strategy to authorize."}
        bullets={["Approval queue empty", "No linked simulation", "No linked agent debate", "No decision payload"]}
        primaryLabel="Run Demo Scenario"
        onPrimary={appActions?.runDemo}
      />
    );
  }

  const sendToApproval = (strategy) => {
    appActions?.submitStrategy(strategy, "Race Engineer Approval");
    onNavigate("decision");
  };

  return (
    <div className="page-stack">
      <DecisionPanel pendingApproval={appState?.pendingApproval} loggedDecisions={appState?.decisions} onLogDecision={appActions?.logDecision} />
      <div className="two-column">
        <section className="panel">
          <div className="panel-header"><h2>Simulation Evidence</h2></div>
          <div className="summary-grid tall">
            <span><b>{simulation.win_probability}%</b> win probability</span>
            <span><b>{simulation.podium_probability}%</b> podium probability</span>
            <span><b>{simulation.points_probability}%</b> points probability</span>
            <span><b>{simulation.risk_score}%</b> risk score</span>
          </div>
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Agent Debate Evidence</h2></div>
          <AgentCard agent={agents[agents.length - 1]} prominent />
        </section>
      </div>
      <section className="strategy-grid compact">
        {strategyOptions.slice(0, 3).map((strategy) => (
          <StrategyCard strategy={strategy} onSend={sendToApproval} key={strategy.id} />
        ))}
      </section>
    </div>
  );
}

