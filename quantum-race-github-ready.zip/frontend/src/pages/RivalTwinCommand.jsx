import React, { useState } from "react";
import MetricCard from "../components/cards/MetricCard.jsx";
import RiskBadge from "../components/cards/RiskBadge.jsx";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import RivalTwinCard from "../components/rivals/RivalTwinCard.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { rivalTwins, telemetry } from "../data/demoData.js";

export default function RivalTwinCommand({ onNavigate, appState, appActions }) {
  const [selected, setSelected] = useState(rivalTwins[1]);
  const positionData = Object.entries(selected.final_position_probability).map(([position, probability]) => ({ position, probability }));
  const pitTimeline = rivalTwins.map((twin) => ({ rival: twin.name.replace(" Twin", ""), lap: twin.likely_energy_attack_lap, threat: twin.rival_battery_soc }));
  const energyAttackThreat = selected.energy_attack_threat;
  const longStintThreat = selected.long_stint_threat;
  const threatComparison = [
    { threat: "Energy Attack", value: energyAttackThreat },
    { threat: "Boost Defense", value: selected.boost_availability === "attack" ? 82 : 58 },
    { threat: "Confidence", value: selected.confidence }
  ];
  const tyreLife = Array.from({ length: 10 }, (_, index) => {
    const lap = 30 + index;
    const base = Math.max(38, 96 - index * 4.8 - selected.tyre_age * 0.75);
    return { lap, grip: Math.round(base), cliff: index > 6 ? Math.round(base - 14) : Math.round(base - 4) };
  });
  const strategyProbability = [
    { strategy: "Rival energy attack", probability: energyAttackThreat },
    { strategy: "Mirror leader", probability: Math.max(22, 82 - energyAttackThreat) },
    { strategy: "Long stint", probability: longStintThreat },
    { strategy: "Rain hedge", probability: selected.confidence - 38 }
  ];
  const sectorModel = [
    { sector: "S1", strength: selected.sector_strengths[0] ? 78 : 48, weakness: selected.sector_weaknesses[0] ? 62 : 34 },
    { sector: "S2", strength: selected.sector_strengths[1] ? 84 : 51, weakness: selected.sector_weaknesses[1] ? 58 : 30 },
    { sector: "S3", strength: selected.strategy_likelihood.includes("Long") ? 72 : 59, weakness: selected.pace_trend.includes("fade") ? 66 : 36 }
  ];

  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Rival Twin Standby"}
        title="No Rival Model Active"
        body={appState?.isConnected
          ? "OpenF1 source fields are connected, but the synthetic rival twin model is not active. Run the Austrian GP demo to inspect energy attack timelines and competitive intelligence."
          : "Competitor behavior models are offline because no race state is connected. Load the demo to inspect rival energy attack timelines, Battery SOC, and Boost defense pressure."}
        bullets={["Rival twins offline", "Energy attack prediction unavailable", "Battery SOC model idle", "Final-position panel empty"]}
        primaryLabel="Load Demo Rival Twins"
        onPrimary={appActions?.runDemo}
      />
    );
  }

  const submitRivalResponse = () => {
    appActions?.submitStrategy(
      {
        id: `rival-response-${selected.name.toLowerCase().replaceAll(" ", "-")}`,
        name: `Cover ${selected.name.replace(" Twin", "")} energy attack`,
        explanation: `${selected.name} is modeled for ${selected.strategy_likelihood.toLowerCase()} with ${energyAttackThreat}% energy attack threat and ${selected.rival_battery_soc}% Battery SOC.`,
        risk_level: energyAttackThreat > 75 ? "Critical" : energyAttackThreat > 50 ? "High" : "Medium",
        win_probability: 20,
        podium_probability: 61,
        simulation_support: selected.confidence,
        batterySOC: 63,
        boostButton: "available",
        overtakeMode: "armed_next_lap",
        activeAeroMode: "Z-Mode",
        rivalEnergyAttackWindow: `Lap ${selected.likely_energy_attack_lap}`
      },
      "Rival Twin Command Center"
    );
    onNavigate("decision");
  };

  return (
    <div className="page-stack">
      <section className="rival-selector">
        {rivalTwins.map((twin) => (
          <RivalTwinCard twin={twin} selected={selected.name === twin.name} onSelect={setSelected} key={twin.name} />
        ))}
      </section>
      <section className="metric-grid">
        <MetricCard label="Rival Battery SOC" value={`${selected.rival_battery_soc}%`} subvalue={selected.rival_soc_trend} accent="green" />
        <MetricCard label="Rival Overtake Mode Eligible" value={selected.overtake_mode_eligibility} subvalue={`Attack lap ${selected.likely_energy_attack_lap}`} />
        <MetricCard label="Boost Defense Required" value={selected.boost_availability} subvalue={`Defense lap ${selected.likely_boost_defense_lap}`} accent="blue" />
        <MetricCard label="X-Mode Straight Threat" value={`${selected.x_mode_efficiency}%`} subvalue={`${selected.superclip_exposure}s superclip`} accent="yellow" />
      </section>
      <div className="two-column rival-intel-grid">
        <section className="panel rival-profile">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Rival Twin Profile</p>
              <h2>{selected.name}</h2>
            </div>
            <RiskBadge level={energyAttackThreat > 75 ? "Critical" : energyAttackThreat > 50 ? "High" : "Medium"} />
          </div>
          <div className="summary-grid tall">
            <span><b>{selected.team}</b> modeled team</span>
            <span><b>{selected.position}</b> current position</span>
            <span><b>{selected.recharge_behavior}</b> Recharge Behavior</span>
            <span><b>{selected.likely_tyre_choice}</b> likely tyre choice</span>
            <span><b>{selected.corner_entry_weakness}</b> Corner Entry Vulnerability</span>
            <span><b>{selected.tyre_thermal_sensitivity}%</b> Tyre Thermal Sensitivity</span>
          </div>
          <div className="two-list">
            <div><h3>Sector Strengths</h3>{selected.sector_strengths.map((item) => <span key={item}>{item}</span>)}</div>
            <div><h3>Sector Weaknesses</h3>{selected.sector_weaknesses.map((item) => <span key={item}>{item}</span>)}</div>
          </div>
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Energy Attack Timeline</h2></div>
          <div className="rival-pit-rail">
            {pitTimeline.map((item) => (
              <span key={item.rival} style={{ left: `${((item.lap - 30) / 12) * 100}%` }}>
                <b>{item.rival}</b>
                <em>Lap {item.lap}</em>
              </span>
            ))}
          </div>
          <TelemetryChart data={pitTimeline} xKey="rival" series={[{ key: "lap", color: "#f2c94c" }, { key: "threat", color: "#ff3333" }]} type="bar" height={190} />
          <button className="primary-button" type="button" onClick={submitRivalResponse}>Open Strategy Response</button>
        </section>
      </div>
      <div className="three-column">
        <section className="panel">
          <div className="panel-header"><h2>Energy Attack / Boost Defense Threat</h2></div>
          <TelemetryChart data={threatComparison} xKey="threat" series={[{ key: "value", color: "#ff3333" }]} type="bar" height={220} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Tyre Thermal Sensitivity</h2></div>
          <TelemetryChart data={tyreLife} xKey="lap" series={[{ key: "grip", color: "#12d986" }, { key: "cliff", color: "#ff8a1f" }]} type="area" height={220} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>X-Mode / Z-Mode Performance Map</h2></div>
          <TelemetryChart data={sectorModel} xKey="sector" series={[{ key: "strength", color: "#12d986" }, { key: "weakness", color: "#ff8a1f" }]} type="bar" height={220} />
        </section>
      </div>
      <div className="two-column">
        <section className="panel strategy-probability-panel">
          <div className="panel-header"><h2>Strategy Probability Panel</h2></div>
          <div className="strategy-probability-list">
            {strategyProbability.map((item) => (
              <div key={item.strategy}>
                <span>{item.strategy}</span>
                <i><b style={{ width: `${Math.max(0, Math.min(100, item.probability))}%` }} /></i>
                <strong>{Math.max(0, Math.min(100, item.probability))}%</strong>
              </div>
            ))}
          </div>
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Final Position Probability</h2></div>
          <TelemetryChart data={positionData} xKey="position" series={[{ key: "probability", color: "#ff3333" }]} type="bar" height={220} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Rival Behavior Summary</h2></div>
          <div className="scenario-cards">
            <article><b>{selected.strategy_likelihood}</b><p>{selected.name} is most likely to bias toward {selected.strategy_likelihood.toLowerCase()} when clear air and pit crew readiness align.</p></article>
            <article><b>{selected.pace_trend}</b><p>Tyre degradation is modeled at {selected.tyre_degradation_estimate}; the twin confidence score is {selected.confidence}%.</p></article>
          </div>
          <button className="outline-button" type="button" onClick={submitRivalResponse}>Cover Energy Attack via Pit Wall Approval</button>
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Pace Trend</h2></div>
          <TelemetryChart data={telemetry.lap_times} xKey="lap" series={[{ key: "HAM", color: "#ff3333" }, { key: "NOR", color: "#ff8a1f" }]} height={220} />
        </section>
      </div>
    </div>
  );
}

