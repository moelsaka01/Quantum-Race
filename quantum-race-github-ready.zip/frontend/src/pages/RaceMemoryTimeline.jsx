import React, { useMemo, useState } from "react";
import MemoryTimeline from "../components/memory/MemoryTimeline.jsx";
import { raceMemory } from "../data/demoData.js";

export default function RaceMemoryTimeline({ appState }) {
  const [activeTag, setActiveTag] = useState("all");
  const memories = useMemo(() => [...(appState?.sessionMemory ?? []), ...raceMemory], [appState?.sessionMemory]);
  const tags = useMemo(() => Array.from(new Set(memories.flatMap((memory) => memory.tags ?? []))).slice(0, 10), [memories]);
  const filteredMemories = activeTag === "all" ? memories : memories.filter((memory) => memory.tags?.includes(activeTag));

  return (
    <div className="page-stack">
      <section className="panel page-intro">
        <div>
          <p className="eyebrow">Race Memory Timeline</p>
          <h2>Institutional Memory for Decisions and Outcomes</h2>
          <p>Past AI recommendations, pit wall decisions, outcomes, and lessons are linked back into future scenario matching.</p>
        </div>
        <span className="system-tag">{appState?.sessionMemory?.length ?? 0} current-session entries</span>
      </section>
      <section className="panel memory-filter-panel">
        <div className="panel-header compact">
          <h2>{appState?.isDemo ? "Current Session Memory" : "Race Memory Available"}</h2>
          <span className="system-tag">
            {appState?.isDemo
              ? "Demo replay memory active"
              : appState?.isConnected
                ? "Connected source memory queue empty"
                : "Current-session queue empty"}
          </span>
        </div>
        <div className="tag-row">
          <button className={activeTag === "all" ? "active" : ""} type="button" onClick={() => setActiveTag("all")}>all</button>
          {tags.map((tag) => (
            <button className={activeTag === tag ? "active" : ""} type="button" onClick={() => setActiveTag(tag)} key={tag}>{tag}</button>
          ))}
        </div>
      </section>
      <MemoryTimeline memories={filteredMemories} />
    </div>
  );
}

