import React from "react";
import { AlertTriangle, CheckCircle2, Radio, Route, ShieldAlert, TimerReset } from "lucide-react";
import AgentCard from "../components/agents/AgentCard.jsx";
import MetricCard from "../components/cards/MetricCard.jsx";
import RiskBadge from "../components/cards/RiskBadge.jsx";
import StatusPill from "../components/cards/StatusPill.jsx";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import RivalTwinCard from "../components/rivals/RivalTwinCard.jsx";
import SimulationStrategyField from "../components/simulations/SimulationStrategyField.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import ThreatMeter from "../components/telemetry/ThreatMeter.jsx";
import TrackPanel from "../components/telemetry/TrackPanel.jsx";
import { agents, drivers, raceMemory, raceState, rivalTwins, simulation, strategyOptions, strategyTimeline, telemetry, threats } from "../data/demoData.js";

export default function MissionControl({ onNavigate, appState, appActions }) {
  const principal = agents[agents.length - 1];
  const defaultStrategy = strategyOptions.find((strategy) => strategy.id === "pit-in-3") ?? strategyOptions[0];
  const timelineNotes = {
    past: "Logged race engineering context",
    current: "Recommendation generated, review pending",
    recommended: "Primary call window",
    future: "Monitor rival hard-tyre cliff"
  };

  if (!appState?.isDemo) {
    const connected = appState?.isConnected;
    return (
      <div className="page-stack">
        <StandbyPanel
          eyebrow={connected ? "Connected Source Standby" : "Mission Control Standby"}
          title={connected ? "OpenF1 Source Connected, No 2026 Tactical Race State" : "No Live 2026 Race Data Connected"}
          body={connected
            ? "OpenF1 public data is connected, but the 2026 strategy cockpit is not running a synthetic demo race state. Open Real-Time Data to inspect source fields."
            : "Quantum Race is standing by with no live telemetry feed, no active race session, and no strategy recommendation awaiting pit wall authorization."}
          bullets={[
            connected ? "OpenF1 source connected" : "Telemetry feed disconnected",
            "Active Aero systems standby",
            "Battery SOC unavailable",
            "Simulation engine standing by",
            "AI agents idle",
            "Rival twins offline",
            "Pit Wall Approval queue empty",
            "Race Memory available"
          ]}
          primaryLabel={connected ? "Open Real-Time Data" : "Run Austrian GP 2026 Demo"}
          onPrimary={connected ? () => onNavigate("real-time") : appActions?.runDemo}
        />
        <section className="standby-command-grid">
          {[
            ["Data Source", "Offline", "No live timing or telemetry source connected."],
            ["Simulation Engine", "Standby", "Monte Carlo race universe ready to run when a session is loaded."],
            ["Agent Network", "Idle", "Strategy, tyre, weather, rival, and risk agents are not debating."],
            ["Approval Queue", "Empty", "No strategy can be logged without race engineer authorization."]
          ].map(([label, value, text]) => (
            <article className="panel standby-instrument" key={label}>
              <p className="eyebrow">{label}</p>
              <h2>{value}</h2>
              <p>{text}</p>
            </article>
          ))}
        </section>
      </div>
    );
  }

  return (
    <div className="page-grid mission-control-page">
      <section className="metric-grid full-width">
        <MetricCard label="Position" value={raceState.position} subvalue={`${raceState.gap_to_leader} to leader`} />
        <MetricCard label="Lap" value={`${raceState.lap} / ${raceState.total_laps}`} subvalue={raceState.race_phase} />
        <MetricCard label="Current Strategy" value="1 Stop" subvalue="Lap 35 primary window" accent="yellow" />
        <MetricCard label="Tyre" value={raceState.tyre_compound} subvalue={`${raceState.tyre_age} laps old`} accent="yellow">
          <div className="tyre-visual" />
        </MetricCard>
        <MetricCard label="Battery SOC" value={`${raceState.batterySOC}%`} subvalue={raceState.batterySOCTrend} accent="green" />
        <MetricCard label="Active Aero Mode" value={raceState.activeAeroMode} subvalue="X-Mode next straight" accent="blue" />
        <MetricCard label="Overtake Mode" value="Armed" subvalue="Next lap" />
        <MetricCard label="Boost Button" value="Available" subvalue={`+${raceState.boostPowerDelta} kW`} accent="green" />
        <MetricCard label="MGU-K Deployment" value={`${raceState.mguKDeployment} kW`} subvalue="Acceleration zones" accent="blue" />
        <MetricCard label="Energy Clipping Risk" value={raceState.energyClippingRisk} subvalue={`${raceState.superclipDuration}s/lap superclip`} />
      </section>

      <div className="main-column">
        <TrackPanel drivers={drivers} />
        <section className="status-strip">
          <span><b>X-Mode Availability</b>Available next straight</span>
          <span><b>Z-Mode Stability</b>{raceState.zModeStability}% stable</span>
          <span><b>Recharge Mode</b>{raceState.rechargeMode}</span>
          <span><b>Superclip Duration</b>{raceState.superclipDuration}s/lap</span>
          <span><b>Corner Entry Risk</b>{raceState.cornerEntryRisk}</span>
          <span><b>Tyre Thermal Load</b>{raceState.tyreThermalLoad}%</span>
          <span><b>Rival Energy Attack Window</b>{raceState.rivalEnergyAttackWindow}</span>
          <span><b>Safety Car</b>None</span>
        </section>
        <div className="two-column">
          <section className="panel">
            <div className="panel-header">
              <div>
              <p className="eyebrow">Simulation Universe Preview</p>
              <h2>100,000 Race Futures</h2>
            </div>
              <StatusPill tone="success">Demo model</StatusPill>
            </div>
            <SimulationStrategyField compact mode="demo" showLegend={false} showCTA={false} activeScenario="current" />
            <div className="summary-grid">
              <span><b>{simulation.win_probability}%</b> win</span>
              <span><b>{simulation.podium_probability}%</b> podium</span>
              <span><b>{simulation.points_probability}%</b> points</span>
              <span><b>P{simulation.expected_finish}</b> expected</span>
            </div>
            <button className="outline-button" type="button" onClick={() => onNavigate("simulation")}>Explore Simulations</button>
          </section>
          <section className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Strategy Timeline</p>
              <h2>Lap 32 Energy Attack Window</h2>
              </div>
              <TimerReset size={20} />
            </div>
            <div className="strategy-command-panel">
              <div className="strategy-rail" aria-label="Race strategy lap timeline">
                {strategyTimeline.map((item) => (
                  <span className={item.state} key={`${item.lap}-${item.event}`} style={{ left: `${(item.lap / raceState.total_laps) * 100}%` }}>
                    <b>{item.lap}</b>
                  </span>
                ))}
              </div>
              <div className="strategy-event-grid">
                {strategyTimeline.map((item) => (
                  <article className={`strategy-event-card ${item.state}`} key={`${item.lap}-${item.event}`}>
                    <small>Lap {item.lap} | {item.state}</small>
                    <strong>{item.event}</strong>
                    <em>{timelineNotes[item.state]}</em>
                  </article>
                ))}
              </div>
            </div>
            <div className="pace-band">
              <span>+0.3s recharge gain</span>
              <span>+0.8s boost defense</span>
              <span>+1.4s clipping risk</span>
            </div>
            <button className="outline-button" type="button" onClick={() => onNavigate("strategy")}>View Strategy Options</button>
          </section>
        </div>
        <div className="three-column bottom-row">
          <section className="panel">
            <div className="panel-header compact">
              <h2>Live Telemetry Strip</h2>
              <StatusPill>HAM vs VER</StatusPill>
            </div>
            <TelemetryChart data={telemetry.speed_trace} series={[{ key: "HAM", color: "#ff3333" }, { key: "VER", color: "#5394ff" }]} height={150} />
          </section>
          <section className="panel radio-panel">
            <div className="panel-header compact">
              <h2>Latest Radio</h2>
              <Radio size={18} />
            </div>
            {["Tyres feeling good, still ok.", "Box this lap. Box this lap.", "What's the gap to Norris?"].map((line, index) => (
              <div className="radio-line" key={line}>
                <span>Lap {32 - index}</span>
                <p>{line}</p>
              </div>
            ))}
            <button className="outline-button" type="button">Open Radio Channel</button>
          </section>
          <section className="panel alerts-panel">
            <div className="panel-header compact">
              <h2>Alerts</h2>
              <ShieldAlert size={18} />
            </div>
            {[
              ["Overtake Mode Threat", "NOR lap 34", "danger"],
              ["Battery SOC Depleting", "63% and falling", "warning"],
              ["X-Mode Straight Threat", "Main straight next lap", "warning"],
              ["Z-Mode Stability Watch", "78% in S2", "success"]
            ].map(([label, value, tone]) => (
              <div className={`alert-row ${tone}`} key={label}>
                <AlertTriangle size={16} />
                <span>{label}</span>
                <b>{value}</b>
              </div>
            ))}
          </section>
        </div>
      </div>

      <aside className="side-column">
        <section className="panel agent-consensus">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Agent Consensus</p>
              <h2>Stay Out</h2>
            </div>
            <strong className="confidence-number">82%</strong>
          </div>
          <div className="confidence-line">
            <span>Overall Confidence</span>
            <b>82%</b>
            <i style={{ width: "82%" }} />
          </div>
          <p>{principal.risk_explanation}</p>
          <ul className="compact-list">
            <li>Tyre life good for 3 more laps</li>
            <li>Rival energy attack manageable if Boost defense is preserved</li>
            <li>Rain risk increasing but not immediate</li>
            <li>Track evolution in our favor</li>
          </ul>
          <button className="outline-button" type="button" onClick={() => onNavigate("debate")}>View Full Debate</button>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Threat Radar</p>
              <h2>Race Risk Stack</h2>
            </div>
          </div>
          <ThreatMeter threats={threats} />
        </section>

        <section className="panel decision-hot">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Pit Wall Approval Status</p>
              <h2>Race Engineer Review Required</h2>
            </div>
            <RiskBadge level="High" />
          </div>
          <p>Race Engineer Review Required: energy attack strategy cannot be logged without pit wall authorization.</p>
          <button
            className="primary-button"
            type="button"
            onClick={() => {
              appActions?.submitStrategy(defaultStrategy, "Mission Control Agent Consensus");
              onNavigate("decision");
            }}
          >
            Go to Pit Wall Approval
          </button>
        </section>

        <section className="panel">
          <div className="panel-header compact">
            <h2>Rival Twins - Top Threats</h2>
            <Route size={18} />
          </div>
          <div className="rival-list">
            {rivalTwins.map((twin) => (
              <RivalTwinCard twin={twin} selected={false} onSelect={() => onNavigate("rivals")} key={twin.name} />
            ))}
          </div>
          <button className="outline-button" type="button" onClick={() => onNavigate("rivals")}>Open Rival Command Center</button>
        </section>

        <section className="panel memory-insight">
          <div className="panel-header compact">
            <h2>Race Memory Insight</h2>
            <CheckCircle2 size={18} />
          </div>
          <StatusPill tone="warning">Similar past scenario found</StatusPill>
          <h3>{raceMemory[1].race} - Lap {raceMemory[1].lap}</h3>
          <p>{raceMemory[1].lesson_learned}</p>
          <button className="outline-button" type="button" onClick={() => onNavigate("memory")}>View Memory Timeline</button>
        </section>
      </aside>
    </div>
  );
}

