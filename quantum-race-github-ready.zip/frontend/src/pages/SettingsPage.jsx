import React from "react";
import { Bot, Database, Palette, ShieldCheck, SlidersHorizontal, UserCheck } from "lucide-react";
import RiskBadge from "../components/cards/RiskBadge.jsx";
import StatusPill from "../components/cards/StatusPill.jsx";

const settings = [
  { icon: UserCheck, title: "Team Profile", value: "Quantum Race Demo Team", detail: "Race engineer: M. Alvarez" },
  { icon: Bot, title: "Agent Settings", value: "Rule-based v1", detail: "Risk Manager and Team Principal synthesis enabled" },
  { icon: SlidersHorizontal, title: "2026 Ruleset Active", value: "Austrian GP 2026", detail: "Active Aero, Overtake Mode, Boost, and Battery SOC model enabled" },
  { icon: ShieldCheck, title: "Pit Wall Approval Settings", value: "Required", detail: "Approve, adjust, or reject workflow active" },
  { icon: Database, title: "Energy Model Settings", value: "Battery SOC + MGU-K", detail: "Recharge, superclip, and energy clipping risk enabled" },
  { icon: Database, title: "Active Aero Model Settings", value: "X-Mode / Z-Mode", detail: "Aero transition and corner-entry risk enabled" },
  { icon: SlidersHorizontal, title: "Tyre Thermal Model Settings", value: "Narrower tyre sensitivity", detail: "Thermal load and lower downforce behavior enabled" },
  { icon: Palette, title: "Theme Settings", value: "Mission Control Dark", detail: "Carbon panels, red accents, technical grid" }
];

export default function SettingsPage({ appState, appActions }) {
  return (
    <div className="page-stack">
      <section className="panel page-intro">
        <div>
          <p className="eyebrow">Settings</p>
          <h2>Platform Configuration</h2>
          <p>Operational defaults keep AI recommendations under race engineer control.</p>
        </div>
        <StatusPill tone="success">Auto execute disabled</StatusPill>
      </section>
      <section className="panel demo-control-panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Demo and Source Controls</p>
            <h2>
              {appState?.isDemo
                ? "Austrian GP 2026 Demo Running"
                : appState?.isConnected
                  ? "OpenF1 Public Data Connected"
                  : "No Live 2026 Data Standby"}
            </h2>
          </div>
          <StatusPill tone={appState?.isDemo ? "danger" : appState?.isConnected ? "success" : "warning"}>
            {appState?.isDemo ? "2026 Ruleset Active" : appState?.isConnected ? "OpenF1 source active" : "No live 2026 data connected"}
          </StatusPill>
        </div>
        <div className="control-button-row">
          <button className="primary-button" type="button" onClick={appActions?.runDemo}>Run Austrian GP 2026 Demo</button>
          <button className="outline-button" type="button" onClick={appActions?.openDataSourceModal}>Connect OpenF1 Data Source</button>
          {appState?.isConnected && <button className="outline-button" type="button" onClick={appActions?.disconnectDataSource}>Disconnect OpenF1 Source</button>}
          <button className="outline-button" type="button" onClick={appActions?.resetDemo}>Reset Demo / Return to Standby</button>
          <button className="outline-button" type="button" onClick={appActions?.clearLocalDecisions}>Clear Local Decisions</button>
          <button className="ghost-button" type="button" onClick={appActions?.resetDemo}>Simulate No Data State</button>
        </div>
      </section>
      <section className="settings-grid">
        {settings.map((item) => {
          const Icon = item.icon;
          return (
            <article className="settings-panel" key={item.title}>
              <Icon size={22} />
              <div>
                <p className="eyebrow">{item.title}</p>
                <h3>{item.value}</h3>
                <span>{item.detail}</span>
              </div>
            </article>
          );
        })}
      </section>
      <section className="panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Risk Tolerance</p>
            <h2>Medium</h2>
          </div>
          <RiskBadge level="Medium" />
        </div>
        <div className="control-row">
          <label><input type="checkbox" defaultChecked /> Require pit wall approval for strategy changes</label>
          <label><input type="checkbox" defaultChecked /> Log decisions to Race Memory</label>
          <label><input type="checkbox" defaultChecked /> Escalate high-risk agent disagreement</label>
        </div>
      </section>
    </div>
  );
}

