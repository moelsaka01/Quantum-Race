import React from "react";
import MetricCard from "../components/cards/MetricCard.jsx";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { performanceAnalytics } from "../data/demoData.js";

export default function PerformanceAnalytics({ appState, appActions }) {
  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Performance Analytics Standby"}
        title="No Live Evaluation Data"
        body={appState?.isConnected
          ? "OpenF1 public data is connected, but Quantum Race has no live evaluation or decision-outcome stream active. Demo metrics load after the Austrian GP replay starts."
          : "No current-session telemetry or decision outcomes are available for evaluation. Demo metrics load after the Austrian GP replay starts."}
        bullets={["No live accuracy stream", "No Battery SOC error trace", "No active aero evaluation", "No pit wall outcome update"]}
        onPrimary={appActions?.runDemo}
      />
    );
  }

  return (
    <div className="page-stack">
      <section className="metric-grid">
        <MetricCard label="Battery SOC Error" value="8%" subvalue="Target 6%" accent="green" />
        <MetricCard label="Recharge Accuracy" value="83%" subvalue="Target 84%" accent="blue" />
        <MetricCard label="Boost Defense Success" value="74%" subvalue="Target 76%" accent="yellow" />
        <MetricCard label="Pit Wall Outcome Rate" value="76%" subvalue="Approval workflow" />
      </section>
      <div className="two-column">
        <section className="panel">
          <div className="panel-header"><h2>System Accuracy and Approval Metrics</h2></div>
          <TelemetryChart data={performanceAnalytics.system_metrics} xKey="name" series={[{ key: "value", color: "#ff3333" }, { key: "target", color: "#12d986" }]} type="bar" height={320} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Pace Ranking</h2></div>
          <div className="data-table">
            {performanceAnalytics.pace_ranking.map((item) => (
              <div className="data-row" key={item.metric}>
                <strong>{item.metric}</strong>
                <span>Rank {item.rank}</span>
                <b>{item.delta}</b>
              </div>
            ))}
          </div>
        </section>
      </div>
      <div className="two-column">
        <section className="panel">
          <div className="panel-header"><h2>Energy Efficiency</h2></div>
          <TelemetryChart data={performanceAnalytics.energy_efficiency} xKey="stint" series={[{ key: "value", color: "#2aa8ff" }]} type="area" />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Tyre Usage Ranking</h2></div>
          <TelemetryChart data={performanceAnalytics.tyre_usage_ranking} xKey="compound" series={[{ key: "score", color: "#f2c94c" }]} type="bar" />
        </section>
      </div>
    </div>
  );
}

