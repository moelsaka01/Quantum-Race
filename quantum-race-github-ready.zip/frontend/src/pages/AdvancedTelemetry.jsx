import React from "react";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { advancedTelemetry } from "../data/demoData.js";

export default function AdvancedTelemetry({ appState, appActions }) {
  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Advanced Telemetry Standby"}
        title={appState?.isConnected ? "Advanced 2026 Analysis Not Loaded" : "No Telemetry Session Loaded"}
        body={appState?.isConnected
          ? "OpenF1 source telemetry is available on Real-Time Data. Advanced Battery SOC, Active Aero, and MGU-K analysis remains idle until the demo tactical state is loaded."
          : "Engineering analysis panels are locked until a race state and data feed are loaded into Quantum Race."}
        bullets={["X-Mode analysis locked", "Z-Mode stability offline", "MGU-K analysis idle", "Corner-entry model idle"]}
        onPrimary={appActions?.runDemo}
      />
    );
  }

  return (
    <div className="page-stack">
      <div className="two-column">
        <section className="panel wide-panel">
          <div className="panel-header"><h2>X-Mode Straight-Line Delta</h2></div>
          <TelemetryChart data={advancedTelemetry.sector_comparison} xKey="sector" series={[{ key: "HAM", color: "#ff3333" }, { key: "VER", color: "#5394ff" }, { key: "NOR", color: "#ff8a1f" }]} type="bar" height={260} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Performance Anomalies</h2></div>
          <div className="data-table">
            {advancedTelemetry.anomalies.map((item) => (
              <div className="data-row" key={item.system}>
                <strong>{item.system}</strong>
                <span>{item.delta}</span>
                <b>{item.severity}</b>
              </div>
            ))}
          </div>
        </section>
      </div>
      <div className="two-column">
        <section className="panel">
          <div className="panel-header"><h2>Z-Mode Cornering Stability</h2></div>
          <TelemetryChart data={advancedTelemetry.corner_speed} xKey="corner" series={[{ key: "HAM", color: "#ff3333" }, { key: "NOR", color: "#ff8a1f" }]} height={250} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Brake Stability Trace</h2></div>
          <TelemetryChart data={advancedTelemetry.brake_pressure} xKey="corner" series={[{ key: "pressure", color: "#f2c94c" }]} type="area" height={250} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>MGU-K Deployment Map</h2></div>
          <TelemetryChart data={advancedTelemetry.mgu_k_usage} xKey="lap" series={[{ key: "deploy", color: "#2aa8ff" }, { key: "harvest", color: "#12d986" }]} height={250} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Tyre Thermal Model</h2></div>
          <TelemetryChart data={advancedTelemetry.tyre_temperature} xKey="lap" series={[{ key: "front_left", color: "#ff3333" }, { key: "front_right", color: "#ff8a1f" }, { key: "rear_left", color: "#f2c94c" }, { key: "rear_right", color: "#12d986" }]} height={250} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>Active Aero Transition Timing</h2></div>
          <TelemetryChart data={advancedTelemetry.sector_comparison} xKey="sector" series={[{ key: "HAM", color: "#6fe7ff" }, { key: "NOR", color: "#f2c94c" }]} height={250} />
        </section>
        <section className="panel">
          <div className="panel-header"><h2>2026 Car Behavior Summary</h2></div>
          <div className="summary-grid tall">
            <span><b>Narrower car</b> lower drag profile</span>
            <span><b>Lower downforce</b> higher aero sensitivity</span>
            <span><b>Narrower tyres</b> thermal load critical</span>
            <span><b>Active Aero</b> X-Mode / Z-Mode strategy</span>
          </div>
        </section>
      </div>
    </div>
  );
}

