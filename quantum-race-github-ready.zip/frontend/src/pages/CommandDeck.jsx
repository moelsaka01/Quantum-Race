import React from "react";
import {
  Activity,
  AlertTriangle,
  BrainCircuit,
  CheckCircle2,
  Cpu,
  Gauge,
  GitBranch,
  Play,
  RadioTower,
  Route,
  ShieldAlert,
  TimerReset,
  UserCheck,
  Zap
} from "lucide-react";
import RiskBadge from "../components/cards/RiskBadge.jsx";
import StatusPill from "../components/cards/StatusPill.jsx";
import SimulationStrategyField from "../components/simulations/SimulationStrategyField.jsx";
import CinematicTrack from "../components/telemetry/CinematicTrack.jsx";
import { agents, raceMemory, raceState, rivalTwins, simulation, strategyOptions, telemetry, threats } from "../data/demoData.js";

const idleSystems = [
  ["Live 2026 Race Data", "Disconnected", "No timing stream attached", AlertTriangle],
  ["Active Aero Systems", "Standby", "X-Mode and Z-Mode unavailable", Gauge],
  ["Battery SOC", "Unavailable", "No energy model attached", Zap],
  ["Simulation Engine", "Standby", "100,000 futures ready", BrainCircuit],
  ["Agent Network", "Idle", "No active debate", Cpu],
  ["Pit Wall Approval", "Empty", "No review queue", UserCheck]
];

const demoSystems = [
  ["2026 Ruleset", "Active", "Austrian GP 2026 demo", Activity],
  ["Active Aero", raceState.activeAeroMode, "X-Mode available next straight", Gauge],
  ["Battery SOC", `${raceState.batterySOC}%`, raceState.batterySOCTrend, Zap],
  ["Overtake Mode", "Armed next lap", "Attack/defense window active", Cpu],
  ["Boost Button", "Available", `+${raceState.boostPowerDelta} kW delta`, ShieldAlert],
  ["Pit Wall Approval", "Required", "Race engineer authorization", UserCheck]
];

const connectedSystems = [
  ["OpenF1 Data Source", "Connected", "Public latest/historical session", CheckCircle2],
  ["Real-Time Subscription", "Unavailable", "Token required for paid real-time mode", AlertTriangle],
  ["2026 Tactical Layer", "Synthetic", "Active Aero and Battery SOC overlay separated", BrainCircuit],
  ["Telemetry Feed", "Partial", "OpenF1 source fields only", RadioTower],
  ["Pit Wall Approval", "Ready", "Strategies still require authorization", UserCheck],
  ["Demo Replay", "Off", "Replay labels disabled", ShieldAlert]
];

const approvalStates = [
  "Recommendation generated",
  "Simulation evidence attached",
  "Agent debate attached",
  "Energy model attached",
  "Active aero model attached",
  "Race engineer review",
  "Pit wall approval required",
  "Memory pending"
];

function MetricNode({ label, value, detail, tone = "neutral" }) {
  return (
    <article className={`deck-metric-node tone-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}

function SystemTile({ item }) {
  const [label, value, detail, Icon] = item;
  return (
    <article className="deck-system-tile">
      <Icon size={17} />
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
        <small>{detail}</small>
      </div>
    </article>
  );
}

export default function CommandDeck({ onNavigate, appState, appActions }) {
  const isDemo = appState?.isDemo;
  const isConnected = appState?.isConnected;
  const isActive = isDemo || isConnected;
  const visualMode = isDemo ? "demo" : isConnected ? "connected" : "idle";
  const principal = agents[agents.length - 1];
  const recommendedStrategy = strategyOptions.find((strategy) => strategy.id === "pit-in-3") ?? strategyOptions[0];
  const coverEnergyAttack = strategyOptions.find((strategy) => strategy.id === "cover-energy-attack") ?? recommendedStrategy;
  const leadingThreat = threats[0];
  const topRival = rivalTwins[1] ?? rivalTwins[0];
  const systems = isDemo ? demoSystems : isConnected ? connectedSystems : idleSystems;
  const connectedLabel = appState?.connectedState?.session_label ?? "OpenF1 public latest session";

  const submitForApproval = (strategy = recommendedStrategy, source = "Quantum Race Command Deck") => {
    if (!isActive) {
      return;
    }
    appActions?.submitStrategy(strategy, source);
    onNavigate("decision");
  };

  const launchDemo = () => {
    appActions?.runDemo();
  };

  return (
    <div className={`command-deck ${isDemo ? "deck-demo" : isConnected ? "deck-connected" : "deck-idle"}`}>
      <section className="deck-hero">
        <div className="deck-brand-panel">
          <div className="deck-brand-kicker">
            <StatusPill tone={isDemo ? "danger" : isConnected ? "success" : "warning"}>{isDemo ? "Austrian GP 2026 Demo Replay Active" : isConnected ? "OpenF1 Public Data Connected" : "No Live 2026 Race Data Connected"}</StatusPill>
            <span>2026 Race Intelligence Platform</span>
          </div>
          <h2>Quantum Race Command Deck</h2>
          <p>
            {isDemo
              ? "AI-powered 2026 race engineering for the Austrian GP demo: Active Aero Strategy, Battery SOC, Overtake Mode, Boost Button, rival energy windows, and Pit Wall Approval in one cinematic command surface."
              : isConnected
                ? `${connectedLabel} is connected through OpenF1 public data. Historical/latest source fields are shown separately from the synthetic 2026 tactical simulation layer.`
                : "A premium 2026 race engineering cockpit standing by with no live telemetry feed, no active race session, no Battery SOC, and no autonomous strategy execution."}
          </p>
          <div className="deck-cta-row">
            {!isDemo && !isConnected && (
              <button className="primary-button deck-main-cta" type="button" onClick={launchDemo}>
                <Play size={16} /> Run Austrian GP 2026 Demo
              </button>
            )}
            {isDemo && (
              <button className="primary-button deck-main-cta" type="button" onClick={() => onNavigate("mission")}>
                <RadioTower size={16} /> Open Mission Control
              </button>
            )}
            {isConnected && (
              <button className="primary-button deck-main-cta" type="button" onClick={() => onNavigate("real-time")}>
                <RadioTower size={16} /> Open Connected Telemetry
              </button>
            )}
            <button className="ghost-button" type="button" onClick={appActions?.openDataSourceModal}>
              Connect Live Data Source
            </button>
            {isConnected && <button className="ghost-button" type="button" onClick={appActions?.disconnectDataSource}>Disconnect Source</button>}
          </div>

          <div className="deck-status-matrix">
            {systems.map((item) => <SystemTile item={item} key={item[0]} />)}
          </div>
        </div>

        <div className="deck-visual-panel">
          <div className="deck-panel-toolbar">
            <span>{isDemo ? raceState.grand_prix : isConnected ? connectedLabel : "2026 simulation command surface"}</span>
            <StatusPill tone={isDemo || isConnected ? "success" : "warning"}>{isDemo ? "2026 Ruleset Active" : isConnected ? "OpenF1 Source Active" : "Simulation Engine Standby"}</StatusPill>
          </div>
          <CinematicTrack mode={visualMode} variant="deck" />
          <div className="deck-track-instruments">
            <MetricNode label="Position" value={isDemo ? raceState.position : "--"} detail={isDemo ? `${raceState.gap_to_leader} to leader` : "No active session"} tone="danger" />
            <MetricNode label="Session" value={isDemo ? `${raceState.lap} / ${raceState.total_laps}` : isConnected ? "OpenF1" : "-- / --"} detail={isDemo ? raceState.race_phase : isConnected ? "Public historical/latest" : "Race state unavailable"} />
            <MetricNode label="Tyre" value={isDemo ? raceState.tyre_compound : "Source n/a"} detail={isDemo ? `${raceState.tyre_age} laps old` : "Not available"} tone="yellow" />
            <MetricNode label="Battery SOC" value={isDemo ? `${raceState.batterySOC}%` : "n/a"} detail={isDemo ? raceState.batterySOCTrend : isConnected ? "Synthetic overlay only" : "Energy model idle"} tone="green" />
            <MetricNode label="Active Aero" value={isDemo ? raceState.activeAeroMode : "n/a"} detail={isDemo ? "X-Mode next straight" : isConnected ? "Not provided by source" : "Standby"} tone="green" />
            <MetricNode label="Overtake Mode" value={isDemo ? "Armed" : "n/a"} detail={isDemo ? "Next lap" : isConnected ? "Not provided by source" : "Unavailable"} tone="danger" />
            <MetricNode label="Data Source" value={isConnected ? "OpenF1" : isDemo ? "Demo" : "None"} detail={isConnected ? "Connected" : isDemo ? "Replay" : "Offline"} tone="yellow" />
          </div>
        </div>

        <aside className="deck-intel-stack">
          <article className="deck-radar-panel">
            <div className="deck-panel-header">
              <div>
                <span>Threat Radar</span>
              <strong>{isDemo ? leadingThreat.name : isConnected ? "Source connected, risk model idle" : "Dormant risk field"}</strong>
              </div>
              <RiskBadge level={isDemo ? "Critical" : "High"} />
            </div>
            <div className={`deck-risk-radar ${isDemo ? "active" : ""}`}>
              <i />
              <b style={{ transform: `rotate(${isDemo ? 18 : -24}deg)` }} />
              <b style={{ transform: `rotate(${isDemo ? 82 : 34}deg)` }} />
              <b style={{ transform: `rotate(${isDemo ? 146 : 96}deg)` }} />
            </div>
            <div className="deck-risk-list">
              {threats.slice(0, 4).map((threat) => (
                <span key={threat.name}>
                  <small>{threat.name}</small>
                  <em>{isDemo ? `${threat.value}%` : "--"}</em>
                </span>
              ))}
            </div>
          </article>

          <article className="deck-agent-panel">
            <div className="deck-panel-header">
              <div>
                <span>Agent Consensus</span>
                <strong>{isDemo ? principal.consensus_recommendation : "Agents idle"}</strong>
              </div>
              <BrainCircuit size={18} />
            </div>
            <p>{isDemo ? principal.risk_explanation : isConnected ? "OpenF1 data is connected, but the 2026 AI tactical recommendation layer is not auto-running. Submit a strategy only after race engineer review." : "Strategy, tyre, weather, rival, energy, active aero, and corner-entry agents are waiting for a loaded race state."}</p>
            <div className="deck-confidence-rail">
              <i style={{ width: isDemo ? `${principal.confidence}%` : "7%" }} />
              <strong>{isDemo ? `${principal.confidence}%` : "Idle"}</strong>
            </div>
            <button className="outline-button" type="button" onClick={() => onNavigate("debate")}>View Agent Debate Arena</button>
          </article>

          <article className="deck-approval-panel">
            <div className="deck-panel-header">
              <div>
                <span>Pit Wall Approval</span>
                <strong>{isDemo ? "Race Engineer Approval Required" : "Queue Empty"}</strong>
              </div>
              <UserCheck size={18} />
            </div>
            <p>{isActive ? "AI recommends. Pit wall approves. Final strategy requires race engineer approval before it can be logged." : "No recommendation awaiting Pit Wall Approval."}</p>
            <button className="primary-button" type="button" onClick={() => submitForApproval(recommendedStrategy)}>
              {isActive ? "Submit to Pit Wall Approval" : "Awaiting Race State"}
            </button>
          </article>
        </aside>
      </section>

      <section className="deck-command-rail">
        {approvalStates.map((state, index) => (
          <article className={isDemo && index < 4 ? "complete" : ""} key={state}>
            <span>{String(index + 1).padStart(2, "0")}</span>
            <strong>{state}</strong>
          </article>
        ))}
      </section>

      <section className="deck-bottom-grid">
        <article className="deck-module deck-simulation-module">
          <div className="deck-panel-header">
            <div>
              <span>Simulation-Driven Strategy</span>
            <strong>{isDemo ? "100,000 Possible Race Futures" : isConnected ? "Simulation Layer Not Started" : "Monte Carlo Race Universe Standby"}</strong>
            </div>
            <GitBranch size={18} />
          </div>
          <SimulationStrategyField
            compact
            mode={visualMode}
            showLegend
            showCTA={false}
            activeScenario={isDemo ? "current" : "idle"}
          />
          <div className="deck-module-actions">
            <button className="outline-button" type="button" onClick={() => onNavigate("simulation")}>Explore Simulations</button>
            <button className="ghost-button" type="button" disabled={!isActive} onClick={() => submitForApproval(recommendedStrategy, "Command Deck Simulation Preview")}>
              Submit Scenario to Review
            </button>
          </div>
        </article>

        <article className="deck-module deck-rival-module">
          <div className="deck-panel-header">
            <div>
              <span>Rival Twin Intelligence</span>
              <strong>{isDemo ? `${topRival.name} - Rival Energy Attack Window` : isConnected ? "Rival model idle for connected source" : "No rival model active"}</strong>
            </div>
            <Route size={18} />
          </div>
          <div className="deck-rival-graph">
            <span style={{ height: isDemo ? `${topRival.rival_battery_soc}%` : "14%" }}><b>Battery SOC</b></span>
            <span style={{ height: isDemo ? `${topRival.x_mode_efficiency}%` : "12%" }}><b>X-Mode</b></span>
            <span style={{ height: isDemo ? `${topRival.z_mode_cornering_strength}%` : "10%" }}><b>Z-Mode</b></span>
            <span style={{ height: isDemo ? `${topRival.tyre_thermal_sensitivity}%` : "11%" }}><b>Tyre thermal</b></span>
          </div>
          <p>{isDemo ? "Norris twin predicts lap 34 Overtake Mode eligibility with Boost attack and X-Mode straight threat." : "Rival twins are idle until a race state or demo replay is loaded."}</p>
          <div className="deck-module-actions">
            <button className="outline-button" type="button" onClick={() => onNavigate("rivals")}>Open Rival Twin Command</button>
            <button className="ghost-button" type="button" disabled={!isActive} onClick={() => submitForApproval(coverEnergyAttack, "Rival Twin Command Deck")}>
              Cover Energy Attack
            </button>
          </div>
        </article>

        <article className="deck-module deck-memory-module">
          <div className="deck-panel-header">
            <div>
              <span>Race Memory</span>
              <strong>{isDemo ? "Similar Scenario Intelligence" : "Historical memory available"}</strong>
            </div>
            <TimerReset size={18} />
          </div>
          <div className="deck-memory-pulse">
            <Zap size={24} />
            <div>
              <strong>{raceMemory[1].race} - Lap {raceMemory[1].lap}</strong>
              <p>{raceMemory[1].lesson_learned}</p>
            </div>
          </div>
          <button className="outline-button" type="button" onClick={() => onNavigate("memory")}>View Race Memory Timeline</button>
        </article>

        <article className="deck-module deck-telemetry-module">
          <div className="deck-panel-header">
            <div>
              <span>Glowing Telemetry Rail</span>
              <strong>{isDemo ? telemetry.live_strip.lap_time : "No active telemetry"}</strong>
            </div>
            <Gauge size={18} />
          </div>
          <div className={`deck-telemetry-trace ${isDemo ? "active" : ""}`}>
            {telemetry.speed_trace.slice(0, 38).map((point, index) => (
              <span
                key={`${point.lap_distance}-${index}`}
                style={{
                  left: `${(index / 37) * 100}%`,
                  height: `${isDemo ? Math.max(12, (point.HAM / 350) * 100) : 8 + (index % 5) * 3}%`
                }}
              />
            ))}
          </div>
          <button className="outline-button" type="button" onClick={() => onNavigate("real-time")}>Open Real-Time Data</button>
        </article>
      </section>
    </div>
  );
}
