import React, { useMemo, useState } from "react";
import MetricCard from "../components/cards/MetricCard.jsx";
import TelemetryChart from "../components/charts/TelemetryChart.jsx";
import SimulationStrategyField from "../components/simulations/SimulationStrategyField.jsx";
import StandbyPanel from "../components/standby/StandbyPanel.jsx";
import { simulation } from "../data/demoData.js";

const scenarios = [
  {
    key: "current",
    label: "Current Strategy",
    cluster: "Podium",
    winDelta: 0,
    podiumDelta: 0,
    batteryDelta: 0,
    riskDelta: 0,
    tyreDelta: 0,
    cornerDelta: 0,
    pathTone: "current",
    insight: "Current strategy keeps the lap 35 pit window as the highest-support path while Battery SOC is managed for Boost defense.",
    response: "Stay out to lap 35, recharge through lift-and-coast windows, and hold Boost for defense."
  },
  {
    key: "overtake",
    label: "Overtake Mode Armed",
    cluster: "Win",
    winDelta: 3,
    podiumDelta: 4,
    batteryDelta: -9,
    riskDelta: 11,
    tyreDelta: 4,
    cornerDelta: 6,
    pathTone: "danger",
    insight: "Overtake Mode Armed increases attack probability but drains Battery SOC and raises corner-entry exposure if boost overlaps braking.",
    response: "Use Overtake Mode only after confirming X-Mode straight-line phase and Boost Button margin."
  },
  {
    key: "battery-low",
    label: "Battery SOC Low",
    cluster: "Failed Strategy",
    winDelta: -6,
    podiumDelta: -11,
    batteryDelta: -18,
    riskDelta: 18,
    tyreDelta: 3,
    cornerDelta: 5,
    pathTone: "danger",
    insight: "Battery SOC Low shifts futures away from the current strategy and increases energy clipping exposure in the next attack phase.",
    response: "Recharge for two laps before attacking with Overtake Mode."
  },
  {
    key: "x-mode",
    label: "X-Mode Straight Advantage",
    cluster: "Points",
    winDelta: 4,
    podiumDelta: 5,
    batteryDelta: -5,
    riskDelta: 8,
    tyreDelta: 2,
    cornerDelta: 3,
    pathTone: "rain",
    insight: "X-Mode Straight-Line Phase improves straight speed but increases transition timing sensitivity before braking.",
    response: "Deploy X-Mode only on the designated straight, then lock Z-Mode before corner entry."
  },
  {
    key: "z-mode",
    label: "Z-Mode Corner Protection",
    cluster: "Podium",
    winDelta: 1,
    podiumDelta: 7,
    batteryDelta: 2,
    riskDelta: -7,
    tyreDelta: -8,
    cornerDelta: -12,
    pathTone: "green",
    insight: "Z-Mode Cornering Phase protects tyre thermal load and reduces corner-entry instability through Sector 2.",
    response: "Prioritize Z-Mode exits and avoid boost overlap into braking zones."
  },
  {
    key: "superclip",
    label: "Superclip Risk",
    cluster: "Failed Strategy",
    winDelta: -8,
    podiumDelta: -13,
    batteryDelta: -12,
    riskDelta: 24,
    tyreDelta: 6,
    cornerDelta: 10,
    pathTone: "danger",
    insight: "Superclip Risk expands the failed strategy tail when MGU-K deployment is clipped across acceleration zones.",
    response: "Reduce push phase and recover Battery SOC before authorizing an attack."
  },
  {
    key: "safety-recharge",
    label: "Safety Car Recharge",
    cluster: "Safety Car",
    winDelta: 5,
    podiumDelta: 6,
    batteryDelta: 14,
    riskDelta: -5,
    tyreDelta: -4,
    cornerDelta: -5,
    pathTone: "safety",
    insight: "Safety Car Recharge gives a Battery SOC reset and improves Boost defense margin for the restart.",
    response: "Harvest aggressively under safety car and prepare Boost defense at restart."
  },
  {
    key: "rival-energy",
    label: "Rival Energy Attack",
    cluster: "No Points",
    winDelta: -5,
    podiumDelta: -10,
    batteryDelta: -7,
    riskDelta: 19,
    tyreDelta: 5,
    cornerDelta: 6,
    pathTone: "danger",
    insight: "Rival Energy Attack increases the probability of Norris combining Overtake Mode eligibility with Boost Button deployment on lap 34.",
    response: "Submit Boost defense and conservative corner-entry deployment for race engineer review."
  },
  {
    key: "thermal",
    label: "Tyre Thermal Spike",
    cluster: "Rain Outcome",
    winDelta: -3,
    podiumDelta: -7,
    batteryDelta: -2,
    riskDelta: 13,
    tyreDelta: 19,
    cornerDelta: 8,
    pathTone: "rain",
    insight: "Tyre Thermal Spike increases narrower-tyre sensitivity and makes Z-Mode corner protection more valuable.",
    response: "Reduce corner-entry aggression and preserve Z-Mode stability until load drops below 70%."
  },
  {
    key: "corner-entry",
    label: "Corner Entry Instability",
    cluster: "Failed Strategy",
    winDelta: -7,
    podiumDelta: -10,
    batteryDelta: -4,
    riskDelta: 22,
    tyreDelta: 12,
    cornerDelta: 24,
    pathTone: "danger",
    insight: "Corner Entry Instability expands when boost deployment overlaps braking with lower downforce and narrower tyres.",
    response: "Conservative MGU-K deployment through Sector 2 requires Pit Wall Approval."
  }
];

export default function SimulationUniversePage({ onNavigate, appState, appActions }) {
  const [activeKey, setActiveKey] = useState("current");
  const activeScenario = useMemo(() => scenarios.find((item) => item.key === activeKey) ?? scenarios[0], [activeKey]);
  const metrics = {
    win: Math.max(0, Math.min(100, simulation.win_probability + activeScenario.winDelta)),
    podium: Math.max(0, Math.min(100, simulation.podium_probability + activeScenario.podiumDelta)),
    risk: Math.max(0, Math.min(100, simulation.risk_score + activeScenario.riskDelta)),
    battery: Math.max(0, Math.min(100, 63 + activeScenario.batteryDelta)),
    tyre: Math.max(0, Math.min(100, 71 + activeScenario.tyreDelta)),
    corner: Math.max(0, Math.min(100, 58 + activeScenario.cornerDelta))
  };
  const clusterLabels = {
    Win: "win futures",
    Podium: "podium futures",
    Points: "points futures",
    "No Points": "no-points futures",
    "Safety Car": "safety car outcomes",
    "Rain Outcome": "rain outcomes",
    "Failed Strategy": "failed strategy outcomes"
  };

  if (!appState?.isDemo) {
    return (
      <StandbyPanel
        eyebrow={appState?.isConnected ? "Connected Source Standby" : "Simulation Universe Standby"}
        title="Simulation Engine Standing By"
        body={appState?.isConnected
          ? "OpenF1 public source data is connected, but the Monte Carlo 2026 race universe is not running. Launch the demo to populate energy, active aero, and scenario filters."
          : "No race state is loaded, so the 2026 Monte Carlo universe is dormant. Launch the Austrian GP 2026 demo to populate energy, active aero, and scenario filters."}
        bullets={["100,000 futures waiting", "Battery SOC model idle", "Active Aero path unavailable", "Pit Wall Approval queue empty"]}
        onPrimary={appActions?.runDemo}
      />
    );
  }

  const submitScenario = () => {
    appActions?.submitStrategy(
      {
        id: `scenario-${activeScenario.key}`,
        name: activeScenario.response,
        explanation: activeScenario.insight,
        risk_level: metrics.risk > 70 ? "Critical" : metrics.risk > 50 ? "High" : "Medium",
        win_probability: metrics.win,
        podium_probability: metrics.podium,
        simulation_support: Math.max(22, 100 - metrics.risk),
        batterySOC: metrics.battery,
        energyClippingRisk: metrics.risk > 70 ? "critical" : metrics.risk > 55 ? "high" : "medium",
        cornerEntryRisk: metrics.corner > 70 ? "high" : "medium",
        tyreThermalLoad: metrics.tyre
      },
      `Simulation Universe | ${activeScenario.label}`
    );
    onNavigate("decision");
  };

  return (
    <div className="page-stack simulation-page">
      <section className="metric-grid">
        <MetricCard label="Monte Carlo Futures" value={simulation.simulation_count.toLocaleString()} subvalue="Rule-based v1" accent="blue" />
        <MetricCard label="Win Probability" value={`${metrics.win}%`} subvalue={activeScenario.label} accent="green" />
        <MetricCard label="Podium Probability" value={`${metrics.podium}%`} subvalue="Scenario-adjusted" accent="yellow" />
        <MetricCard label="Risk Delta" value={`${activeScenario.riskDelta >= 0 ? "+" : ""}${activeScenario.riskDelta}%`} subvalue={`Risk score ${metrics.risk}`} />
      </section>
      <section className={`panel universe-panel scenario-${activeScenario.pathTone}`}>
        <div className="panel-header">
          <div>
            <p className="eyebrow">Simulation Universe Explorer</p>
              <h2>Every Dot Is One 2026 Race Future</h2>
          </div>
          <span className="system-tag">100k futures | Lap 32 | demo strategy state</span>
        </div>
        <div className="universe-filter-strip">
          {scenarios.map((scenario) => (
            <button
              className={activeKey === scenario.key ? "active" : ""}
              type="button"
              onClick={() => setActiveKey(scenario.key)}
              key={scenario.key}
            >
              {scenario.label}
            </button>
          ))}
        </div>
        <SimulationStrategyField
          mode="demo"
          activeScenario={activeScenario.key}
          showLegend={false}
          showCTA={false}
        />
        <div className="cluster-legend">
          {simulation.outcome_clusters.map((cluster) => (
            <span key={cluster.name}><i style={{ background: cluster.color }} />{clusterLabels[cluster.name] ?? cluster.name}<b>{cluster.probability}%</b></span>
          ))}
        </div>
      </section>
      <div className="two-column simulation-inspector-grid">
        <section className="panel">
          <div className="panel-header"><h2>Strategy Comparison</h2></div>
          <TelemetryChart data={simulation.strategy_comparison} xKey="strategy" series={[{ key: "support", color: "#12d986" }, { key: "risk", color: "#ff3333" }]} type="bar" height={280} />
        </section>
        <section className="panel scenario-inspector">
          <div className="panel-header">
            <div>
              <p className="eyebrow">Scenario Inspector</p>
              <h2>{activeScenario.label}</h2>
            </div>
            <span className="system-tag">Requires Pit Wall Approval</span>
          </div>
          <p>{activeScenario.insight}</p>
          <div className="summary-grid tall">
            <span><b>{activeScenario.winDelta >= 0 ? "+" : ""}{activeScenario.winDelta}%</b> win probability impact</span>
            <span><b>{activeScenario.podiumDelta >= 0 ? "+" : ""}{activeScenario.podiumDelta}%</b> podium probability impact</span>
            <span><b>{activeScenario.batteryDelta >= 0 ? "+" : ""}{activeScenario.batteryDelta}%</b> Battery SOC impact</span>
            <span><b>{activeScenario.riskDelta >= 0 ? "+" : ""}{activeScenario.riskDelta}%</b> risk delta</span>
            <span><b>{activeScenario.tyreDelta >= 0 ? "+" : ""}{activeScenario.tyreDelta}%</b> tyre thermal impact</span>
            <span><b>{activeScenario.cornerDelta >= 0 ? "+" : ""}{activeScenario.cornerDelta}%</b> corner-entry risk delta</span>
            <span><b>{activeScenario.cluster}</b> highlighted outcome</span>
          </div>
          <div className="decision-warning">Recommended response: {activeScenario.response}</div>
          <button className="primary-button" type="button" onClick={submitScenario}>Submit Scenario to Pit Wall Approval</button>
        </section>
      </div>
    </div>
  );
}
