import React, { useState } from "react";
import { Database, X } from "lucide-react";
import StatusPill from "../cards/StatusPill.jsx";

export default function DataSourceModal({ error, loading, onCancel, onConnect }) {
  const [mode, setMode] = useState("public_historical");
  const [session, setSession] = useState("latest");
  const [driverNumber, setDriverNumber] = useState("");
  const [allowMockFallback, setAllowMockFallback] = useState(true);

  const submit = (event) => {
    event.preventDefault();
    onConnect?.({
      provider: "openf1",
      mode,
      session,
      driver_number: driverNumber ? Number(driverNumber) : null,
      allow_mock_fallback: allowMockFallback
    });
  };

  return (
    <div className="modal-backdrop" role="presentation">
      <section className="data-source-modal" role="dialog" aria-modal="true" aria-labelledby="data-source-title">
        <div className="panel-header">
          <div>
            <p className="eyebrow">Data Source</p>
            <h2 id="data-source-title">Connect Live Data Source</h2>
          </div>
          <button className="icon-button" type="button" onClick={onCancel} aria-label="Close data source modal">
            <X size={16} />
          </button>
        </div>

        <div className="source-provider-card">
          <Database size={18} />
          <div>
            <strong>OpenF1</strong>
            <span>Public latest/historical data is supported without auth. True real-time mode requires a subscription token.</span>
          </div>
          <StatusPill tone="warning">Public Source</StatusPill>
        </div>

        {error && <div className="decision-error">{error}</div>}

        <form className="data-source-form" onSubmit={submit}>
          <label>
            Provider
            <select value="openf1" disabled>
              <option value="openf1">OpenF1</option>
            </select>
          </label>
          <label>
            Mode
            <select value={mode} onChange={(event) => setMode(event.target.value)}>
              <option value="public_historical">Public latest/historical session</option>
              <option value="realtime_subscription">Real-time subscription mode</option>
            </select>
          </label>
          <label>
            Session
            <select value={session} onChange={(event) => setSession(event.target.value)}>
              <option value="latest">latest</option>
            </select>
          </label>
          <label>
            Driver focus
            <input value={driverNumber} onChange={(event) => setDriverNumber(event.target.value)} inputMode="numeric" placeholder="Optional driver number" />
          </label>
          <label className="checkbox-row">
            <input type="checkbox" checked={allowMockFallback} onChange={(event) => setAllowMockFallback(event.target.checked)} />
            Use structured mock fallback if OpenF1 is unavailable in this environment.
          </label>
          <div className="source-disclaimer">
            Connected source labels will identify public/historical data. The 2026 tactical layer remains a synthetic simulation overlay unless connected data provides matching fields.
          </div>
          <div className="modal-actions">
            <button className="ghost-button" type="button" onClick={onCancel}>Cancel</button>
            <button className="primary-button" type="submit" disabled={loading}>
              {loading ? "Connecting..." : "Connect"}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
