import React from "react";
import RiskBadge from "../cards/RiskBadge.jsx";

export default function AgentCard({ agent, prominent = false }) {
  return (
    <article className={`agent-card ${prominent ? "prominent" : ""}`}>
      <div className="agent-card-top">
        <div>
          <p className="eyebrow">{agent.role}</p>
          <h3>{agent.name}</h3>
        </div>
        <RiskBadge level={agent.risk_level} />
      </div>
      <div className="agent-recommendation">
        <span>Recommendation</span>
        <strong>{agent.recommendation}</strong>
      </div>
      <div className="confidence-line">
        <span>Confidence</span>
        <b>{agent.confidence}%</b>
        <i style={{ width: `${agent.confidence}%` }} />
      </div>
      <ul className="compact-list">
        {agent.evidence.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
      <p className="concern">{agent.concern}</p>
      <span className="stance">{agent.stance}</span>
    </article>
  );
}

