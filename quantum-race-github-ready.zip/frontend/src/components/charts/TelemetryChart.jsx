import React from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const tooltipStyle = {
  background: "#070b0f",
  border: "1px solid rgba(255,255,255,0.14)",
  borderRadius: 6,
  color: "#f4f7fb"
};

export default function TelemetryChart({ data, series, type = "line", height = 190, xKey = "lap_distance" }) {
  const Chart = type === "bar" ? BarChart : type === "area" ? AreaChart : LineChart;
  return (
    <div className="chart-frame" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <Chart data={data} margin={{ top: 10, right: 10, left: -22, bottom: 0 }}>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
          <XAxis dataKey={xKey} tick={{ fill: "#798692", fontSize: 10 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: "#798692", fontSize: 10 }} axisLine={false} tickLine={false} />
          <Tooltip contentStyle={tooltipStyle} labelStyle={{ color: "#ffdf5a" }} />
          {series.map((item) =>
            type === "bar" ? (
              <Bar key={item.key} dataKey={item.key} fill={item.color} radius={[3, 3, 0, 0]} />
            ) : type === "area" ? (
              <Area key={item.key} type="monotone" dataKey={item.key} stroke={item.color} fill={item.color} fillOpacity={0.18} strokeWidth={2} />
            ) : (
              <Line key={item.key} type="monotone" dataKey={item.key} stroke={item.color} strokeWidth={2} dot={false} />
            )
          )}
        </Chart>
      </ResponsiveContainer>
    </div>
  );
}

