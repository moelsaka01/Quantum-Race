import React from "react";

const drivers = [
  { code: "VER", pos: "P1", x: 31, y: 28, tone: "blue" },
  { code: "LEC", pos: "P2", x: 59, y: 24, tone: "red" },
  { code: "HAM", pos: "P3", x: 24, y: 67, tone: "active" },
  { code: "NOR", pos: "P4", x: 79, y: 48, tone: "orange" }
];

const demoCallouts = [
  { label: "X-Mode straight-line zone", x: 34, y: 23, tone: "cyan" },
  { label: "Z-Mode cornering phase", x: 67, y: 69, tone: "green" },
  { label: "Overtake Mode armed", x: 56, y: 40, tone: "red" },
  { label: "Rival Energy Attack Window", x: 80, y: 37, tone: "orange" },
  { label: "Battery SOC 63% | Boost available", x: 35, y: 77, tone: "green" },
  { label: "Pit Window Lap 33-37", x: 47, y: 61, tone: "yellow" }
];

export default function CinematicTrack({ mode = "demo", variant = "panel", compact = false }) {
  const isDemo = mode === "demo";
  const isConnected = mode === "connected";
  const stateLabel = isDemo
    ? "Austrian GP 2026 tactical layer"
    : isConnected
      ? "OpenF1 source connected | tactical overlay standby"
      : "No live 2026 race data connected";

  return (
    <div className={`cinematic-track cinematic-track-${variant} ${compact ? "compact" : ""} mode-${mode}`}>
      <div className="cinematic-terrain" />
      <svg className="cinematic-track-svg" viewBox="0 0 1000 560" role="img" aria-label="Cinematic race strategy track visualization">
        <defs>
          <filter id="cinematicTrackGlow" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="8" result="blur" />
            <feColorMatrix
              in="blur"
              type="matrix"
              values="1 0 0 0 0.95  0 0.15 0 0 0.05  0 0 0.12 0 0.08  0 0 0 0.85 0"
              result="glow"
            />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="cinematicTrackShadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="22" stdDeviation="18" floodColor="#000" floodOpacity="0.85" />
          </filter>
          <linearGradient id="cinematicAsphalt" x1="0%" x2="100%" y1="0%" y2="100%">
            <stop offset="0%" stopColor="#3d454b" />
            <stop offset="45%" stopColor="#181f25" />
            <stop offset="100%" stopColor="#49525a" />
          </linearGradient>
          <linearGradient id="cinematicLine" x1="0%" x2="100%">
            <stop offset="0%" stopColor="#ff2b2b" />
            <stop offset="38%" stopColor="#f2c94c" />
            <stop offset="72%" stopColor="#12d986" />
            <stop offset="100%" stopColor="#6fe7ff" />
          </linearGradient>
          <radialGradient id="cinematicTerrainLight" cx="38%" cy="38%" r="64%">
            <stop offset="0%" stopColor="rgba(64,92,70,0.52)" />
            <stop offset="52%" stopColor="rgba(21,41,36,0.3)" />
            <stop offset="100%" stopColor="rgba(2,5,8,0.72)" />
          </radialGradient>
        </defs>

        <rect x="0" y="0" width="1000" height="560" fill="url(#cinematicTerrainLight)" />
        <path className="cinematic-service-road road-a" d="M48 430 C172 348 270 330 386 356 C516 385 605 340 723 270 C820 214 925 208 974 244" />
        <path className="cinematic-service-road road-b" d="M110 102 C209 164 320 178 422 138 C539 92 620 82 740 114 C842 141 903 205 932 312" />
        <path className="cinematic-track-shadow" d="M112 330 C140 154 273 90 405 130 C512 163 519 72 650 105 C787 140 781 286 636 304 C514 319 485 413 343 417 C211 421 78 475 112 330 Z" />
        <path className="cinematic-track-body" d="M112 330 C140 154 273 90 405 130 C512 163 519 72 650 105 C787 140 781 286 636 304 C514 319 485 413 343 417 C211 421 78 475 112 330 Z" />
        <path className="cinematic-track-highlight" d="M112 330 C140 154 273 90 405 130 C512 163 519 72 650 105 C787 140 781 286 636 304 C514 319 485 413 343 417 C211 421 78 475 112 330 Z" />
        <path className="cinematic-kerb kerb-red" d="M130 344 C165 222 247 150 366 150" />
        <path className="cinematic-kerb kerb-white" d="M645 111 C760 143 751 257 632 278" />
        <path className="cinematic-kerb kerb-red kerb-bottom" d="M353 398 C226 408 102 452 112 330" />
        <path className="cinematic-racing-line" d="M118 332 C151 188 261 118 394 152 C505 181 521 98 646 127 C752 152 744 257 624 279 C502 302 478 387 342 390 C224 393 93 456 118 332 Z" />
        <path className="cinematic-strategy-path" d="M132 337 C176 223 258 168 374 160 C470 154 513 144 586 126 C638 114 683 121 721 151" />
        <path className="cinematic-pulse-path" d="M118 332 C151 188 261 118 394 152 C505 181 521 98 646 127 C752 152 744 257 624 279 C502 302 478 387 342 390 C224 393 93 456 118 332 Z" />
        <text x="202" y="111">SECTOR 1</text>
        <text x="654" y="91">SECTOR 2</text>
        <text x="690" y="352">SECTOR 3</text>
      </svg>

      <div className="cinematic-track-overlay" />
      <div className="cinematic-track-status">{stateLabel}</div>

      {isDemo && drivers.map((driver) => (
        <div className={`cinematic-driver driver-${driver.tone}`} style={{ left: `${driver.x}%`, top: `${driver.y}%` }} key={driver.code}>
          <b>{driver.pos}</b>
          <span>{driver.code}</span>
        </div>
      ))}

      {isDemo && demoCallouts.map((callout) => (
        <span className={`cinematic-callout callout-${callout.tone}`} style={{ left: `${callout.x}%`, top: `${callout.y}%` }} key={callout.label}>
          {callout.label}
        </span>
      ))}

      {!isDemo && (
        <>
          <span className="cinematic-callout callout-red standby-main">{isConnected ? "Connected source shell" : "Empty track shell"}</span>
          <span className="cinematic-callout callout-cyan standby-aero">Active Aero standby</span>
          <span className="cinematic-callout callout-yellow standby-energy">Battery SOC unavailable</span>
        </>
      )}
    </div>
  );
}
