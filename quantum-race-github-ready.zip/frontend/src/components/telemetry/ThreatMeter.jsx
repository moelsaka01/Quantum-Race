import React from "react";
import RiskBadge from "../cards/RiskBadge.jsx";

export default function ThreatMeter({ threats }) {
  const spokes = threats.slice(0, 6);
  return (
    <div className="threat-meter">
      <div className="radar-scope" aria-label="Threat radar">
        <span />
        <span />
        <span />
        {spokes.map((threat, index) => (
          <i
            key={threat.name}
            style={{
              transform: `rotate(${index * 60}deg) scaleY(${0.38 + threat.value / 130})`
            }}
          />
        ))}
      </div>
      <div className="threat-list">
        {threats.map((threat) => (
          <div className="meter-row" key={threat.name}>
            <div>
              <span>{threat.name}</span>
              <RiskBadge level={threat.severity === "critical" ? "Critical" : threat.severity === "warning" ? "High" : "Medium"} />
            </div>
            <strong>{threat.value}%</strong>
            <div className="meter-track">
              <b style={{ width: `${threat.value}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

