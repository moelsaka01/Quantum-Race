import React from "react";
import { ChevronDown } from "lucide-react";
import CinematicTrack from "./CinematicTrack.jsx";

export default function TrackPanel({ drivers, compact = false, mode = "demo" }) {
  return (
    <section className={`panel track-panel ${compact ? "track-panel-compact" : ""}`}>
      <div className="panel-header">
        <div>
          <p className="eyebrow">Live Track View</p>
          <h2>2026 Race Strategy Visualization</h2>
        </div>
        <button className="ghost-button" type="button">
          3D Track <ChevronDown size={14} />
        </button>
      </div>
      <div className="track-layout">
        <div className="driver-table">
          <div className="table-row table-head">
            <span>Pos</span>
            <span>Driver</span>
            <span>Gap</span>
            <span>Tyre</span>
            <span>Pit</span>
          </div>
          {drivers.map((driver) => (
            <div className={`table-row ${driver.code === "HAM" ? "selected" : ""}`} key={driver.code}>
              <span>{driver.pos}</span>
              <span><b className={`driver-dot ${driver.code.toLowerCase()}`} />{driver.code}</span>
              <span>{driver.gap}</span>
              <span className="tyre-chip">{driver.tyre}</span>
              <span>{driver.pit}</span>
            </div>
          ))}
        </div>
        <CinematicTrack mode={mode} variant="panel" compact={compact} />
      </div>
    </section>
  );
}

