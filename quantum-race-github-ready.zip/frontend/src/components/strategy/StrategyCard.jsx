import React from "react";
import { Send } from "lucide-react";
import RiskBadge from "../cards/RiskBadge.jsx";

export default function StrategyCard({ strategy, onSend }) {
  const batteryImpact = strategy.battery_soc_impact ?? strategy.batterySOCImpact ?? strategy.batterySOC ?? 0;
  const boostRequirement = strategy.boost_requirement ?? strategy.boostRequirement ?? 0;
  return (
    <article className="strategy-card">
      <div className="strategy-title">
        <div>
          <p className="eyebrow">Strategy Option</p>
          <h3>{strategy.name}</h3>
        </div>
        <RiskBadge level={strategy.risk_level} />
      </div>
      <div className="strategy-metrics">
        <span><b>P{strategy.expected_finish}</b> expected</span>
        <span><b>{strategy.probability_of_success}%</b> success</span>
        <span><b>{strategy.win_probability}%</b> win</span>
        <span><b>{strategy.podium_probability}%</b> podium</span>
        <span><b>{batteryImpact}%</b> Battery SOC impact</span>
        <span><b>{boostRequirement}%</b> Boost requirement</span>
      </div>
      <p>{strategy.explanation}</p>
      <div className="risk-bars">
        {[
          ["Recharge", strategy.recharge_requirement ?? strategy.rechargeRequirement],
          ["Overtake Mode", strategy.overtake_mode_relevance],
          ["Active Aero", strategy.active_aero_risk ?? strategy.activeAeroRisk],
          ["Energy Clip", strategy.energy_clipping_risk],
          ["Tyre Thermal", strategy.tyre_thermal_risk],
          ["Corner Entry", strategy.corner_entry_risk],
          ["Simulation", strategy.simulation_support]
        ].filter(([, value]) => value !== undefined).map(([label, value]) => (
          <div className="mini-bar" key={label}>
            <span>{label}</span>
            <i><b style={{ width: `${value}%` }} /></i>
            <strong>{value}%</strong>
          </div>
        ))}
      </div>
      <button className="outline-button" type="button" onClick={() => onSend?.(strategy)}>
        <Send size={15} /> Submit to Pit Wall Approval
      </button>
    </article>
  );
}

