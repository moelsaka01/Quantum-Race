import React from "react";
export default function MemoryTimeline({ memories }) {
  return (
    <div className="memory-timeline">
      {memories.map((memory) => (
        <article className="memory-item" key={memory.id}>
          <div className="memory-node" />
          <div className="memory-content">
            <div className="memory-topline">
              <span>{memory.date}</span>
              <span>Lap {memory.lap}</span>
              <span>{memory.circuit}</span>
            </div>
            <h3>{memory.race}</h3>
            <p>{memory.situation}</p>
            <div className="memory-grid">
              <span><b>AI</b>{memory.ai_recommendation}</span>
              <span><b>Pit Wall</b>{memory.race_engineer_decision}</span>
              <span><b>Outcome</b>{memory.final_outcome}</span>
              {memory.selected_strategy && <span><b>Strategy</b>{memory.selected_strategy}</span>}
              {memory.risk_level && <span><b>Risk</b>{memory.risk_level}</span>}
              {memory.battery_soc && <span><b>Battery SOC</b>{memory.battery_soc}%</span>}
              {memory.boost_status && <span><b>Boost</b>{memory.boost_status}</span>}
              {memory.overtake_mode_status && <span><b>Overtake Mode</b>{memory.overtake_mode_status}</span>}
              {memory.active_aero_mode && <span><b>Active Aero</b>{memory.active_aero_mode}</span>}
              {memory.energy_clipping_risk && <span><b>Energy Risk</b>{memory.energy_clipping_risk}</span>}
              {memory.corner_entry_risk && <span><b>Corner Entry</b>{memory.corner_entry_risk}</span>}
              {memory.tyre_thermal_load && <span><b>Tyre Thermal</b>{memory.tyre_thermal_load}%</span>}
              {memory.rival_energy_threat && <span><b>Rival Energy</b>{memory.rival_energy_threat}</span>}
              {memory.timestamp && <span><b>Timestamp</b>{new Date(memory.timestamp).toLocaleString()}</span>}
            </div>
            <div className="lesson">Lesson: {memory.lesson_learned}</div>
            <div className="tag-row">
              {memory.tags.map((tag) => (
                <em key={tag}>{tag}</em>
              ))}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

