import React from "react";
import { CircleOff, DatabaseZap, Play, RadioTower } from "lucide-react";
import StatusPill from "../cards/StatusPill.jsx";

export default function StandbyPanel({
  eyebrow = "No Live Data",
  title,
  body,
  bullets = [],
  primaryLabel = "Run Austrian GP 2026 Demo",
  secondaryLabel = "Connect Live Data Source",
  onPrimary,
  compact = false
}) {
  return (
    <section className={`standby-hero ${compact ? "compact" : ""}`}>
      <div className="standby-copy">
        <StatusPill tone="warning">NO LIVE 2026 RACE DATA CONNECTED</StatusPill>
        <p className="eyebrow">{eyebrow}</p>
        <h2>{title}</h2>
        <p>{body}</p>
        <div className="standby-status-grid">
          {bullets.map((item) => (
            <span key={item}><i />{item}</span>
          ))}
        </div>
        <div className="standby-actions">
          <button className="primary-button" type="button" onClick={onPrimary}>
            <Play size={16} /> {primaryLabel}
          </button>
          <button className="ghost-button disabled" type="button" disabled>
            <DatabaseZap size={16} /> {secondaryLabel} | Coming Soon
          </button>
        </div>
      </div>
      <div className="standby-visual" aria-hidden="true">
        <div className="standby-track-shell">
          <svg viewBox="0 0 580 330" preserveAspectRatio="xMidYMid meet">
            <path className="standby-track-shadow" d="M77 193 C111 83 235 53 341 81 C450 110 508 186 467 244 C423 306 297 273 216 270 C126 267 51 252 77 193Z" />
            <path className="standby-track-core" d="M77 193 C111 83 235 53 341 81 C450 110 508 186 467 244 C423 306 297 273 216 270 C126 267 51 252 77 193Z" />
            <path className="standby-racing-line" d="M104 197 C141 120 236 83 330 104 C417 124 460 187 431 229 C395 278 301 247 221 246 C153 245 89 235 104 197Z" />
          </svg>
          <div className="standby-scanline" />
          <div className="standby-node node-a">SIM</div>
          <div className="standby-node node-b">AI</div>
          <div className="standby-node node-c">RIVAL</div>
          <div className="standby-node node-d">PIT WALL</div>
        </div>
        <div className="standby-telemetry-rail">
          {[
            ["Telemetry", "Disconnected", RadioTower],
            ["Simulation", "Standing by", CircleOff],
            ["Approval Queue", "Empty", CircleOff]
          ].map(([label, value, Icon]) => (
            <span key={label}>
              <Icon size={15} />
              <b>{label}</b>
              <em>{value}</em>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
