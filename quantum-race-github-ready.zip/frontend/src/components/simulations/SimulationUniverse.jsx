import React from "react";

const scenarioPathLabels = {
  current: "Current strategy path | lap 32 to lap 35 recharge window",
  overtake: "Overtake Mode path | attack probability versus Battery SOC drain",
  "battery-low": "Battery SOC low path | energy clipping tail expanding",
  "x-mode": "X-Mode path | straight-line gain versus aero transition risk",
  "z-mode": "Z-Mode path | corner stability and tyre thermal protection",
  superclip: "Superclip path | MGU-K clipping exposure",
  "safety-recharge": "Safety Car Recharge path | restart boost margin",
  "rival-energy": "Rival energy attack path | Norris Boost Button pressure",
  thermal: "Tyre thermal spike path | narrower-tyre load sensitivity",
  "corner-entry": "Corner-entry instability path | lower downforce braking risk"
};

export default function SimulationUniverse({ points, compact = false, activeScenario = "current", highlightCluster, pathTone = "current" }) {
  const labels = [
    { name: "Win futures", x: 45, y: 8, color: "#12d986" },
    { name: "Podium futures", x: 32, y: 24, color: "#f2c94c" },
    { name: "Points futures", x: 26, y: 47, color: "#2aa8ff" },
    { name: "No-points futures", x: 15, y: 70, color: "#ff3333" },
    { name: "Rain outcomes", x: 63, y: 14, color: "#6fe7ff" },
    { name: "Safety car outcomes", x: 73, y: 36, color: "#ff8a1f" },
    { name: "Failed strategy outcomes", x: 83, y: 73, color: "#d92929" }
  ];

  return (
    <div className={`simulation-universe ${compact ? "compact" : "annotated"} scenario-path-${pathTone}`}>
      <div className="universe-grid" />
      {!compact && (
        <svg className="universe-strategy-path" viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="Current strategy path">
          <path d="M18 71 C28 58 35 46 43 31 C51 16 61 14 73 36" />
          <circle cx="43" cy="31" r="1.7" />
          <circle cx="73" cy="36" r="1.7" />
        </svg>
      )}
      {points.map((point, index) => (
        <span
          className={`future-dot ${highlightCluster && point.cluster !== highlightCluster ? "dimmed" : ""} ${highlightCluster === point.cluster ? "highlighted" : ""}`}
          key={`${point.cluster}-${index}`}
          title={point.cluster}
          style={{
            left: `${point.x}%`,
            top: `${point.y}%`,
            background: point.color,
            opacity: point.opacity,
            animationDelay: `${(index % 12) * 0.12}s`
          }}
        />
      ))}
      {!compact && labels.map((label) => (
        <strong className={`universe-label ${highlightCluster && label.name.toLowerCase().startsWith(highlightCluster.toLowerCase().split(" ")[0]) ? "active" : ""}`} key={label.name} style={{ left: `${label.x}%`, top: `${label.y}%`, color: label.color }}>
          {label.name}
        </strong>
      ))}
      {!compact && <div className="strategy-path-label">{scenarioPathLabels[activeScenario] ?? scenarioPathLabels.current}</div>}
      <div className="axis x-axis">Race Lap Outcome</div>
      <div className="axis y-axis">Position</div>
    </div>
  );
}

