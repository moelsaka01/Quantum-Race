import React, { useMemo } from "react";

const clusters = [
  { key: "Win", label: "Win Futures", x: 31, y: 24, spreadX: 14, spreadY: 11, color: "#12d986" },
  { key: "Podium", label: "Podium Futures", x: 43, y: 39, spreadX: 16, spreadY: 13, color: "#f2c94c" },
  { key: "Points", label: "Points Futures", x: 57, y: 51, spreadX: 18, spreadY: 15, color: "#2aa8ff" },
  { key: "No Points", label: "No-Points Futures", x: 23, y: 68, spreadX: 15, spreadY: 13, color: "#ff3333" },
  { key: "Safety Car", label: "Safety Car Outcomes", x: 69, y: 35, spreadX: 13, spreadY: 12, color: "#ff8a1f" },
  { key: "Rain Outcome", label: "Rain Outcomes", x: 77, y: 21, spreadX: 14, spreadY: 11, color: "#6fe7ff" },
  { key: "Failed Strategy", label: "Failed Strategy Tail", x: 79, y: 74, spreadX: 17, spreadY: 12, color: "#d92929" }
];

const scenarioClusterMap = {
  current: "Podium",
  overtake: "Win",
  "battery-low": "Failed Strategy",
  "x-mode": "Points",
  "z-mode": "Podium",
  superclip: "Failed Strategy",
  "safety-recharge": "Safety Car",
  "rival-energy": "No Points",
  thermal: "Rain Outcome",
  "corner-entry": "Failed Strategy"
};

function seededUnit(index, salt) {
  const value = Math.sin(index * 97.17 + salt * 31.93) * 10000;
  return value - Math.floor(value);
}

function makePoints(count) {
  return Array.from({ length: count }, (_, index) => {
    const cluster = clusters[index % clusters.length];
    const x = Math.max(3, Math.min(97, cluster.x + (seededUnit(index, 1) - 0.5) * cluster.spreadX * 2));
    const y = Math.max(5, Math.min(95, cluster.y + (seededUnit(index, 2) - 0.5) * cluster.spreadY * 2));
    const z = Math.round(seededUnit(index, 3) * 42);
    return {
      cluster: cluster.key,
      color: cluster.color,
      x,
      y,
      z,
      size: 2 + Math.round(seededUnit(index, 4) * 3),
      opacity: 0.42 + seededUnit(index, 5) * 0.46
    };
  });
}

export default function SimulationStrategyField({
  activeScenario = "current",
  compact = false,
  mode = "demo",
  showLegend = true,
  showCTA = false,
  onExplore
}) {
  const count = compact ? 168 : 360;
  const points = useMemo(() => makePoints(count), [count]);
  const activeCluster = scenarioClusterMap[activeScenario] ?? activeScenario ?? "Podium";
  const isDemo = mode === "demo";
  const isConnected = mode === "connected";
  const label = isDemo
    ? "100,000 Race Futures"
    : isConnected
      ? "Connected data loaded. Simulation layer awaiting race-state model."
      : "Simulation Engine Standby";

  return (
    <div className={`simulation-strategy-field ${compact ? "compact" : "full"} mode-${mode}`}>
      <div className="sim-field-header">
        <div>
          <span>{compact ? "Simulation Preview" : "Monte Carlo Race Universe"}</span>
          <strong>{label}</strong>
        </div>
        {showCTA && (
          <button className="outline-button compact-button" type="button" onClick={onExplore}>
            Explore Simulations
          </button>
        )}
      </div>
      <div className="sim-field-stage">
        <div className="sim-field-floor">
          <i className="sim-axis sim-axis-x">Laps</i>
          <i className="sim-axis sim-axis-y">Position</i>
          <i className="sim-axis sim-axis-z">Race Outcome</i>
          <span className="sim-current-path" />
          {points.map((point, index) => {
            const active = point.cluster === activeCluster;
            return (
              <b
                className={`sim-field-dot ${active ? "active" : ""}`}
                key={`${point.cluster}-${index}`}
                style={{
                  left: `${point.x}%`,
                  top: `${point.y}%`,
                  width: point.size,
                  height: point.size,
                  background: point.color,
                  color: point.color,
                  opacity: isDemo ? (active ? 1 : point.opacity) : 0.14,
                  transform: `translate3d(-50%, -50%, ${point.z}px) scale(${active ? 1.35 : 1})`,
                  animationDelay: `${(index % 18) * 0.09}s`
                }}
                title={point.cluster}
              />
            );
          })}
          {clusters.slice(0, compact ? 4 : clusters.length).map((cluster) => (
            <em
              className={`sim-field-label ${cluster.key === activeCluster ? "active" : ""}`}
              key={cluster.key}
              style={{ left: `${cluster.x}%`, top: `${cluster.y}%`, color: cluster.color }}
            >
              {cluster.label}
            </em>
          ))}
        </div>
      </div>
      {showLegend && (
        <div className="sim-field-legend">
          {clusters.map((cluster) => (
            <span key={cluster.key}>
              <i style={{ background: cluster.color }} />
              {cluster.label}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
