import React from "react";
export default function StatusPill({ children, tone = "live" }) {
  return <span className={`status-pill status-${tone}`}>{children}</span>;
}

