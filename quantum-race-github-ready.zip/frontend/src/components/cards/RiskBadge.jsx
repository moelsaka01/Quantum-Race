import React from "react";
export default function RiskBadge({ level = "Medium" }) {
  const normalized = String(level).toLowerCase();
  return <span className={`risk-badge risk-${normalized}`}>{level}</span>;
}

