import React from "react";
import { motion } from "framer-motion";

export default function MetricCard({ label, value, subvalue, accent = "red", children }) {
  return (
    <motion.section className={`metric-card accent-${accent}`} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.28 }}>
      <div>
        <p className="eyebrow">{label}</p>
        <strong className="metric-value">{value}</strong>
        {subvalue && <span className="metric-subvalue">{subvalue}</span>}
      </div>
      {children && <div className="metric-art">{children}</div>}
    </motion.section>
  );
}

