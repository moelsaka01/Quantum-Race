import React, { useEffect, useMemo, useState } from "react";
import { Check, RotateCcw, X } from "lucide-react";
import StatusPill from "../cards/StatusPill.jsx";

const fallbackApproval = {
  id: "pit-in-3",
  name: "Pit in 3 laps",
  source: "Austrian GP 2026 Demo",
  aiRecommendation: "Stay out until lap 35, recharge Battery SOC, and prepare Boost defense against Norris",
  explanation: "Best balance between tyre life, traffic, and rival cover.",
  riskLevel: "Medium",
  winProbability: 22,
  podiumProbability: 66,
  simulationSupport: 82,
  batterySOC: 63,
  batterySOCTrend: "depleting",
  boostButton: "available",
  overtakeMode: "armed_next_lap",
  activeAeroMode: "Z-Mode",
  xModeAvailable: true,
  zModeStability: 78,
  rechargeMode: "balanced",
  mguKDeployment: 350,
  superclipDuration: 3.2,
  energyClippingRisk: "medium",
  cornerEntryRisk: "high",
  tyreThermalLoad: 71,
  rivalEnergyAttackWindow: "Lap 34-36",
  linkedSimulationId: "simulation-demo-100k-lap-32",
  linkedAgentDebateId: "debate-demo-lap-32",
  responsibleEngineer: "M. Alvarez",
  sessionId: "austrian-gp-demo-lap-32",
  decisionId: "decision-demo-pit-wall-001",
  createdAt: "2026-06-21T14:32:00.000Z",
  status: "Strategy under race engineer review"
};

export default function DecisionPanel({ pendingApproval, onLogDecision, loggedDecisions = [] }) {
  const approval = pendingApproval ?? fallbackApproval;
  const [action, setAction] = useState("Approved");
  const [rationale, setRationale] = useState("");
  const [revisedStrategy, setRevisedStrategy] = useState("");
  const [riskTolerance, setRiskTolerance] = useState("Medium");
  const [acknowledgedCritical, setAcknowledgedCritical] = useState(false);
  const [error, setError] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [localLog, setLocalLog] = useState([]);

  useEffect(() => {
    setAction("Approved");
    setRationale("");
    setRevisedStrategy("");
    setRiskTolerance("Medium");
    setAcknowledgedCritical(false);
    setError("");
    setConfirmation("");
  }, [approval.decisionId]);

  const requiresRiskAcknowledgement = ["Critical"].includes(approval.riskLevel) || ["critical", "high"].includes(String(approval.energyClippingRisk).toLowerCase()) || ["critical", "high"].includes(String(approval.cornerEntryRisk).toLowerCase());
  const approvalCompleted = Boolean(confirmation || approval.completedAt || approval.status?.startsWith("Decision logged"));
  const decisionState = useMemo(() => (approvalCompleted ? "Completed" : "Under Review"), [approvalCompleted]);
  const statusText = confirmation || approval.status || decisionState;
  const reviewTimestamp = new Date(approval.createdAt).toLocaleString([], {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
  const workflowStates = [
    { state: "Recommendation Generated", detail: "AI strategy output created", complete: true },
    { state: "Simulation Evidence Attached", detail: approval.linkedSimulationId, complete: true },
    { state: "Agent Debate Attached", detail: approval.linkedAgentDebateId, complete: true },
    { state: "Energy Model Attached", detail: `Battery SOC ${approval.batterySOC}% | ${approval.rechargeMode}`, complete: true },
    { state: "Active Aero Model Attached", detail: `${approval.activeAeroMode} | Z-Mode ${approval.zModeStability}%`, complete: true },
    { state: "Race Engineer Review", detail: approvalCompleted ? "Review completed" : "Awaiting race engineer action", complete: true },
    { state: action, detail: approvalCompleted ? "Authorization recorded" : "Pending authorization", complete: approvalCompleted },
    { state: "Strategy Logged", detail: approvalCompleted ? "Current session decision stored" : "Blocked until rationale is entered", complete: approvalCompleted },
    { state: "Race Memory Updated", detail: confirmation || (approvalCompleted ? "Decision logged. Race Memory updated." : "Pending final decision"), complete: approvalCompleted }
  ];
  const auditEntries = [
    { time: "18:29:44", actor: "Strategy Director", event: `Generated recommendation: ${approval.aiRecommendation}` },
    { time: "18:30:08", actor: "Team Principal Agent", event: "Attached agent debate evidence and flagged race engineer review" },
    { time: "18:31:12", actor: "Energy Strategist", event: "Attached Battery SOC, Boost, recharge, and MGU-K deployment evidence" },
    { time: "18:31:29", actor: "Active Aero Engineer", event: "Attached X-Mode, Z-Mode, and aero transition risk model" }
  ];

  const submitDecision = (event) => {
    event.preventDefault();
    const cleanRationale = rationale.trim();
    const cleanRevised = revisedStrategy.trim();

    if (!cleanRationale) {
      setError("A race engineer rationale is required before the decision can be logged.");
      return;
    }
    if (action === "Adjusted" && !cleanRevised) {
      setError("Adjusted decisions require revised strategy text.");
      return;
    }
    if (action === "Rejected" && cleanRationale.length < 12) {
      setError("Rejected decisions require a clear rejection rationale.");
      return;
    }
    if (requiresRiskAcknowledgement && !acknowledgedCritical) {
      setError("Critical-risk recommendations require explicit race engineer acknowledgement.");
      return;
    }

    const decision = {
      pendingApprovalId: approval.id,
      decisionId: approval.decisionId,
      sessionId: approval.sessionId,
      selectedStrategy: approval.name,
      aiRecommendation: approval.aiRecommendation,
      source: approval.source,
      action,
      rationale: cleanRationale,
      revisedStrategy: action === "Adjusted" ? cleanRevised : "",
      riskTolerance,
      riskLevel: approval.riskLevel,
      responsibleEngineer: approval.responsibleEngineer,
      linkedSimulationId: approval.linkedSimulationId,
      linkedAgentDebateId: approval.linkedAgentDebateId,
      batterySOC: approval.batterySOC,
      batterySOCTrend: approval.batterySOCTrend,
      boostButton: approval.boostButton,
      overtakeMode: approval.overtakeMode,
      activeAeroMode: approval.activeAeroMode,
      xModeAvailable: approval.xModeAvailable,
      zModeStability: approval.zModeStability,
      rechargeMode: approval.rechargeMode,
      mguKDeployment: approval.mguKDeployment,
      superclipDuration: approval.superclipDuration,
      energyClippingRisk: approval.energyClippingRisk,
      cornerEntryRisk: approval.cornerEntryRisk,
      tyreThermalLoad: approval.tyreThermalLoad,
      rivalEnergyAttackWindow: approval.rivalEnergyAttackWindow
    };
    const record = onLogDecision?.(decision) ?? { ...decision, timestamp: new Date().toISOString() };
    setLocalLog((items) => [record, ...items]);
    setConfirmation("Decision logged. Race Memory updated.");
    setError("");
  };

  return (
    <section className="panel decision-panel">
      <div className="panel-header">
        <div>
          <p className="eyebrow">Pit Wall Approval</p>
          <h2>Race Engineer Approval Required</h2>
        </div>
        <StatusPill tone={decisionState === "Completed" ? "success" : "warning"}>{statusText}</StatusPill>
      </div>
      <div className="decision-warning">AI recommendation only. Final strategy requires race engineer authorization before it is logged.</div>
      {confirmation && <div className="decision-confirmation">{confirmation}</div>}
      {error && <div className="decision-error">{error}</div>}
      <div className="decision-state-timeline">
        {workflowStates.map((item) => (
          <article className={item.complete ? "complete" : ""} key={item.state}>
            <span />
            <strong>{item.state}</strong>
            <small>{item.detail}</small>
          </article>
        ))}
      </div>
      <div className="decision-grid">
        <div className="decision-evidence">
          <p className="eyebrow">Recommendation Source</p>
          <h3>{approval.source}</h3>
          <dl>
            <div><dt>Strategy selected</dt><dd>{approval.name}</dd></div>
            <div><dt>AI recommendation</dt><dd>{approval.aiRecommendation}</dd></div>
            <div><dt>Simulation evidence</dt><dd>{approval.winProbability}% win | {approval.podiumProbability}% podium</dd></div>
            <div><dt>Agent debate evidence</dt><dd>{approval.simulationSupport}% support</dd></div>
            <div><dt>Battery SOC</dt><dd>{approval.batterySOC}% | {approval.batterySOCTrend}</dd></div>
            <div><dt>Boost availability</dt><dd>{approval.boostButton}</dd></div>
            <div><dt>Overtake Mode status</dt><dd>{approval.overtakeMode}</dd></div>
            <div><dt>Active aero mode</dt><dd>{approval.activeAeroMode}</dd></div>
            <div><dt>X-Mode availability</dt><dd>{approval.xModeAvailable ? "available" : "unavailable"}</dd></div>
            <div><dt>Z-Mode stability</dt><dd>{approval.zModeStability}%</dd></div>
            <div><dt>Recharge mode</dt><dd>{approval.rechargeMode}</dd></div>
            <div><dt>MGU-K deployment</dt><dd>{approval.mguKDeployment} kW</dd></div>
            <div><dt>Superclip exposure</dt><dd>{approval.superclipDuration}s/lap</dd></div>
            <div><dt>Energy clipping risk</dt><dd>{approval.energyClippingRisk}</dd></div>
            <div><dt>Corner-entry risk</dt><dd>{approval.cornerEntryRisk}</dd></div>
            <div><dt>Tyre thermal load</dt><dd>{approval.tyreThermalLoad}%</dd></div>
            <div><dt>Rival energy attack window</dt><dd>{approval.rivalEnergyAttackWindow}</dd></div>
            <div><dt>Rival twin evidence</dt><dd>Norris Energy Attack Window active</dd></div>
            <div><dt>Weather uncertainty</dt><dd>Rain crossover lap 42-48</dd></div>
            <div><dt>Risk level</dt><dd>{approval.riskLevel}</dd></div>
            <div><dt>Responsible engineer</dt><dd>{approval.responsibleEngineer}</dd></div>
            <div><dt>Timestamp</dt><dd>{reviewTimestamp}</dd></div>
            <div><dt>Decision ID</dt><dd>{approval.decisionId}</dd></div>
            <div><dt>Session ID</dt><dd>{approval.sessionId}</dd></div>
            <div><dt>Linked simulation ID</dt><dd>{approval.linkedSimulationId}</dd></div>
            <div><dt>Linked agent debate ID</dt><dd>{approval.linkedAgentDebateId}</dd></div>
          </dl>
          <ul className="compact-list">
            <li>Simulation support strongest for the selected strategy path.</li>
            <li>Rival model warns Norris may open an Overtake Mode attack window.</li>
            <li>Energy clipping and corner-entry risk keep final command under race engineer review.</li>
          </ul>
        </div>
        <form className="decision-form" onSubmit={submitDecision}>
          <div className="decision-actions" role="group" aria-label="Decision action">
            {[
              ["Approved", "Approve Recommendation", Check],
              ["Adjusted", "Adjust Strategy", RotateCcw],
              ["Rejected", "Reject Recommendation", X]
            ].map(([value, label, Icon]) => (
              <button className={action === value ? "active" : ""} type="button" onClick={() => setAction(value)} key={value}>
                <Icon size={16} /> {label}
              </button>
            ))}
          </div>
          {action === "Adjusted" && (
            <label>
              Revised strategy
              <input value={revisedStrategy} onChange={(event) => setRevisedStrategy(event.target.value)} placeholder="Example: recharge lap 33, pit lap 35, preserve Boost for defense" />
            </label>
          )}
          <label>
            Race engineer rationale
            <textarea value={rationale} onChange={(event) => setRationale(event.target.value)} rows={4} placeholder="Explain why the pit wall approved, adjusted, or rejected this recommendation." />
          </label>
          {requiresRiskAcknowledgement && (
            <label className="checkbox-row">
              <input type="checkbox" checked={acknowledgedCritical} onChange={(event) => setAcknowledgedCritical(event.target.checked)} />
              I acknowledge this critical energy or corner-entry risk and confirm race engineer authorization is still required.
            </label>
          )}
          <label>
            Risk tolerance
            <select value={riskTolerance} onChange={(event) => setRiskTolerance(event.target.value)}>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </select>
          </label>
          <button className="primary-button" type="submit">Log Race Engineer Decision</button>
        </form>
      </div>
      <div className="audit-log">
        <div className="panel-header compact">
          <h2>Audit Log</h2>
          <StatusPill tone={confirmation ? "success" : "warning"}>{confirmation ? "Race Memory Updated" : "Awaiting Decision"}</StatusPill>
        </div>
        {[...localLog, ...loggedDecisions].slice(0, 3).map((entry) => ({
          time: new Date(entry.timestamp ?? Date.now()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
          actor: entry.responsibleEngineer ?? "M. Alvarez, Race Engineer",
          event: `${entry.action}: ${entry.rationale}`
        })).concat(auditEntries).map((entry, index) => (
          <div key={`${entry.time}-${index}`}>
            <span>{entry.time}</span>
            <strong>{entry.actor}</strong>
            <p>{entry.event}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
