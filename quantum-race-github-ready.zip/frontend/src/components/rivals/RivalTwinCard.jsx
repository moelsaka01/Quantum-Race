import React from "react";
import RiskBadge from "../cards/RiskBadge.jsx";

export default function RivalTwinCard({ twin, selected, onSelect }) {
  const energyAttackThreat = twin.energy_attack_threat;
  return (
    <button className={`rival-card ${selected ? "selected" : ""}`} type="button" onClick={() => onSelect(twin)}>
      <span className="helmet-mark">{twin.name.slice(0, 1)}</span>
      <div>
        <strong>{twin.name}</strong>
        <small>{twin.position} | {twin.team}</small>
      </div>
      <RiskBadge level={energyAttackThreat > 75 ? "Critical" : energyAttackThreat > 50 ? "High" : "Medium"} />
    </button>
  );
}

